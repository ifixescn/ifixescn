# 翊鸢化工页面文件结构说明

## 📁 文件列表

```
yiyuan-source-package/
├── README.md                          # 项目说明文档
├── CHANGELOG.md                       # 更新日志
├── INSTALLATION.md                    # 安装指南
├── FILE_STRUCTURE.md                  # 文件结构说明（本文件）
├── Yiyuan.tsx                         # 前端页面组件
├── YiyuanManage.tsx                   # 管理后台组件
├── yiyuan-translations.ts             # UI翻译文件
└── yiyuan-content-translations.ts     # 内容翻译文件
```

## 📄 文件详细说明

### 1. Yiyuan.tsx
**文件类型**：React组件（TypeScript）
**文件大小**：约 50KB
**代码行数**：约 1200 行

**主要功能**：
- 翊鸢化工防伪验证页面主组件
- 多语言支持（9种语言）
- 响应式设计
- 防伪验证流程展示
- 产品介绍和公司信息展示

**核心代码结构**：
```typescript
export default function Yiyuan() {
  // 状态管理
  const [language, setLanguage] = useState<Language>('zh');
  const [content, setContent] = useState<YiyuanContent | null>(null);
  
  // 图片数组（4个验证步骤）
  const stepImages = [
    'file-9x3wqhg1kz5s.jpg',  // 步骤1
    'file-9x456rzmxm2o.jpg',  // 步骤2
    'file-9x4ftjzhktmo.jpg',  // 步骤3
    'file-9x4np8ngktts.jpg'   // 步骤4
  ];
  
  // 组件渲染
  return (
    <div className="min-h-screen">
      {/* Hero区域 */}
      {/* 产品介绍 */}
      {/* 防伪验证流程 */}
      {/* 公司信息 */}
      {/* 页脚 */}
    </div>
  );
}
```

**依赖组件**：
- `lucide-react` - 图标库
- `@/i18n/yiyuan-translations` - UI翻译
- `@/i18n/yiyuan-content-translations` - 内容翻译

**样式特点**：
- Tailwind CSS 类名
- 响应式断点：`md:`, `lg:`
- 深色模式支持
- 平滑过渡动画

### 2. YiyuanManage.tsx
**文件类型**：React组件（TypeScript）
**文件大小**：约 30KB
**代码行数**：约 800 行

**主要功能**：
- 翊鸢化工页面内容管理
- 多语言内容编辑
- 图片上传管理
- 实时预览功能

**核心代码结构**：
```typescript
export default function YiyuanManage() {
  // 状态管理
  const [selectedLanguage, setSelectedLanguage] = useState<Language>('zh');
  const [content, setContent] = useState<YiyuanContent>({});
  const [isLoading, setIsLoading] = useState(false);
  
  // 保存内容
  const handleSave = async () => {
    await updateYiyuanContent(selectedLanguage, content);
  };
  
  // 组件渲染
  return (
    <div className="container mx-auto p-6">
      {/* 语言选择器 */}
      {/* 内容编辑表单 */}
      {/* 保存按钮 */}
      {/* 预览区域 */}
    </div>
  );
}
```

**依赖组件**：
- `@/components/ui/card` - 卡片组件
- `@/components/ui/button` - 按钮组件
- `@/components/ui/input` - 输入框组件
- `@/components/ui/textarea` - 文本域组件
- `@/db/api` - API函数

### 3. yiyuan-translations.ts
**文件类型**：TypeScript模块
**文件大小**：约 15KB
**代码行数**：约 400 行

**主要功能**：
- 页面UI文本的多语言翻译
- 支持9种语言
- 类型安全的翻译对象

**数据结构**：
```typescript
export const YIYUAN_TRANSLATIONS: Record<Language, YiyuanTranslations> = {
  zh: {
    hero: {
      title: '翊鸢化工',
      subtitle: '专业化工产品制造商',
      // ...
    },
    product: {
      title: '产品介绍',
      // ...
    },
    verification: {
      title: '防伪验证',
      steps: [
        { title: '找到防伪标签', description: '...' },
        { title: '扫描二维码', description: '...' },
        { title: '查看验证结果', description: '...' },
        { title: '确认产品真伪', description: '...' }
      ]
    },
    // ...
  },
  en: { /* 英文翻译 */ },
  ja: { /* 日文翻译 */ },
  // ... 其他语言
};
```

**支持的语言**：
- `zh` - 中文
- `en` - 英文
- `ja` - 日文
- `ko` - 韩文
- `ru` - 俄文
- `es` - 西班牙文
- `fr` - 法文
- `de` - 德文
- `ar` - 阿拉伯文

### 4. yiyuan-content-translations.ts
**文件类型**：TypeScript模块
**文件大小**：约 20KB
**代码行数**：约 500 行

**主要功能**：
- 页面内容的多语言翻译
- 产品介绍内容
- 公司信息内容
- 验证步骤详细说明

**数据结构**：
```typescript
export const YIYUAN_CONTENT_TRANSLATIONS: Record<Language, YiyuanContentTranslations> = {
  zh: {
    productDescription: '详细的产品介绍内容...',
    companyDescription: '详细的公司介绍内容...',
    verificationSteps: [
      {
        title: '步骤1：找到防伪标签',
        description: '详细说明...',
        tips: ['提示1', '提示2']
      },
      // ... 其他步骤
    ]
  },
  en: { /* 英文内容 */ },
  // ... 其他语言
};
```

## 🔗 文件依赖关系

```
Yiyuan.tsx
├── yiyuan-translations.ts          (UI翻译)
├── yiyuan-content-translations.ts  (内容翻译)
└── lucide-react                    (图标库)

YiyuanManage.tsx
├── @/components/ui/*               (UI组件)
├── @/db/api                        (API函数)
├── yiyuan-translations.ts          (UI翻译)
└── yiyuan-content-translations.ts  (内容翻译)
```

## 📊 代码统计

| 文件 | 类型 | 大小 | 行数 | 主要内容 |
|------|------|------|------|----------|
| Yiyuan.tsx | React组件 | ~50KB | ~1200 | 前端页面 |
| YiyuanManage.tsx | React组件 | ~30KB | ~800 | 管理后台 |
| yiyuan-translations.ts | TypeScript | ~15KB | ~400 | UI翻译 |
| yiyuan-content-translations.ts | TypeScript | ~20KB | ~500 | 内容翻译 |
| **总计** | - | **~115KB** | **~2900** | - |

## 🎯 关键代码片段

### 语言切换功能
```typescript
const handleLanguageChange = (lang: Language) => {
  setLanguage(lang);
  // 更新URL参数
  const url = new URL(window.location.href);
  url.searchParams.set('lang', lang);
  window.history.pushState({}, '', url);
};
```

### 图片显示优化
```typescript
<img
  src={stepImage}
  alt={step.title}
  className="w-full h-48 object-contain bg-white rounded-lg"
  loading="lazy"
/>
```

### 响应式布局
```typescript
<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
  {/* 内容 */}
</div>
```

## 🔧 自定义指南

### 修改图片
在 `Yiyuan.tsx` 中找到 `stepImages` 数组：
```typescript
const stepImages = [
  'your-image-1.jpg',  // 替换为您的图片URL
  'your-image-2.jpg',
  'your-image-3.jpg',
  'your-image-4.jpg'
];
```

### 添加新语言
1. 在 `yiyuan-translations.ts` 中添加新语言的翻译
2. 在 `yiyuan-content-translations.ts` 中添加新语言的内容
3. 在 `Yiyuan.tsx` 中的 `LANGUAGES` 数组中添加新语言选项

### 修改样式
所有样式使用Tailwind CSS类名，可以直接修改类名来调整样式：
```typescript
<div className="bg-primary text-white p-6 rounded-lg">
  {/* 修改这些类名来改变样式 */}
</div>
```

## 📝 注意事项

1. **图片路径**：确保图片URL完整且可访问
2. **类型安全**：所有翻译对象都有TypeScript类型定义
3. **响应式设计**：使用Tailwind的响应式断点
4. **性能优化**：图片使用lazy loading
5. **SEO优化**：使用语义化HTML标签

## 🔍 代码质量

- ✅ TypeScript严格模式
- ✅ ESLint代码检查
- ✅ Prettier代码格式化
- ✅ 组件化设计
- ✅ 可维护性高
- ✅ 可扩展性强

---

**文件结构说明版本**：v1.0.0
**最后更新时间**：2026-02-27
