# 翊鸢化工页面安装指南

## 📋 前置要求

### 技术栈
- Node.js 18+
- React 18+
- TypeScript 5+
- Tailwind CSS 3+
- Supabase

### 依赖包
```json
{
  "react": "^18.0.0",
  "react-dom": "^18.0.0",
  "react-router-dom": "^6.0.0",
  "typescript": "^5.0.0",
  "tailwindcss": "^3.0.0",
  "@supabase/supabase-js": "^2.0.0",
  "lucide-react": "^0.0.0"
}
```

## 🚀 安装步骤

### 1. 复制源码文件

```bash
# 创建目标目录（如果不存在）
mkdir -p src/pages
mkdir -p src/pages/admin
mkdir -p src/i18n

# 复制页面组件
cp Yiyuan.tsx src/pages/

# 复制管理后台组件
cp YiyuanManage.tsx src/pages/admin/

# 复制翻译文件
cp yiyuan-translations.ts src/i18n/
cp yiyuan-content-translations.ts src/i18n/
```

### 2. 配置路由

在 `src/routes.tsx` 中添加路由配置：

```typescript
import Yiyuan from './pages/Yiyuan';
import YiyuanManage from './pages/admin/YiyuanManage';

// 在 routes 数组中添加前端路由
const routes: RouteConfig[] = [
  // ... 其他路由
  {
    name: 'Yiyuan Chemical',
    path: '/yiyuan',
    element: <Yiyuan />,
    visible: false  // 不在导航菜单中显示
  },
  // ... 其他路由
];

// 在 admin children 中添加管理后台路由
{
  name: 'Admin Panel',
  path: '/admin',
  element: <AdminLayout />,
  visible: false,
  children: [
    // ... 其他管理路由
    {
      name: 'Yiyuan Management',
      path: 'yiyuan-manage',
      element: <YiyuanManage />
    },
    // ... 其他管理路由
  ]
}
```

### 3. 配置独立页面布局

在 `src/App.tsx` 中配置独立页面布局（无Header和Footer）：

```typescript
function AppContent() {
  const location = useLocation();
  
  // 检查是否为独立页面
  const isStandalonePage = location.pathname === '/yiyuan';

  return (
    <>
      <GlobalSEO />
      <ScrollToTop />
      <Toaster />
      <RequireAuth whiteList={[
        // ... 其他白名单路径
        "/yiyuan"  // 添加到白名单
      ]}>
        {isStandalonePage ? (
          // 独立页面布局（无 Header 和 Footer）
          <Routes>
            {/* 路由配置 */}
          </Routes>
        ) : (
          // 标准页面布局（包含 Header 和 Footer）
          <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow">
              <Routes>
                {/* 路由配置 */}
              </Routes>
            </main>
            <Footer />
          </div>
        )}
      </RequireAuth>
    </>
  );
}
```

### 4. 配置数据库

#### 4.1 创建数据库表

执行以下SQL创建必要的数据库表：

```sql
-- 创建翊鸢内容表
CREATE TABLE IF NOT EXISTS yiyuan_content (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  language TEXT NOT NULL UNIQUE,
  hero_title TEXT,
  hero_subtitle TEXT,
  product_title TEXT,
  product_description TEXT,
  company_name TEXT,
  company_description TEXT,
  verification_title TEXT,
  verification_description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 创建制造商信息表
CREATE TABLE IF NOT EXISTS yiyuan_manufacturer (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  address TEXT,
  phone TEXT,
  email TEXT,
  website TEXT,
  logo_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_yiyuan_content_language ON yiyuan_content(language);

-- 启用RLS（行级安全）
ALTER TABLE yiyuan_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE yiyuan_manufacturer ENABLE ROW LEVEL SECURITY;

-- 创建公开读取策略
CREATE POLICY "Allow public read access" ON yiyuan_content
  FOR SELECT USING (true);

CREATE POLICY "Allow public read access" ON yiyuan_manufacturer
  FOR SELECT USING (true);

-- 创建管理员写入策略（需要根据实际情况调整）
CREATE POLICY "Allow admin write access" ON yiyuan_content
  FOR ALL USING (
    auth.jwt() ->> 'role' = 'admin'
  );

CREATE POLICY "Allow admin write access" ON yiyuan_manufacturer
  FOR ALL USING (
    auth.jwt() ->> 'role' = 'admin'
  );
```

#### 4.2 插入初始数据

```sql
-- 插入中文内容
INSERT INTO yiyuan_content (language, hero_title, hero_subtitle, product_title, product_description, company_name, company_description, verification_title, verification_description)
VALUES (
  'zh',
  '翊鸢化工',
  '专业化工产品制造商',
  '产品介绍',
  '我们提供高质量的化工产品...',
  '深圳翊鸢化工有限公司',
  '公司成立于...',
  '防伪验证',
  '扫描产品上的二维码进行防伪验证'
);

-- 插入英文内容
INSERT INTO yiyuan_content (language, hero_title, hero_subtitle, product_title, product_description, company_name, company_description, verification_title, verification_description)
VALUES (
  'en',
  'Yiyuan Chemical',
  'Professional Chemical Products Manufacturer',
  'Product Introduction',
  'We provide high-quality chemical products...',
  'Shenzhen Yiyuan Chemical Co., Ltd.',
  'Founded in...',
  'Anti-counterfeiting Verification',
  'Scan the QR code on the product for verification'
);

-- 插入制造商信息
INSERT INTO yiyuan_manufacturer (name, address, phone, email, website)
VALUES (
  '深圳翊鸢化工有限公司',
  '深圳市...',
  '+86-xxx-xxxx-xxxx',
  'info@yiyuan.com',
  'https://www.yiyuan.com'
);
```

### 5. 配置API函数

在 `src/db/api.ts` 中添加API函数（如果还没有）：

```typescript
// 获取翊鸢内容
export async function getYiyuanContent(language: string = 'zh') {
  const { data, error } = await supabase
    .from('yiyuan_content')
    .select('*')
    .eq('language', language)
    .single();

  if (error) throw error;
  return data;
}

// 更新翊鸢内容
export async function updateYiyuanContent(language: string, content: any) {
  const { data, error } = await supabase
    .from('yiyuan_content')
    .upsert({ language, ...content, updated_at: new Date().toISOString() })
    .select()
    .single();

  if (error) throw error;
  return data;
}

// 获取制造商信息
export async function getYiyuanManufacturer() {
  const { data, error } = await supabase
    .from('yiyuan_manufacturer')
    .select('*')
    .single();

  if (error) throw error;
  return data;
}
```

### 6. 配置管理后台菜单

在 `src/pages/admin/AdminLayout.tsx` 中添加菜单项：

```typescript
// 在侧边栏菜单中添加
<Link to="/admin/yiyuan-manage">
  <Button variant="ghost" className="w-full justify-start">
    <Building className="mr-2 h-4 w-4" />
    翊鸢化工管理
  </Button>
</Link>
```

## ✅ 验证安装

### 1. 启动开发服务器

```bash
npm run dev
```

### 2. 访问页面

- **前端页面**：http://localhost:5173/yiyuan
- **管理后台**：http://localhost:5173/admin/yiyuan-manage

### 3. 检查功能

- [ ] 页面正常加载
- [ ] 多语言切换正常
- [ ] 图片正常显示
- [ ] 响应式布局正常
- [ ] 管理后台可以访问
- [ ] 内容编辑功能正常

## 🐛 常见问题

### 问题1：页面404错误

**原因**：路由配置不正确

**解决方案**：
1. 检查 `src/routes.tsx` 中是否正确添加了路由
2. 确保路由路径为 `/yiyuan`
3. 重启开发服务器

### 问题2：图片不显示

**原因**：图片URL不正确或图片未上传

**解决方案**：
1. 检查图片URL是否完整
2. 确保图片已上传到Supabase Storage
3. 检查图片访问权限

### 问题3：翻译文件导入错误

**原因**：翻译文件路径不正确

**解决方案**：
1. 确保翻译文件在 `src/i18n/` 目录下
2. 检查导入路径是否正确
3. 重新编译项目

### 问题4：数据库连接错误

**原因**：Supabase配置不正确

**解决方案**：
1. 检查 `.env` 文件中的Supabase配置
2. 确保数据库表已创建
3. 检查RLS策略是否正确

## 📞 技术支持

如遇到其他问题，请联系技术团队。

## 📝 下一步

安装完成后，您可以：
1. 自定义页面内容
2. 上传产品图片
3. 配置多语言内容
4. 调整页面样式
5. 添加更多功能

---

**安装指南版本**：v1.0.0
**最后更新时间**：2026-02-27
