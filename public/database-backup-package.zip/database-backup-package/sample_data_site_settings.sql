-- ================================================================
-- Sample Data: Site Settings
-- ================================================================
-- This file contains sample site configuration data
-- ================================================================

INSERT INTO site_settings (key, value, type, description, created_at, updated_at) VALUES
('site_name', 'iFixes', 'text', 'Website name', NOW(), NOW()),
('site_description', 'Global leading mobile phone repair resource integration service provider', 'text', 'Website description', NOW(), NOW()),
('site_keywords', 'mobile phone repair, smartphone repair, repair guides, repair parts, repair tools', 'text', 'Website keywords', NOW(), NOW()),
('site_logo', '', 'text', 'Website logo URL', NOW(), NOW()),
('site_favicon', '', 'text', 'Website favicon URL', NOW(), NOW()),
('contact_email', 'info@ifixes.com', 'text', 'Contact email', NOW(), NOW()),
('contact_phone', '+1-xxx-xxx-xxxx', 'text', 'Contact phone', NOW(), NOW()),
('contact_address', 'Shenzhen, China', 'text', 'Contact address', NOW(), NOW()),
('footer_copyright', '© 2026 iFixes. All rights reserved.', 'text', 'Footer copyright text', NOW(), NOW()),
('enable_registration', 'true', 'boolean', 'Enable user registration', NOW(), NOW()),
('enable_comments', 'true', 'boolean', 'Enable comments', NOW(), NOW()),
('items_per_page', '12', 'number', 'Items per page', NOW(), NOW()),
('maintenance_mode', 'false', 'boolean', 'Maintenance mode', NOW(), NOW())
ON CONFLICT (key) DO UPDATE SET
  value = EXCLUDED.value,
  updated_at = NOW();

-- ================================================================
-- End of Sample Data: Site Settings
-- ================================================================
