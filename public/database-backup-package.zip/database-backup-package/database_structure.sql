/*
# 创建翻译缓存表

## 1. 新表
- `translations`
  - `id` (uuid, 主键)
  - `source_text` (text, 原文)
  - `target_text` (text, 译文)
  - `source_lang` (text, 源语言代码，默认 'en')
  - `target_lang` (text, 目标语言代码)
  - `translation_key` (text, 翻译键，用于快速查找)
  - `context` (text, 上下文信息，可选)
  - `created_at` (timestamptz, 创建时间)
  - `updated_at` (timestamptz, 更新时间)
  - `usage_count` (integer, 使用次数)

## 2. 索引
- 为 translation_key 创建唯一索引
- 为 source_lang 和 target_lang 创建组合索引
- 为 source_text 创建全文搜索索引

## 3. 安全策略
- 允许所有用户读取翻译缓存
- 只允许通过 Edge Function 写入翻译缓存

## 4. RPC 函数
- `get_translation`: 获取翻译（带缓存）
- `batch_get_translations`: 批量获取翻译
- `increment_translation_usage`: 增加翻译使用次数
*/

-- 创建翻译缓存表
CREATE TABLE IF NOT EXISTS translations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_text text NOT NULL,
  target_text text NOT NULL,
  source_lang text NOT NULL DEFAULT 'en',
  target_lang text NOT NULL,
  translation_key text NOT NULL,
  context text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  usage_count integer DEFAULT 0
);

-- 创建唯一索引（防止重复翻译）
CREATE UNIQUE INDEX IF NOT EXISTS idx_translations_key 
ON translations(translation_key);

-- 创建组合索引（优化查询）
CREATE INDEX IF NOT EXISTS idx_translations_langs 
ON translations(source_lang, target_lang);

-- 创建全文搜索索引
CREATE INDEX IF NOT EXISTS idx_translations_source_text 
ON translations USING gin(to_tsvector('english', source_text));

-- 创建更新时间触发器
CREATE OR REPLACE FUNCTION update_translations_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_translations_updated_at
  BEFORE UPDATE ON translations
  FOR EACH ROW
  EXECUTE FUNCTION update_translations_updated_at();

-- RPC: 获取单个翻译
CREATE OR REPLACE FUNCTION get_translation(
  p_source_text text,
  p_source_lang text DEFAULT 'en',
  p_target_lang text DEFAULT 'zh'
)
RETURNS TABLE(
  id uuid,
  source_text text,
  target_text text,
  source_lang text,
  target_lang text
) AS $$
DECLARE
  v_translation_key text;
BEGIN
  -- 生成翻译键
  v_translation_key := md5(p_source_lang || ':' || p_target_lang || ':' || p_source_text);
  
  -- 查询翻译
  RETURN QUERY
  SELECT 
    t.id,
    t.source_text,
    t.target_text,
    t.source_lang,
    t.target_lang
  FROM translations t
  WHERE t.translation_key = v_translation_key;
  
  -- 增加使用次数
  UPDATE translations 
  SET usage_count = usage_count + 1
  WHERE translation_key = v_translation_key;
END;
$$ LANGUAGE plpgsql;

-- RPC: 批量获取翻译
CREATE OR REPLACE FUNCTION batch_get_translations(
  p_texts text[],
  p_source_lang text DEFAULT 'en',
  p_target_lang text DEFAULT 'zh'
)
RETURNS TABLE(
  source_text text,
  target_text text,
  found boolean
) AS $$
DECLARE
  v_text text;
  v_translation_key text;
  v_result record;
BEGIN
  -- 遍历所有文本
  FOREACH v_text IN ARRAY p_texts
  LOOP
    -- 生成翻译键
    v_translation_key := md5(p_source_lang || ':' || p_target_lang || ':' || v_text);
    
    -- 查询翻译
    SELECT t.target_text INTO v_result
    FROM translations t
    WHERE t.translation_key = v_translation_key;
    
    IF FOUND THEN
      -- 找到翻译
      RETURN QUERY SELECT v_text, v_result.target_text, true;
      
      -- 增加使用次数
      UPDATE translations 
      SET usage_count = usage_count + 1
      WHERE translation_key = v_translation_key;
    ELSE
      -- 未找到翻译
      RETURN QUERY SELECT v_text, v_text, false;
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- RPC: 保存翻译（仅供 Edge Function 使用）
CREATE OR REPLACE FUNCTION save_translation(
  p_source_text text,
  p_target_text text,
  p_source_lang text DEFAULT 'en',
  p_target_lang text DEFAULT 'zh',
  p_context text DEFAULT NULL
)
RETURNS uuid AS $$
DECLARE
  v_translation_key text;
  v_id uuid;
BEGIN
  -- 生成翻译键
  v_translation_key := md5(p_source_lang || ':' || p_target_lang || ':' || p_source_text);
  
  -- 插入或更新翻译
  INSERT INTO translations (
    source_text,
    target_text,
    source_lang,
    target_lang,
    translation_key,
    context,
    usage_count
  ) VALUES (
    p_source_text,
    p_target_text,
    p_source_lang,
    p_target_lang,
    v_translation_key,
    p_context,
    1
  )
  ON CONFLICT (translation_key) 
  DO UPDATE SET
    target_text = EXCLUDED.target_text,
    updated_at = now(),
    usage_count = translations.usage_count + 1
  RETURNING id INTO v_id;
  
  RETURN v_id;
END;
$$ LANGUAGE plpgsql;

-- RPC: 批量保存翻译
CREATE OR REPLACE FUNCTION batch_save_translations(
  p_translations jsonb
)
RETURNS integer AS $$
DECLARE
  v_translation jsonb;
  v_count integer := 0;
BEGIN
  -- 遍历所有翻译
  FOR v_translation IN SELECT * FROM jsonb_array_elements(p_translations)
  LOOP
    PERFORM save_translation(
      v_translation->>'source_text',
      v_translation->>'target_text',
      COALESCE(v_translation->>'source_lang', 'en'),
      COALESCE(v_translation->>'target_lang', 'zh'),
      v_translation->>'context'
    );
    v_count := v_count + 1;
  END LOOP;
  
  RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- 允许所有用户读取翻译缓存
ALTER TABLE translations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "允许所有用户读取翻译" ON translations
  FOR SELECT TO public USING (true);

-- 注意：写入操作只能通过 Edge Function 进行，不需要直接的写入策略/*
# 创建系统配置表

## 1. 新增表
- `system_settings`
  - `id` (uuid, 主键)
  - `setting_key` (text, 唯一, 配置键名)
  - `setting_value` (jsonb, 配置值)
  - `category` (text, 配置分类)
  - `description` (text, 配置描述)
  - `is_encrypted` (boolean, 是否加密)
  - `created_at` (timestamptz, 创建时间)
  - `updated_at` (timestamptz, 更新时间)

## 2. 安全策略
- 启用 RLS
- 只允许管理员读取和修改配置

## 3. RPC 函数
- get_system_setting：获取单个配置
- set_system_setting：设置配置
- delete_system_setting：删除配置
- get_settings_by_category：获取分类下的所有配置
*/

-- 删除已存在的表（如果存在）
DROP TABLE IF EXISTS system_settings CASCADE;

-- 创建系统配置表
CREATE TABLE system_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value jsonb NOT NULL DEFAULT '{}'::jsonb,
  category text NOT NULL DEFAULT 'general',
  description text,
  is_encrypted boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX idx_system_settings_key ON system_settings(setting_key);
CREATE INDEX idx_system_settings_category ON system_settings(category);

-- 启用 RLS
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- 创建策略：只允许管理员访问
CREATE POLICY "管理员可以查看所有配置" ON system_settings
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "管理员可以修改所有配置" ON system_settings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- 创建更新时间触发器
CREATE OR REPLACE FUNCTION update_system_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER system_settings_updated_at
  BEFORE UPDATE ON system_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_system_settings_updated_at();

-- 创建 RPC 函数：获取配置
CREATE OR REPLACE FUNCTION get_system_setting(p_setting_key text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_setting_value jsonb;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION '权限不足';
  END IF;

  SELECT setting_value INTO v_setting_value
  FROM system_settings
  WHERE setting_key = p_setting_key;

  RETURN COALESCE(v_setting_value, '{}'::jsonb);
END;
$$;

-- 创建 RPC 函数：设置配置
CREATE OR REPLACE FUNCTION set_system_setting(
  p_setting_key text,
  p_setting_value jsonb,
  p_category text DEFAULT 'general',
  p_description text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION '权限不足';
  END IF;

  INSERT INTO system_settings (setting_key, setting_value, category, description)
  VALUES (p_setting_key, p_setting_value, p_category, p_description)
  ON CONFLICT (setting_key)
  DO UPDATE SET
    setting_value = p_setting_value,
    category = p_category,
    description = COALESCE(p_description, system_settings.description),
    updated_at = now();
END;
$$;

-- 创建 RPC 函数：删除配置
CREATE OR REPLACE FUNCTION delete_system_setting(p_setting_key text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION '权限不足';
  END IF;

  DELETE FROM system_settings WHERE setting_key = p_setting_key;
END;
$$;

-- 创建 RPC 函数：获取分类下的所有配置
CREATE OR REPLACE FUNCTION get_settings_by_category(p_category text)
RETURNS TABLE (
  setting_key text,
  setting_value jsonb,
  description text,
  updated_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION '权限不足';
  END IF;

  RETURN QUERY
  SELECT
    s.setting_key,
    s.setting_value,
    s.description,
    s.updated_at
  FROM system_settings s
  WHERE s.category = p_category
  ORDER BY s.setting_key;
END;
$$;

-- 插入默认翻译配置
INSERT INTO system_settings (setting_key, setting_value, category, description) VALUES
  ('translation.baidu.app_id', '""'::jsonb, 'translation', '百度翻译 APP ID'),
  ('translation.baidu.secret_key', '""'::jsonb, 'translation', '百度翻译密钥'),
  ('translation.enabled', 'true'::jsonb, 'translation', '是否启用自动翻译'),
  ('translation.quality', '"high"'::jsonb, 'translation', '翻译质量（high/standard）'),
  ('translation.cache_enabled', 'true'::jsonb, 'translation', '是否启用翻译缓存'),
  ('translation.cache_ttl', '2592000'::jsonb, 'translation', '缓存过期时间（秒，默认30天）'),
  ('translation.auto_translate', 'true'::jsonb, 'translation', '是否自动翻译未找到的文本'),
  ('translation.fallback_lang', '"en"'::jsonb, 'translation', '备用语言'),
  ('translation.rate_limit', '100'::jsonb, 'translation', 'API 调用频率限制（次/分钟）'),
  ('translation.log_enabled', 'true'::jsonb, 'translation', '是否记录翻译日志'),
  ('translation.review_required', 'false'::jsonb, 'translation', '新翻译是否需要审核'),
  ('translation.supported_languages', '["en","zh","zh-TW","ja","ko","es","fr","de","ru","pt","it","ar"]'::jsonb, 'translation', '支持的语言列表');
/*
# 添加内部配置获取函数

## 说明
- 创建 get_system_setting_internal 函数供 Edge Function 使用
- 不需要权限检查，因为 Edge Function 使用 service_role
- 保留原有的 get_system_setting 函数供前端使用
*/

-- 创建内部配置获取函数（供 Edge Function 使用）
CREATE OR REPLACE FUNCTION get_system_setting_internal(p_setting_key text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_setting_value jsonb;
BEGIN
  -- 不检查权限，因为 Edge Function 使用 service_role 调用
  SELECT setting_value INTO v_setting_value
  FROM system_settings
  WHERE setting_key = p_setting_key;

  RETURN COALESCE(v_setting_value, 'null'::jsonb);
END;
$$;

-- 添加注释
COMMENT ON FUNCTION get_system_setting_internal IS '内部配置获取函数，供 Edge Function 使用，不检查权限';
/*
# 创建 SEO 管理表

## 1. 新增表

### seo_settings 表
全局 SEO 设置表，存储网站级别的 SEO 配置
- `id` (uuid, 主键)
- `site_title` (text) - 网站标题
- `site_description` (text) - 网站描述
- `site_keywords` (text) - 网站关键词
- `site_author` (text) - 网站作者
- `og_image` (text) - Open Graph 默认图片
- `twitter_handle` (text) - Twitter 账号
- `google_analytics_id` (text) - Google Analytics ID
- `google_search_console_id` (text) - Google Search Console ID
- `bing_webmaster_id` (text) - Bing Webmaster ID
- `robots_txt` (text) - robots.txt 内容
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### page_seo 表
页面级 SEO 设置表，存储每个页面的 SEO 配置
- `id` (uuid, 主键)
- `page_path` (text, 唯一) - 页面路径
- `page_title` (text) - 页面标题
- `page_description` (text) - 页面描述
- `page_keywords` (text) - 页面关键词
- `og_title` (text) - Open Graph 标题
- `og_description` (text) - Open Graph 描述
- `og_image` (text) - Open Graph 图片
- `twitter_title` (text) - Twitter Card 标题
- `twitter_description` (text) - Twitter Card 描述
- `twitter_image` (text) - Twitter Card 图片
- `canonical_url` (text) - 规范 URL
- `noindex` (boolean) - 是否禁止索引
- `nofollow` (boolean) - 是否禁止跟踪链接
- `priority` (decimal) - 站点地图优先级 (0.0-1.0)
- `change_frequency` (text) - 更新频率
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### redirects 表
重定向管理表，存储 URL 重定向规则
- `id` (uuid, 主键)
- `from_path` (text, 唯一) - 源路径
- `to_path` (text) - 目标路径
- `redirect_type` (integer) - 重定向类型 (301, 302, 307, 308)
- `is_active` (boolean) - 是否启用
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

## 2. 安全性
- 所有表都是公开的，任何人都可以读取
- 只有管理员可以修改

## 3. RPC 函数
- `get_seo_settings`: 获取全局 SEO 设置
- `update_seo_settings`: 更新全局 SEO 设置
- `get_page_seo`: 获取页面 SEO 设置
- `upsert_page_seo`: 创建或更新页面 SEO 设置
- `get_all_page_seo`: 获取所有页面 SEO 设置（用于生成站点地图）
- `get_active_redirects`: 获取所有启用的重定向规则
*/

-- 创建 seo_settings 表
CREATE TABLE IF NOT EXISTS seo_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_title text NOT NULL DEFAULT 'iFixes',
  site_description text NOT NULL DEFAULT 'Global leading mobile phone repair resource integration service provider',
  site_keywords text NOT NULL DEFAULT 'mobile phone repair, smartphone repair, screen repair, battery replacement',
  site_author text NOT NULL DEFAULT 'iFixes',
  og_image text,
  twitter_handle text,
  google_analytics_id text,
  google_search_console_id text,
  bing_webmaster_id text,
  robots_txt text NOT NULL DEFAULT 'User-agent: *
Allow: /
Sitemap: /sitemap.xml',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建 page_seo 表
CREATE TABLE IF NOT EXISTS page_seo (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_path text UNIQUE NOT NULL,
  page_title text,
  page_description text,
  page_keywords text,
  og_title text,
  og_description text,
  og_image text,
  twitter_title text,
  twitter_description text,
  twitter_image text,
  canonical_url text,
  noindex boolean DEFAULT false,
  nofollow boolean DEFAULT false,
  priority decimal(2,1) DEFAULT 0.5 CHECK (priority >= 0.0 AND priority <= 1.0),
  change_frequency text DEFAULT 'weekly' CHECK (change_frequency IN ('always', 'hourly', 'daily', 'weekly', 'monthly', 'yearly', 'never')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建 redirects 表
CREATE TABLE IF NOT EXISTS redirects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_path text UNIQUE NOT NULL,
  to_path text NOT NULL,
  redirect_type integer DEFAULT 301 CHECK (redirect_type IN (301, 302, 307, 308)),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 插入默认的全局 SEO 设置
INSERT INTO seo_settings (id, site_title, site_description, site_keywords, site_author)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'iFixes - Global Leading Mobile Phone Repair Resource Integration Service Provider',
  'iFixes provides comprehensive mobile phone repair resources, including repair guides, parts sourcing, technical support, and professional training for repair technicians worldwide.',
  'mobile phone repair, smartphone repair, screen repair, battery replacement, repair guides, repair parts, technical support, repair training',
  'iFixes'
)
ON CONFLICT (id) DO NOTHING;

-- 插入默认的页面 SEO 设置
INSERT INTO page_seo (page_path, page_title, page_description, priority, change_frequency) VALUES
('/', 'Home - iFixes', 'Welcome to iFixes, your trusted partner for mobile phone repair resources and services.', 1.0, 'daily'),
('/articles', 'Articles - iFixes', 'Browse our comprehensive collection of repair guides and technical articles.', 0.9, 'daily'),
('/products', 'Products - iFixes', 'Discover high-quality repair parts and tools for mobile phone repair.', 0.9, 'daily'),
('/questions', 'Q&A - iFixes', 'Get answers to your repair questions from our expert community.', 0.8, 'daily'),
('/downloads', 'Downloads - iFixes', 'Access repair manuals, software tools, and technical resources.', 0.8, 'weekly'),
('/videos', 'Videos - iFixes', 'Watch step-by-step repair tutorials and training videos.', 0.8, 'weekly'),
('/search', 'Search - iFixes', 'Search for repair guides, parts, and technical information.', 0.7, 'weekly')
ON CONFLICT (page_path) DO NOTHING;

-- 创建更新时间触发器函数
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 为所有表添加更新时间触发器
CREATE TRIGGER update_seo_settings_updated_at BEFORE UPDATE ON seo_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_page_seo_updated_at BEFORE UPDATE ON page_seo
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_redirects_updated_at BEFORE UPDATE ON redirects
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- RPC 函数：获取全局 SEO 设置
CREATE OR REPLACE FUNCTION get_seo_settings()
RETURNS TABLE (
  id uuid,
  site_title text,
  site_description text,
  site_keywords text,
  site_author text,
  og_image text,
  twitter_handle text,
  google_analytics_id text,
  google_search_console_id text,
  bing_webmaster_id text,
  robots_txt text,
  created_at timestamptz,
  updated_at timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT * FROM seo_settings
  ORDER BY created_at DESC
  LIMIT 1;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC 函数：更新全局 SEO 设置
CREATE OR REPLACE FUNCTION update_seo_settings(
  p_site_title text,
  p_site_description text,
  p_site_keywords text,
  p_site_author text,
  p_og_image text DEFAULT NULL,
  p_twitter_handle text DEFAULT NULL,
  p_google_analytics_id text DEFAULT NULL,
  p_google_search_console_id text DEFAULT NULL,
  p_bing_webmaster_id text DEFAULT NULL,
  p_robots_txt text DEFAULT NULL
)
RETURNS void AS $$
BEGIN
  UPDATE seo_settings
  SET
    site_title = p_site_title,
    site_description = p_site_description,
    site_keywords = p_site_keywords,
    site_author = p_site_author,
    og_image = COALESCE(p_og_image, og_image),
    twitter_handle = COALESCE(p_twitter_handle, twitter_handle),
    google_analytics_id = COALESCE(p_google_analytics_id, google_analytics_id),
    google_search_console_id = COALESCE(p_google_search_console_id, google_search_console_id),
    bing_webmaster_id = COALESCE(p_bing_webmaster_id, bing_webmaster_id),
    robots_txt = COALESCE(p_robots_txt, robots_txt),
    updated_at = now()
  WHERE id = '00000000-0000-0000-0000-000000000001';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC 函数：获取页面 SEO 设置
CREATE OR REPLACE FUNCTION get_page_seo(p_page_path text)
RETURNS TABLE (
  id uuid,
  page_path text,
  page_title text,
  page_description text,
  page_keywords text,
  og_title text,
  og_description text,
  og_image text,
  twitter_title text,
  twitter_description text,
  twitter_image text,
  canonical_url text,
  noindex boolean,
  nofollow boolean,
  priority decimal,
  change_frequency text,
  created_at timestamptz,
  updated_at timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT * FROM page_seo
  WHERE page_seo.page_path = p_page_path;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC 函数：创建或更新页面 SEO 设置
CREATE OR REPLACE FUNCTION upsert_page_seo(
  p_page_path text,
  p_page_title text DEFAULT NULL,
  p_page_description text DEFAULT NULL,
  p_page_keywords text DEFAULT NULL,
  p_og_title text DEFAULT NULL,
  p_og_description text DEFAULT NULL,
  p_og_image text DEFAULT NULL,
  p_twitter_title text DEFAULT NULL,
  p_twitter_description text DEFAULT NULL,
  p_twitter_image text DEFAULT NULL,
  p_canonical_url text DEFAULT NULL,
  p_noindex boolean DEFAULT false,
  p_nofollow boolean DEFAULT false,
  p_priority decimal DEFAULT 0.5,
  p_change_frequency text DEFAULT 'weekly'
)
RETURNS void AS $$
BEGIN
  INSERT INTO page_seo (
    page_path,
    page_title,
    page_description,
    page_keywords,
    og_title,
    og_description,
    og_image,
    twitter_title,
    twitter_description,
    twitter_image,
    canonical_url,
    noindex,
    nofollow,
    priority,
    change_frequency
  ) VALUES (
    p_page_path,
    p_page_title,
    p_page_description,
    p_page_keywords,
    p_og_title,
    p_og_description,
    p_og_image,
    p_twitter_title,
    p_twitter_description,
    p_twitter_image,
    p_canonical_url,
    p_noindex,
    p_nofollow,
    p_priority,
    p_change_frequency
  )
  ON CONFLICT (page_path) DO UPDATE SET
    page_title = COALESCE(EXCLUDED.page_title, page_seo.page_title),
    page_description = COALESCE(EXCLUDED.page_description, page_seo.page_description),
    page_keywords = COALESCE(EXCLUDED.page_keywords, page_seo.page_keywords),
    og_title = COALESCE(EXCLUDED.og_title, page_seo.og_title),
    og_description = COALESCE(EXCLUDED.og_description, page_seo.og_description),
    og_image = COALESCE(EXCLUDED.og_image, page_seo.og_image),
    twitter_title = COALESCE(EXCLUDED.twitter_title, page_seo.twitter_title),
    twitter_description = COALESCE(EXCLUDED.twitter_description, page_seo.twitter_description),
    twitter_image = COALESCE(EXCLUDED.twitter_image, page_seo.twitter_image),
    canonical_url = COALESCE(EXCLUDED.canonical_url, page_seo.canonical_url),
    noindex = EXCLUDED.noindex,
    nofollow = EXCLUDED.nofollow,
    priority = EXCLUDED.priority,
    change_frequency = EXCLUDED.change_frequency,
    updated_at = now();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC 函数：获取所有页面 SEO 设置（用于生成站点地图）
CREATE OR REPLACE FUNCTION get_all_page_seo()
RETURNS TABLE (
  page_path text,
  page_title text,
  priority decimal,
  change_frequency text,
  updated_at timestamptz,
  noindex boolean
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    page_seo.page_path,
    page_seo.page_title,
    page_seo.priority,
    page_seo.change_frequency,
    page_seo.updated_at,
    page_seo.noindex
  FROM page_seo
  WHERE page_seo.noindex = false
  ORDER BY page_seo.priority DESC, page_seo.page_path ASC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC 函数：获取所有启用的重定向规则
CREATE OR REPLACE FUNCTION get_active_redirects()
RETURNS TABLE (
  from_path text,
  to_path text,
  redirect_type integer
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    redirects.from_path,
    redirects.to_path,
    redirects.redirect_type
  FROM redirects
  WHERE redirects.is_active = true
  ORDER BY redirects.from_path ASC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;/*
# 修复 update_seo_settings 函数

## 问题
当前的 update_seo_settings 函数使用 COALESCE，导致无法将字段更新为空字符串或 NULL。
例如：COALESCE(p_og_image, og_image) 会在 p_og_image 为 NULL 时保留原值。

## 解决方案
修改函数逻辑，允许将可选字段更新为空字符串或 NULL。
- 如果参数为空字符串 ''，则更新为 NULL
- 如果参数为 NULL，则保持原值不变
- 如果参数有值，则更新为新值

## 修改内容
重新创建 update_seo_settings 函数，使用更灵活的更新逻辑
*/

-- 删除旧函数
DROP FUNCTION IF EXISTS update_seo_settings(text, text, text, text, text, text, text, text, text, text);

-- 重新创建函数，修复更新逻辑
CREATE OR REPLACE FUNCTION update_seo_settings(
  p_site_title text,
  p_site_description text,
  p_site_keywords text,
  p_site_author text,
  p_og_image text DEFAULT NULL,
  p_twitter_handle text DEFAULT NULL,
  p_google_analytics_id text DEFAULT NULL,
  p_google_search_console_id text DEFAULT NULL,
  p_bing_webmaster_id text DEFAULT NULL,
  p_robots_txt text DEFAULT NULL
)
RETURNS void AS $$
BEGIN
  UPDATE seo_settings
  SET
    site_title = p_site_title,
    site_description = p_site_description,
    site_keywords = p_site_keywords,
    site_author = p_site_author,
    -- 如果传入空字符串，转换为 NULL；如果传入 NULL，保持原值
    og_image = CASE 
      WHEN p_og_image = '' THEN NULL 
      WHEN p_og_image IS NOT NULL THEN p_og_image 
      ELSE og_image 
    END,
    twitter_handle = CASE 
      WHEN p_twitter_handle = '' THEN NULL 
      WHEN p_twitter_handle IS NOT NULL THEN p_twitter_handle 
      ELSE twitter_handle 
    END,
    google_analytics_id = CASE 
      WHEN p_google_analytics_id = '' THEN NULL 
      WHEN p_google_analytics_id IS NOT NULL THEN p_google_analytics_id 
      ELSE google_analytics_id 
    END,
    google_search_console_id = CASE 
      WHEN p_google_search_console_id = '' THEN NULL 
      WHEN p_google_search_console_id IS NOT NULL THEN p_google_search_console_id 
      ELSE google_search_console_id 
    END,
    bing_webmaster_id = CASE 
      WHEN p_bing_webmaster_id = '' THEN NULL 
      WHEN p_bing_webmaster_id IS NOT NULL THEN p_bing_webmaster_id 
      ELSE bing_webmaster_id 
    END,
    robots_txt = CASE 
      WHEN p_robots_txt = '' THEN 'User-agent: *
Allow: /
Sitemap: /sitemap.xml'
      WHEN p_robots_txt IS NOT NULL THEN p_robots_txt 
      ELSE robots_txt 
    END,
    updated_at = now()
  WHERE id = '00000000-0000-0000-0000-000000000001';
  
  -- 如果没有记录，插入默认记录
  IF NOT FOUND THEN
    INSERT INTO seo_settings (
      id,
      site_title,
      site_description,
      site_keywords,
      site_author,
      og_image,
      twitter_handle,
      google_analytics_id,
      google_search_console_id,
      bing_webmaster_id,
      robots_txt
    ) VALUES (
      '00000000-0000-0000-0000-000000000001',
      p_site_title,
      p_site_description,
      p_site_keywords,
      p_site_author,
      NULLIF(p_og_image, ''),
      NULLIF(p_twitter_handle, ''),
      NULLIF(p_google_analytics_id, ''),
      NULLIF(p_google_search_console_id, ''),
      NULLIF(p_bing_webmaster_id, ''),
      COALESCE(NULLIF(p_robots_txt, ''), 'User-agent: *
Allow: /
Sitemap: /sitemap.xml')
    );
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
/*
# Translate Video Module Data to English

## Purpose
Translate all Chinese content in the video module to English, including:
- Video categories (name, slug, description)
- Sample video data (title, description, content)
- Policy comments

## Changes
1. Update video category names and descriptions
2. Update sample video data
3. Update policy comments

## Tables Affected
- categories (video type)
- videos (sample data)
*/

-- Update video categories to English
UPDATE categories 
SET 
  name = 'Tutorial Videos',
  slug = 'tutorial-videos',
  description = 'Various tutorials and training videos'
WHERE name = '教程视频' AND type = 'video';

UPDATE categories 
SET 
  name = 'Product Demos',
  slug = 'product-demos',
  description = 'Product feature demonstration videos'
WHERE name = '产品演示' AND type = 'video';

UPDATE categories 
SET 
  name = 'Event Reviews',
  slug = 'event-reviews',
  description = 'Event and conference review videos'
WHERE name = '活动回顾' AND type = 'video';

-- Update sample video data to English
UPDATE videos 
SET 
  title = 'Sample Tutorial Video',
  description = 'This is a sample tutorial video',
  content = '<p>This is a detailed introduction to the sample tutorial video.</p><p>Video content includes:</p><ul><li>Basic knowledge explanation</li><li>Practical demonstration</li><li>Common questions and answers</li></ul>'
WHERE title = '示例教程视频';

-- Update policy comments to English
COMMENT ON POLICY "公开可读已发布的视频" ON videos IS 'Allow everyone (including anonymous users and members) to view published videos';/*
# Add Home Hero Icon Setting

## Purpose
Add a configurable setting for the home page hero section icon/image.
This allows administrators to customize the visual element displayed on the home page.

## Changes
1. Add home_hero_icon setting to site_settings table
2. Default value is empty (will use default Wrench icon if not set)

## Tables Affected
- site_settings (new row)
*/

-- Add home hero icon setting
INSERT INTO site_settings (key, value, description)
VALUES (
  'home_hero_icon',
  '',
  'Home page hero section icon/image URL. Leave empty to use default icon.'
)
ON CONFLICT (key) DO NOTHING;-- 创建验证文件表
CREATE TABLE IF NOT EXISTS verification_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  filename TEXT NOT NULL UNIQUE,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by TEXT NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_verification_files_filename ON verification_files(filename);
CREATE INDEX IF NOT EXISTS idx_verification_files_created_at ON verification_files(created_at DESC);

-- 启用RLS
ALTER TABLE verification_files ENABLE ROW LEVEL SECURITY;

-- 创建策略（仅管理员可访问）
CREATE POLICY "管理员可以查看所有验证文件"
  ON verification_files
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "管理员可以插入验证文件"
  ON verification_files
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "管理员可以更新验证文件"
  ON verification_files
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "管理员可以删除验证文件"
  ON verification_files
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- 添加注释
COMMENT ON TABLE verification_files IS '微信公众号域名验证文件表';
COMMENT ON COLUMN verification_files.filename IS '文件名（例如：MP_verify_xxxxx.txt）';
COMMENT ON COLUMN verification_files.content IS '文件内容';
COMMENT ON COLUMN verification_files.created_by IS '创建者';
COMMENT ON COLUMN verification_files.updated_at IS '更新时间';-- 删除现有的RLS策略
DROP POLICY IF EXISTS "管理员可以查看所有验证文件" ON verification_files;
DROP POLICY IF EXISTS "管理员可以插入验证文件" ON verification_files;
DROP POLICY IF EXISTS "管理员可以更新验证文件" ON verification_files;
DROP POLICY IF EXISTS "管理员可以删除验证文件" ON verification_files;

-- 创建新的策略：公开读取，管理员管理
CREATE POLICY "任何人都可以读取验证文件"
  ON verification_files
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "管理员可以插入验证文件"
  ON verification_files
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "管理员可以更新验证文件"
  ON verification_files
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "管理员可以删除验证文件"
  ON verification_files
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );-- 为 verification_files 表添加 file_type 字段，支持 txt 和 html 格式
ALTER TABLE verification_files 
ADD COLUMN IF NOT EXISTS file_type TEXT DEFAULT 'txt' CHECK (file_type IN ('txt', 'html'));

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_verification_files_file_type ON verification_files(file_type);

-- 添加注释
COMMENT ON COLUMN verification_files.file_type IS '文件类型：txt 或 html';

-- 更新表注释，扩展支持范围
COMMENT ON TABLE verification_files IS '搜索引擎验证文件表，支持Google、Bing、Baidu、360、Sogou等所有搜索引擎';
COMMENT ON COLUMN verification_files.filename IS '文件名（例如：google123456.html、MP_verify_xxxxx.txt、BingSiteAuth.xml等）';

-- 更新所有测试会员的密码为 lun123456
-- 只更新邮箱以@miaoda.com结尾的测试账号

-- 批量更新auth.users表中的密码
UPDATE auth.users
SET 
  encrypted_password = crypt('lun123456', gen_salt('bf')),
  updated_at = now()
WHERE email LIKE '%@miaoda.com' 
  AND email != 'ifixes@miaoda.com'
  AND id IN (
    SELECT id FROM profiles WHERE role = 'member'
  );

-- 记录更新日志
DO $$
DECLARE
  v_updated_count int;
BEGIN
  -- 统计更新的账号数量
  SELECT COUNT(*) INTO v_updated_count
  FROM auth.users
  WHERE email LIKE '%@miaoda.com' 
    AND email != 'ifixes@miaoda.com'
    AND id IN (
      SELECT id FROM profiles WHERE role = 'member'
    );
  
  RAISE NOTICE '========================================';
  RAISE NOTICE '✅ 密码更新完成！';
  RAISE NOTICE '- 更新账号数量: %', v_updated_count;
  RAISE NOTICE '- 新密码: lun123456';
  RAISE NOTICE '- 用户名格式: 点号(.)已替换为字母i';
  RAISE NOTICE '========================================';
END $$;

-- 修复邮箱域名：将 @miaodaicom 改回 @miaoda.com
-- 只修复那些域名被错误替换的账号

-- 更新profiles表
UPDATE profiles
SET 
  email = REPLACE(email, '@miaodaicom', '@miaoda.com'),
  updated_at = now()
WHERE email LIKE '%@miaodaicom';

-- 更新auth.users表
UPDATE auth.users
SET 
  email = REPLACE(email, '@miaodaicom', '@miaoda.com'),
  updated_at = now()
WHERE email LIKE '%@miaodaicom';

-- 验证修复结果
DO $$
DECLARE
  v_fixed_count int;
  v_remaining_wrong int;
BEGIN
  -- 统计修复的账号数量
  SELECT COUNT(*) INTO v_fixed_count
  FROM profiles
  WHERE email LIKE '%@miaoda.com' AND username LIKE '%i%';
  
  -- 检查是否还有错误的域名
  SELECT COUNT(*) INTO v_remaining_wrong
  FROM profiles
  WHERE email LIKE '%@miaodaicom';
  
  RAISE NOTICE '========================================';
  RAISE NOTICE '✅ 邮箱域名修复完成！';
  RAISE NOTICE '- 正确邮箱数量: %', v_fixed_count;
  RAISE NOTICE '- 错误邮箱数量: %', v_remaining_wrong;
  RAISE NOTICE '========================================';
END $$;
-- 为 videos 表添加 SEO 字段
ALTER TABLE videos 
ADD COLUMN IF NOT EXISTS seo_title TEXT,
ADD COLUMN IF NOT EXISTS seo_description TEXT,
ADD COLUMN IF NOT EXISTS seo_keywords TEXT;

-- 添加注释
COMMENT ON COLUMN videos.seo_title IS 'SEO 标题';
COMMENT ON COLUMN videos.seo_description IS 'SEO 描述';
COMMENT ON COLUMN videos.seo_keywords IS 'SEO 关键词';-- 修复视频上传存储桶配置
-- 1. 更新视频封面存储桶大小限制从 2MB 到 5MB
UPDATE storage.buckets 
SET file_size_limit = 5242880  -- 5MB in bytes
WHERE id = 'app-7fshtpomqha9_video_covers';

-- 2. 确保视频存储桶支持更多视频格式
UPDATE storage.buckets 
SET allowed_mime_types = ARRAY[
  'video/mp4', 
  'video/webm', 
  'video/ogg', 
  'video/quicktime',  -- MOV
  'video/x-msvideo',  -- AVI
  'video/x-matroska', -- MKV
  'video/mpeg',
  'video/3gpp',
  'video/x-flv'
]
WHERE id = 'app-7fshtpomqha9_videos';

-- 3. 确保封面存储桶支持更多图片格式
UPDATE storage.buckets 
SET allowed_mime_types = ARRAY[
  'image/png', 
  'image/jpeg', 
  'image/jpg', 
  'image/webp',
  'image/gif',
  'image/bmp'
]
WHERE id = 'app-7fshtpomqha9_video_covers';

-- 添加注释
COMMENT ON TABLE storage.buckets IS '存储桶配置表';
COMMENT ON COLUMN storage.buckets.file_size_limit IS '文件大小限制（字节）';
COMMENT ON COLUMN storage.buckets.allowed_mime_types IS '允许的MIME类型数组';-- 将视频存储桶大小限制提升到最大值 5GB
-- Supabase 支持的最大单文件大小为 5GB

-- 更新视频存储桶大小限制
UPDATE storage.buckets 
SET file_size_limit = 5368709120  -- 5GB = 5 * 1024 * 1024 * 1024 bytes
WHERE id = 'app-7fshtpomqha9_videos';

-- 添加注释说明
COMMENT ON TABLE storage.buckets IS '存储桶配置表 - 视频存储桶已设置为最大 5GB';

-- 验证更新
SELECT 
  id,
  ROUND(file_size_limit::numeric / 1024 / 1024 / 1024, 2) as size_limit_gb
FROM storage.buckets 
WHERE id = 'app-7fshtpomqha9_videos';-- 将视频存储桶大小限制提升到 50GB（Supabase PRO 版支持）
-- PRO 版实际支持最大 50GB 单文件上传

-- 更新视频存储桶大小限制到 50GB
UPDATE storage.buckets 
SET file_size_limit = 53687091200  -- 50GB = 50 * 1024 * 1024 * 1024 bytes
WHERE id = 'app-7fshtpomqha9_videos';

-- 同时提升 CMS 视频存储桶到 50GB
UPDATE storage.buckets 
SET file_size_limit = 53687091200  -- 50GB
WHERE id = 'app-7fshtpomqha9_cms_videos';

-- 添加注释
COMMENT ON TABLE storage.buckets IS '存储桶配置 - PRO 版支持最大 50GB 单文件';

-- 验证更新
SELECT 
  id,
  ROUND(file_size_limit::numeric / 1024 / 1024 / 1024, 2) as "大小限制(GB)"
FROM storage.buckets 
WHERE id LIKE '%video%'
ORDER BY id;-- 创建微信配置表
CREATE TABLE IF NOT EXISTS wechat_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL CHECK (type IN ('miniprogram', 'official_account')),
  name TEXT NOT NULL,
  app_id TEXT NOT NULL,
  app_secret TEXT NOT NULL,
  token TEXT,
  encoding_aes_key TEXT,
  config_data JSONB DEFAULT '{}'::jsonb,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES auth.users(id),
  UNIQUE(type, app_id)
);

-- 添加注释
COMMENT ON TABLE wechat_configs IS '微信配置表 - 存储小程序和公众号配置';
COMMENT ON COLUMN wechat_configs.type IS '类型: miniprogram=小程序, official_account=公众号';
COMMENT ON COLUMN wechat_configs.name IS '配置名称';
COMMENT ON COLUMN wechat_configs.app_id IS '微信 AppID';
COMMENT ON COLUMN wechat_configs.app_secret IS '微信 AppSecret';
COMMENT ON COLUMN wechat_configs.token IS '微信 Token';
COMMENT ON COLUMN wechat_configs.encoding_aes_key IS '消息加密密钥';
COMMENT ON COLUMN wechat_configs.config_data IS '其他配置数据(JSON)';
COMMENT ON COLUMN wechat_configs.is_active IS '是否启用';

-- 创建索引
CREATE INDEX idx_wechat_configs_type ON wechat_configs(type);
CREATE INDEX idx_wechat_configs_is_active ON wechat_configs(is_active);
CREATE INDEX idx_wechat_configs_created_at ON wechat_configs(created_at DESC);

-- 创建更新时间触发器
CREATE OR REPLACE FUNCTION update_wechat_configs_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_wechat_configs_updated_at
  BEFORE UPDATE ON wechat_configs
  FOR EACH ROW
  EXECUTE FUNCTION update_wechat_configs_updated_at();

-- RLS 策略
ALTER TABLE wechat_configs ENABLE ROW LEVEL SECURITY;

-- 只有 admin 可以查看
CREATE POLICY "Admin can view wechat configs"
  ON wechat_configs
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'admin'
    )
  );

-- 只有 admin 可以插入
CREATE POLICY "Admin can insert wechat configs"
  ON wechat_configs
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'admin'
    )
  );

-- 只有 admin 可以更新
CREATE POLICY "Admin can update wechat configs"
  ON wechat_configs
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'admin'
    )
  );

-- 只有 admin 可以删除
CREATE POLICY "Admin can delete wechat configs"
  ON wechat_configs
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'admin'
    )
  );

-- 插入示例数据
INSERT INTO wechat_configs (type, name, app_id, app_secret, token, encoding_aes_key, config_data, is_active)
VALUES 
  (
    'miniprogram',
    '主小程序',
    'wx1234567890abcdef',
    'your_miniprogram_secret_here',
    'your_token_here',
    'your_encoding_aes_key_here',
    '{
      "description": "主要的微信小程序配置",
      "version": "1.0.0",
      "permissions": ["userInfo", "location", "payment"]
    }'::jsonb,
    true
  ),
  (
    'official_account',
    '主公众号',
    'wx0987654321fedcba',
    'your_official_account_secret_here',
    'your_token_here',
    'your_encoding_aes_key_here',
    '{
      "description": "主要的微信公众号配置",
      "type": "service",
      "verified": true,
      "permissions": ["message", "menu", "user"]
    }'::jsonb,
    true
  )
ON CONFLICT (type, app_id) DO NOTHING;-- Create or replace function to sync email from auth.users to profiles
CREATE OR REPLACE FUNCTION sync_profile_email()
RETURNS TRIGGER AS $$
BEGIN
  -- Update profiles.email when auth.users.email changes
  UPDATE profiles
  SET email = NEW.email,
      updated_at = now()
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing trigger if exists
DROP TRIGGER IF EXISTS sync_profile_email_trigger ON auth.users;

-- Create trigger on auth.users to sync email to profiles
CREATE TRIGGER sync_profile_email_trigger
  AFTER UPDATE OF email ON auth.users
  FOR EACH ROW
  WHEN (OLD.email IS DISTINCT FROM NEW.email)
  EXECUTE FUNCTION sync_profile_email();

-- Add comment
COMMENT ON FUNCTION sync_profile_email() IS 'Automatically sync email from auth.users to profiles table when email is updated';-- 创建翻译缓存表
CREATE TABLE IF NOT EXISTS translation_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_text TEXT NOT NULL,
  source_lang VARCHAR(10) NOT NULL DEFAULT 'en',
  target_lang VARCHAR(10) NOT NULL,
  translated_text TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  hit_count INTEGER DEFAULT 1,
  UNIQUE(source_text, source_lang, target_lang)
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_translation_cache_lookup 
ON translation_cache(source_text, source_lang, target_lang);

CREATE INDEX IF NOT EXISTS idx_translation_cache_created 
ON translation_cache(created_at DESC);

-- 创建翻译统计表
CREATE TABLE IF NOT EXISTS translation_stats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  source_lang VARCHAR(10) NOT NULL,
  target_lang VARCHAR(10) NOT NULL,
  request_count INTEGER DEFAULT 0,
  character_count BIGINT DEFAULT 0,
  cache_hit_count INTEGER DEFAULT 0,
  api_call_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(date, source_lang, target_lang)
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_translation_stats_date 
ON translation_stats(date DESC);

-- 启用 RLS
ALTER TABLE translation_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE translation_stats ENABLE ROW LEVEL SECURITY;

-- 翻译缓存表策略：所有人可读，只有认证用户可写
CREATE POLICY "翻译缓存公开可读"
ON translation_cache FOR SELECT
TO public
USING (true);

CREATE POLICY "认证用户可写翻译缓存"
ON translation_cache FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "认证用户可更新翻译缓存"
ON translation_cache FOR UPDATE
TO authenticated
USING (true);

-- 翻译统计表策略：只有管理员可访问
CREATE POLICY "管理员可读翻译统计"
ON translation_stats FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

CREATE POLICY "管理员可写翻译统计"
ON translation_stats FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

CREATE POLICY "管理员可更新翻译统计"
ON translation_stats FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

-- 添加注释
COMMENT ON TABLE translation_cache IS '翻译缓存表，存储已翻译的文本';
COMMENT ON TABLE translation_stats IS '翻译统计表，记录翻译使用情况';

-- 创建更新 updated_at 的触发器
CREATE OR REPLACE FUNCTION update_translation_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_translation_cache_updated_at
  BEFORE UPDATE ON translation_cache
  FOR EACH ROW
  EXECUTE FUNCTION update_translation_updated_at();

CREATE TRIGGER update_translation_stats_updated_at
  BEFORE UPDATE ON translation_stats
  FOR EACH ROW
  EXECUTE FUNCTION update_translation_updated_at();-- 创建增加缓存命中次数的函数
CREATE OR REPLACE FUNCTION increment_cache_hit(
  p_source_text TEXT,
  p_source_lang VARCHAR(10),
  p_target_lang VARCHAR(10)
)
RETURNS VOID AS $$
BEGIN
  UPDATE translation_cache
  SET hit_count = hit_count + 1,
      updated_at = now()
  WHERE source_text = p_source_text
    AND source_lang = p_source_lang
    AND target_lang = p_target_lang;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建更新翻译统计的函数
CREATE OR REPLACE FUNCTION update_translation_stats(
  p_source_lang VARCHAR(10),
  p_target_lang VARCHAR(10),
  p_request_count INTEGER,
  p_character_count BIGINT,
  p_cache_hit_count INTEGER,
  p_api_call_count INTEGER
)
RETURNS VOID AS $$
BEGIN
  INSERT INTO translation_stats (
    date,
    source_lang,
    target_lang,
    request_count,
    character_count,
    cache_hit_count,
    api_call_count
  )
  VALUES (
    CURRENT_DATE,
    p_source_lang,
    p_target_lang,
    p_request_count,
    p_character_count,
    p_cache_hit_count,
    p_api_call_count
  )
  ON CONFLICT (date, source_lang, target_lang)
  DO UPDATE SET
    request_count = translation_stats.request_count + p_request_count,
    character_count = translation_stats.character_count + p_character_count,
    cache_hit_count = translation_stats.cache_hit_count + p_cache_hit_count,
    api_call_count = translation_stats.api_call_count + p_api_call_count,
    updated_at = now();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建获取翻译统计的函数
CREATE OR REPLACE FUNCTION get_translation_stats(
  p_start_date DATE DEFAULT CURRENT_DATE - INTERVAL '30 days',
  p_end_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE (
  date DATE,
  source_lang VARCHAR(10),
  target_lang VARCHAR(10),
  request_count INTEGER,
  character_count BIGINT,
  cache_hit_count INTEGER,
  api_call_count INTEGER,
  cache_hit_rate NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    ts.date,
    ts.source_lang,
    ts.target_lang,
    ts.request_count,
    ts.character_count,
    ts.cache_hit_count,
    ts.api_call_count,
    CASE
      WHEN ts.request_count > 0 THEN
        ROUND((ts.cache_hit_count::NUMERIC / ts.request_count::NUMERIC) * 100, 2)
      ELSE 0
    END AS cache_hit_rate
  FROM translation_stats ts
  WHERE ts.date BETWEEN p_start_date AND p_end_date
  ORDER BY ts.date DESC, ts.request_count DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建清理过期缓存的函数
CREATE OR REPLACE FUNCTION clean_expired_translation_cache(
  p_days_to_keep INTEGER DEFAULT 90
)
RETURNS INTEGER AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  DELETE FROM translation_cache
  WHERE updated_at < (CURRENT_DATE - (p_days_to_keep || ' days')::INTERVAL);
  
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建获取缓存统计的函数
CREATE OR REPLACE FUNCTION get_cache_statistics()
RETURNS TABLE (
  total_entries BIGINT,
  total_size_mb NUMERIC,
  most_used_pairs JSONB,
  cache_by_language JSONB
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    COUNT(*)::BIGINT AS total_entries,
    ROUND((pg_total_relation_size('translation_cache')::NUMERIC / 1024 / 1024), 2) AS total_size_mb,
    (
      SELECT jsonb_agg(
        jsonb_build_object(
          'source_lang', source_lang,
          'target_lang', target_lang,
          'count', count,
          'total_hits', total_hits
        )
      )
      FROM (
        SELECT
          source_lang,
          target_lang,
          COUNT(*) AS count,
          SUM(hit_count) AS total_hits
        FROM translation_cache
        GROUP BY source_lang, target_lang
        ORDER BY SUM(hit_count) DESC
        LIMIT 10
      ) top_pairs
    ) AS most_used_pairs,
    (
      SELECT jsonb_object_agg(
        target_lang,
        count
      )
      FROM (
        SELECT
          target_lang,
          COUNT(*) AS count
        FROM translation_cache
        GROUP BY target_lang
        ORDER BY COUNT(*) DESC
      ) lang_counts
    ) AS cache_by_language
  FROM translation_cache;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 添加注释
COMMENT ON FUNCTION increment_cache_hit IS '增加翻译缓存命中次数';
COMMENT ON FUNCTION update_translation_stats IS '更新翻译统计数据';
COMMENT ON FUNCTION get_translation_stats IS '获取翻译统计数据';
COMMENT ON FUNCTION clean_expired_translation_cache IS '清理过期的翻译缓存';
COMMENT ON FUNCTION get_cache_statistics IS '获取缓存统计信息';
-- 删除翻译相关的表
DROP TABLE IF EXISTS translation_stats CASCADE;
DROP TABLE IF EXISTS translation_cache CASCADE;
DROP TABLE IF EXISTS translations CASCADE;

-- 翊鸢化工产品表
CREATE TABLE IF NOT EXISTS yiyuan_products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_zh TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description_zh TEXT,
  description_en TEXT,
  image_url TEXT,
  specifications_zh TEXT,
  specifications_en TEXT,
  features_zh TEXT[],
  features_en TEXT[],
  applications_zh TEXT[],
  applications_en TEXT[],
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 翊鸢化工页面内容表（支持多语言）
CREATE TABLE IF NOT EXISTS yiyuan_content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  section_key TEXT NOT NULL UNIQUE,
  title_zh TEXT,
  title_en TEXT,
  content_zh TEXT,
  content_en TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 翊鸢化工防伪验证说明表（支持多语言）
CREATE TABLE IF NOT EXISTS yiyuan_verification_guide (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  step_number INTEGER NOT NULL,
  title_zh TEXT NOT NULL,
  title_en TEXT NOT NULL,
  description_zh TEXT,
  description_en TEXT,
  image_url TEXT,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_yiyuan_products_order ON yiyuan_products(display_order);
CREATE INDEX IF NOT EXISTS idx_yiyuan_products_active ON yiyuan_products(is_active);
CREATE INDEX IF NOT EXISTS idx_yiyuan_verification_order ON yiyuan_verification_guide(display_order);

-- 插入初始数据
INSERT INTO yiyuan_content (section_key, title_zh, title_en, content_zh, content_en) VALUES
('hero', '翊鸢化工', 'Yiyuan Chemical', '专业化工产品供应商，致力于为客户提供高品质的化工产品和解决方案', 'Professional chemical product supplier, committed to providing high-quality chemical products and solutions to customers'),
('about', '关于我们', 'About Us', '翊鸢化工是一家专注于化工产品研发、生产和销售的现代化企业。我们拥有先进的生产设备和专业的技术团队，为客户提供优质的产品和服务。', 'Yiyuan Chemical is a modern enterprise focusing on the research, production and sales of chemical products. We have advanced production equipment and professional technical team to provide customers with high-quality products and services.'),
('verification_intro', '产品防伪验证', 'Product Anti-counterfeiting Verification', '为保障您的权益，我们为每件产品提供唯一的防伪码。请按照以下步骤进行验证：', 'To protect your rights, we provide a unique anti-counterfeiting code for each product. Please follow the steps below to verify:')
ON CONFLICT (section_key) DO NOTHING;

INSERT INTO yiyuan_verification_guide (step_number, title_zh, title_en, description_zh, description_en, display_order) VALUES
(1, '找到防伪标签', 'Find the Anti-counterfeiting Label', '在产品包装上找到防伪标签，标签上印有唯一的防伪码', 'Find the anti-counterfeiting label on the product packaging, which has a unique anti-counterfeiting code', 1),
(2, '刮开涂层', 'Scratch the Coating', '轻轻刮开防伪标签上的涂层，露出防伪码', 'Gently scratch the coating on the anti-counterfeiting label to reveal the anti-counterfeiting code', 2),
(3, '输入验证码', 'Enter the Verification Code', '在验证页面输入防伪码，点击验证按钮', 'Enter the anti-counterfeiting code on the verification page and click the verify button', 3),
(4, '查看验证结果', 'View Verification Result', '系统将显示产品信息和验证结果，首次验证显示"正品"，多次验证请谨慎', 'The system will display product information and verification results. The first verification shows "Genuine", please be cautious about multiple verifications', 4);

INSERT INTO yiyuan_products (name_zh, name_en, description_zh, description_en, specifications_zh, specifications_en, features_zh, features_en, applications_zh, applications_en, display_order) VALUES
('工业级乙醇', 'Industrial Grade Ethanol', '高纯度工业级乙醇，适用于各种工业应用', 'High purity industrial grade ethanol, suitable for various industrial applications', '纯度：≥99.5%
包装：200L/桶
储存：阴凉干燥处', 'Purity: ≥99.5%
Packaging: 200L/drum
Storage: Cool and dry place', 
ARRAY['高纯度', '低杂质', '稳定性好', '符合国家标准'], 
ARRAY['High purity', 'Low impurity', 'Good stability', 'Meets national standards'],
ARRAY['溶剂', '清洗剂', '化工原料', '医药中间体'],
ARRAY['Solvent', 'Cleaning agent', 'Chemical raw material', 'Pharmaceutical intermediate'],
1),
('精细化工助剂', 'Fine Chemical Additives', '专业的化工助剂产品，提升产品性能', 'Professional chemical additive products to improve product performance', '类型：多功能助剂
包装：25kg/袋
有效期：12个月', 'Type: Multifunctional additive
Packaging: 25kg/bag
Shelf life: 12 months',
ARRAY['高效能', '环保型', '易使用', '性价比高'],
ARRAY['High efficiency', 'Environmentally friendly', 'Easy to use', 'Cost-effective'],
ARRAY['涂料', '塑料', '橡胶', '纺织'],
ARRAY['Coatings', 'Plastics', 'Rubber', 'Textiles'],
2);

-- 设置 RLS 策略
ALTER TABLE yiyuan_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE yiyuan_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE yiyuan_verification_guide ENABLE ROW LEVEL SECURITY;

-- 公开读取权限
CREATE POLICY "Allow public read yiyuan_products" ON yiyuan_products FOR SELECT USING (true);
CREATE POLICY "Allow public read yiyuan_content" ON yiyuan_content FOR SELECT USING (true);
CREATE POLICY "Allow public read yiyuan_verification_guide" ON yiyuan_verification_guide FOR SELECT USING (true);

-- 管理员完全权限
CREATE POLICY "Allow admin all yiyuan_products" ON yiyuan_products FOR ALL USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  )
);

CREATE POLICY "Allow admin all yiyuan_content" ON yiyuan_content FOR ALL USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  )
);

CREATE POLICY "Allow admin all yiyuan_verification_guide" ON yiyuan_verification_guide FOR ALL USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  )
);
-- 创建翊鸢化工生产商信息表
CREATE TABLE IF NOT EXISTS yiyuan_manufacturer (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  standard_zh TEXT NOT NULL DEFAULT '符合行业标准',
  standard_en TEXT NOT NULL DEFAULT 'Complies with industry standards',
  origin_zh TEXT NOT NULL DEFAULT '广东·深圳',
  origin_en TEXT NOT NULL DEFAULT 'Shenzhen, Guangdong',
  company_name_zh TEXT NOT NULL DEFAULT '义乌市颂祝浔礼文化创意有限公司',
  company_name_en TEXT NOT NULL DEFAULT 'Yiwu Songzhuxunli Cultural Creative Co., Ltd.',
  address_zh TEXT NOT NULL DEFAULT '浙江省义乌市甘三里街道春潮路11号3楼',
  address_en TEXT NOT NULL DEFAULT '3rd Floor, No. 11 Chunchao Road, Gansanli Street, Yiwu City, Zhejiang Province',
  website TEXT NOT NULL DEFAULT 'www.ifixes.com.cn',
  email TEXT NOT NULL DEFAULT 'dps@ifixes.com.cn',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 插入默认数据（只保留一条记录）
INSERT INTO yiyuan_manufacturer (
  standard_zh, standard_en,
  origin_zh, origin_en,
  company_name_zh, company_name_en,
  address_zh, address_en,
  website, email
) VALUES (
  '符合行业标准', 'Complies with industry standards',
  '广东·深圳', 'Shenzhen, Guangdong',
  '义乌市颂祝浔礼文化创意有限公司', 'Yiwu Songzhuxunli Cultural Creative Co., Ltd.',
  '浙江省义乌市甘三里街道春潮路11号3楼', '3rd Floor, No. 11 Chunchao Road, Gansanli Street, Yiwu City, Zhejiang Province',
  'www.ifixes.com.cn', 'dps@ifixes.com.cn'
);

-- 创建 RLS 策略
ALTER TABLE yiyuan_manufacturer ENABLE ROW LEVEL SECURITY;

-- 允许所有人查看
CREATE POLICY "允许所有人查看生产商信息"
  ON yiyuan_manufacturer
  FOR SELECT
  TO public
  USING (true);

-- 只允许管理员修改
CREATE POLICY "只允许管理员修改生产商信息"
  ON yiyuan_manufacturer
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'admin'
    )
  );

-- 添加注释
COMMENT ON TABLE yiyuan_manufacturer IS '翊鸢化工生产商信息表';
COMMENT ON COLUMN yiyuan_manufacturer.standard_zh IS '执行标准（中文）';
COMMENT ON COLUMN yiyuan_manufacturer.standard_en IS '执行标准（英文）';
COMMENT ON COLUMN yiyuan_manufacturer.origin_zh IS '产地（中文）';
COMMENT ON COLUMN yiyuan_manufacturer.origin_en IS '产地（英文）';
COMMENT ON COLUMN yiyuan_manufacturer.company_name_zh IS '公司名称（中文）';
COMMENT ON COLUMN yiyuan_manufacturer.company_name_en IS '公司名称（英文）';
COMMENT ON COLUMN yiyuan_manufacturer.address_zh IS '地址（中文）';
COMMENT ON COLUMN yiyuan_manufacturer.address_en IS '地址（英文）';
COMMENT ON COLUMN yiyuan_manufacturer.website IS '网址';
COMMENT ON COLUMN yiyuan_manufacturer.email IS '邮箱';-- 创建获取表统计信息的RPC函数
CREATE OR REPLACE FUNCTION get_table_statistics()
RETURNS TABLE (
  table_name TEXT,
  row_count BIGINT,
  total_size TEXT
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    t.tablename::TEXT,
    COALESCE(s.n_live_tup, 0) as row_count,
    pg_size_pretty(pg_total_relation_size(quote_ident(t.schemaname) || '.' || quote_ident(t.tablename)))::TEXT as total_size
  FROM pg_tables t
  LEFT JOIN pg_stat_user_tables s ON t.tablename = s.relname
  WHERE t.schemaname = 'public'
  ORDER BY t.tablename;
END;
$$;

-- 创建获取表结构的RPC函数
CREATE OR REPLACE FUNCTION get_table_structure(table_name_param TEXT)
RETURNS TABLE (
  create_statement TEXT
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    'CREATE TABLE ' || table_name_param || ' (' || E'\n  ' ||
    string_agg(
      column_name || ' ' || 
      CASE 
        WHEN data_type = 'character varying' THEN 
          'VARCHAR' || COALESCE('(' || character_maximum_length::TEXT || ')', '')
        WHEN data_type = 'timestamp with time zone' THEN 'TIMESTAMPTZ'
        WHEN data_type = 'timestamp without time zone' THEN 'TIMESTAMP'
        WHEN data_type = 'USER-DEFINED' THEN UPPER(udt_name)
        WHEN data_type = 'integer' THEN 'INTEGER'
        WHEN data_type = 'bigint' THEN 'BIGINT'
        WHEN data_type = 'boolean' THEN 'BOOLEAN'
        WHEN data_type = 'text' THEN 'TEXT'
        WHEN data_type = 'uuid' THEN 'UUID'
        WHEN data_type = 'numeric' THEN 'NUMERIC'
        WHEN data_type = 'date' THEN 'DATE'
        WHEN data_type = 'jsonb' THEN 'JSONB'
        WHEN data_type = 'json' THEN 'JSON'
        WHEN data_type = 'ARRAY' THEN udt_name
        ELSE UPPER(data_type)
      END ||
      CASE WHEN is_nullable = 'NO' THEN ' NOT NULL' ELSE '' END ||
      CASE 
        WHEN column_default IS NOT NULL AND column_default NOT LIKE 'nextval%' 
        THEN ' DEFAULT ' || column_default 
        ELSE '' 
      END,
      ',' || E'\n  ' ORDER BY ordinal_position
    ) || E'\n);' as create_statement
  FROM information_schema.columns
  WHERE table_schema = 'public' 
    AND table_name = table_name_param
  GROUP BY table_name;
END;
$$;

-- 授予执行权限
GRANT EXECUTE ON FUNCTION get_table_statistics() TO authenticated;
GRANT EXECUTE ON FUNCTION get_table_structure(TEXT) TO authenticated;

-- 添加注释
COMMENT ON FUNCTION get_table_statistics() IS '获取所有表的统计信息（行数、大小）';
COMMENT ON FUNCTION get_table_structure(TEXT) IS '获取指定表的CREATE TABLE语句';
/*
# 修复AI生成的会员账号格式

将格式从 firstname_lastname_数字 改为更真实的格式：
- 去掉末尾的数字
- 使用更自然的用户名格式

修复策略：
1. 提取firstname和lastname
2. 生成新的username格式（firstname.lastname 或 firstname + 随机字母）
3. 更新username和email
*/

-- 创建临时函数来生成随机字母
CREATE OR REPLACE FUNCTION random_letters(length int) 
RETURNS text AS $$
DECLARE
  chars text := 'abcdefghijklmnopqrstuvwxyz';
  result text := '';
  i int;
BEGIN
  FOR i IN 1..length LOOP
    result := result || substr(chars, floor(random() * length(chars) + 1)::int, 1);
  END LOOP;
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- 创建函数来修复用户名
CREATE OR REPLACE FUNCTION fix_member_username(old_username text)
RETURNS text AS $$
DECLARE
  parts text[];
  firstname text;
  lastname text;
  new_username text;
  suffix text;
  attempt int := 0;
BEGIN
  -- 分割用户名，提取firstname和lastname
  parts := string_to_array(old_username, '_');
  
  IF array_length(parts, 1) < 2 THEN
    RETURN old_username; -- 如果格式不符合预期，保持原样
  END IF;
  
  firstname := parts[1];
  lastname := parts[2];
  
  -- 尝试不同的格式，直到找到唯一的用户名
  LOOP
    IF attempt = 0 THEN
      -- 第一次尝试：firstname.lastname
      new_username := firstname || '.' || lastname;
    ELSIF attempt = 1 THEN
      -- 第二次尝试：firstname_lastname (不带数字)
      new_username := firstname || '_' || lastname;
    ELSIF attempt = 2 THEN
      -- 第三次尝试：firstnamelastname
      new_username := firstname || lastname;
    ELSIF attempt = 3 THEN
      -- 第四次尝试：firstname + lastname首字母
      new_username := firstname || substring(lastname, 1, 1);
    ELSIF attempt = 4 THEN
      -- 第五次尝试：firstname.lastname + 随机字母
      suffix := random_letters(2);
      new_username := firstname || '.' || lastname || suffix;
    ELSE
      -- 最后尝试：firstname.lastname + 随机字母（更长）
      suffix := random_letters(3);
      new_username := firstname || '.' || lastname || suffix;
    END IF;
    
    -- 检查是否已存在
    IF NOT EXISTS (SELECT 1 FROM profiles WHERE username = new_username) THEN
      RETURN new_username;
    END IF;
    
    attempt := attempt + 1;
    
    -- 防止无限循环
    IF attempt > 10 THEN
      -- 使用原用户名 + 随机字母
      RETURN old_username || random_letters(4);
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- 更新所有符合格式的会员账号
DO $$
DECLARE
  profile_record RECORD;
  new_username text;
  new_email text;
  updated_count int := 0;
BEGIN
  -- 遍历所有包含数字后缀的用户名
  FOR profile_record IN 
    SELECT id, username, email 
    FROM profiles 
    WHERE username ~ '_[0-9]+$'  -- 匹配以下划线+数字结尾的用户名
    AND email LIKE '%@miaoda.com'  -- 只处理测试账号
  LOOP
    -- 生成新的用户名
    new_username := fix_member_username(profile_record.username);
    new_email := new_username || '@miaoda.com';
    
    -- 更新profile表
    UPDATE profiles 
    SET 
      username = new_username,
      email = new_email,
      updated_at = now()
    WHERE id = profile_record.id;
    
    updated_count := updated_count + 1;
    
    -- 每100条记录输出一次进度
    IF updated_count % 100 = 0 THEN
      RAISE NOTICE '已更新 % 个会员账号...', updated_count;
    END IF;
  END LOOP;
  
  RAISE NOTICE '修复完成！共更新 % 个会员账号', updated_count;
END $$;

-- 清理临时函数
DROP FUNCTION IF EXISTS random_letters(int);
DROP FUNCTION IF EXISTS fix_member_username(text);

-- 验证结果
SELECT 
  '修复后的用户名示例' as description,
  username,
  email
FROM profiles 
WHERE email LIKE '%@miaoda.com'
ORDER BY created_at DESC
LIMIT 20;
/*
# 文章采集系统

创建文章采集系统所需的数据库表和函数，支持：
- 采集规则管理
- 采集历史记录
- 图片本地化
- 来源标注
*/

-- 创建采集规则表
CREATE TABLE IF NOT EXISTS scraper_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL, -- 规则名称
  description text, -- 规则描述
  source_url text NOT NULL, -- 源网站URL
  source_name text NOT NULL, -- 源网站名称
  
  -- 采集规则配置（CSS选择器或XPath）
  list_page_url text, -- 列表页URL（可选，用于批量采集）
  list_item_selector text, -- 列表项选择器
  article_url_selector text, -- 文章链接选择器
  
  -- 文章内容选择器
  title_selector text NOT NULL, -- 标题选择器
  content_selector text NOT NULL, -- 内容选择器
  excerpt_selector text, -- 摘要选择器
  cover_image_selector text, -- 封面图选择器
  author_selector text, -- 作者选择器
  publish_date_selector text, -- 发布日期选择器
  
  -- 采集配置
  category_id uuid REFERENCES categories(id), -- 默认分类
  auto_publish boolean DEFAULT false, -- 是否自动发布
  download_images boolean DEFAULT true, -- 是否下载图片到本地
  add_source_link boolean DEFAULT true, -- 是否添加来源链接
  
  -- 状态
  status text DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'testing')),
  last_run_at timestamptz, -- 最后运行时间
  success_count int DEFAULT 0, -- 成功采集数
  fail_count int DEFAULT 0, -- 失败采集数
  
  -- 元数据
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建采集历史表
CREATE TABLE IF NOT EXISTS scraper_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_id uuid REFERENCES scraper_rules(id) ON DELETE CASCADE,
  
  -- 采集信息
  source_url text NOT NULL, -- 源文章URL
  article_id uuid REFERENCES articles(id), -- 生成的文章ID
  
  -- 采集结果
  status text NOT NULL CHECK (status IN ('success', 'failed', 'processing')),
  error_message text, -- 错误信息
  
  -- 采集数据
  scraped_data jsonb, -- 采集到的原始数据
  images_downloaded int DEFAULT 0, -- 下载的图片数量
  
  -- 元数据
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_scraper_rules_status ON scraper_rules(status);
CREATE INDEX IF NOT EXISTS idx_scraper_rules_created_by ON scraper_rules(created_by);
CREATE INDEX IF NOT EXISTS idx_scraper_history_rule_id ON scraper_history(rule_id);
CREATE INDEX IF NOT EXISTS idx_scraper_history_status ON scraper_history(status);
CREATE INDEX IF NOT EXISTS idx_scraper_history_created_at ON scraper_history(created_at DESC);

-- 创建更新时间触发器
CREATE OR REPLACE FUNCTION update_scraper_rules_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_scraper_rules_updated_at
  BEFORE UPDATE ON scraper_rules
  FOR EACH ROW
  EXECUTE FUNCTION update_scraper_rules_updated_at();

-- 启用RLS
ALTER TABLE scraper_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE scraper_history ENABLE ROW LEVEL SECURITY;

-- 创建RLS策略
-- 管理员和编辑可以查看所有规则
CREATE POLICY "管理员和编辑可以查看采集规则"
  ON scraper_rules FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

-- 管理员和编辑可以创建规则
CREATE POLICY "管理员和编辑可以创建采集规则"
  ON scraper_rules FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

-- 管理员和编辑可以更新规则
CREATE POLICY "管理员和编辑可以更新采集规则"
  ON scraper_rules FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

-- 管理员可以删除规则
CREATE POLICY "管理员可以删除采集规则"
  ON scraper_rules FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- 采集历史策略
CREATE POLICY "管理员和编辑可以查看采集历史"
  ON scraper_history FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "系统可以插入采集历史"
  ON scraper_history FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- 创建统计函数
CREATE OR REPLACE FUNCTION get_scraper_stats()
RETURNS jsonb AS $$
DECLARE
  result jsonb;
BEGIN
  SELECT jsonb_build_object(
    'total_rules', COUNT(*),
    'active_rules', COUNT(*) FILTER (WHERE status = 'active'),
    'total_scraped', SUM(success_count),
    'total_failed', SUM(fail_count)
  ) INTO result
  FROM scraper_rules;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 插入示例采集规则
INSERT INTO scraper_rules (
  name,
  description,
  source_url,
  source_name,
  title_selector,
  content_selector,
  excerpt_selector,
  cover_image_selector,
  status,
  download_images,
  add_source_link
) VALUES (
  '示例采集规则',
  '这是一个示例采集规则，展示如何配置CSS选择器',
  'https://example.com',
  '示例网站',
  'h1.article-title',
  'div.article-content',
  'div.article-excerpt',
  'img.cover-image',
  'testing',
  true,
  true
) ON CONFLICT DO NOTHING;

COMMENT ON TABLE scraper_rules IS '文章采集规则配置表';
COMMENT ON TABLE scraper_history IS '文章采集历史记录表';
/*
# 增强文章采集系统 - 添加反爬虫配置

添加反爬虫配置字段和请求控制功能
*/

-- 添加反爬虫配置字段到scraper_rules表
ALTER TABLE scraper_rules ADD COLUMN IF NOT EXISTS anti_scraping_config jsonb DEFAULT '{
  "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "delay_min": 2000,
  "delay_max": 5000,
  "use_referer": true,
  "use_cookies": false,
  "custom_headers": {},
  "timeout": 30000,
  "retry_times": 3,
  "retry_delay": 5000
}'::jsonb;

-- 添加请求频率控制字段
ALTER TABLE scraper_rules ADD COLUMN IF NOT EXISTS rate_limit_config jsonb DEFAULT '{
  "max_requests_per_minute": 10,
  "max_requests_per_hour": 100,
  "concurrent_requests": 1
}'::jsonb;

-- 添加代理配置字段
ALTER TABLE scraper_rules ADD COLUMN IF NOT EXISTS proxy_config jsonb DEFAULT '{
  "enabled": false,
  "proxy_url": null,
  "rotate_proxy": false
}'::jsonb;

-- 添加Cookie存储字段
ALTER TABLE scraper_rules ADD COLUMN IF NOT EXISTS cookies jsonb DEFAULT '[]'::jsonb;

-- 添加最后请求时间字段（用于频率控制）
ALTER TABLE scraper_rules ADD COLUMN IF NOT EXISTS last_request_at timestamptz;

-- 添加请求计数字段
ALTER TABLE scraper_rules ADD COLUMN IF NOT EXISTS request_count_minute int DEFAULT 0;
ALTER TABLE scraper_rules ADD COLUMN IF NOT EXISTS request_count_hour int DEFAULT 0;
ALTER TABLE scraper_rules ADD COLUMN IF NOT EXISTS request_count_reset_at timestamptz DEFAULT now();

-- 创建请求日志表（用于分析和调试）
CREATE TABLE IF NOT EXISTS scraper_request_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_id uuid REFERENCES scraper_rules(id) ON DELETE CASCADE,
  url text NOT NULL,
  method text DEFAULT 'GET',
  status_code int,
  response_time int, -- 毫秒
  user_agent text,
  headers jsonb,
  success boolean,
  error_message text,
  created_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_scraper_request_logs_rule_id ON scraper_request_logs(rule_id);
CREATE INDEX IF NOT EXISTS idx_scraper_request_logs_created_at ON scraper_request_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_scraper_request_logs_success ON scraper_request_logs(success);

-- 创建清理旧日志的函数
CREATE OR REPLACE FUNCTION cleanup_old_scraper_logs()
RETURNS void AS $$
BEGIN
  -- 删除30天前的日志
  DELETE FROM scraper_request_logs
  WHERE created_at < now() - interval '30 days';
END;
$$ LANGUAGE plpgsql;

-- 创建更新请求计数的函数
CREATE OR REPLACE FUNCTION update_scraper_request_count(rule_uuid uuid)
RETURNS void AS $$
DECLARE
  current_rule RECORD;
BEGIN
  SELECT * INTO current_rule FROM scraper_rules WHERE id = rule_uuid;
  
  -- 检查是否需要重置计数
  IF current_rule.request_count_reset_at < now() - interval '1 hour' THEN
    UPDATE scraper_rules
    SET 
      request_count_minute = 0,
      request_count_hour = 0,
      request_count_reset_at = now()
    WHERE id = rule_uuid;
  ELSIF current_rule.request_count_reset_at < now() - interval '1 minute' THEN
    UPDATE scraper_rules
    SET 
      request_count_minute = 0
    WHERE id = rule_uuid;
  END IF;
  
  -- 增加计数
  UPDATE scraper_rules
  SET 
    request_count_minute = request_count_minute + 1,
    request_count_hour = request_count_hour + 1,
    last_request_at = now()
  WHERE id = rule_uuid;
END;
$$ LANGUAGE plpgsql;

-- 创建检查频率限制的函数
CREATE OR REPLACE FUNCTION check_scraper_rate_limit(rule_uuid uuid)
RETURNS boolean AS $$
DECLARE
  current_rule RECORD;
  rate_config jsonb;
BEGIN
  SELECT * INTO current_rule FROM scraper_rules WHERE id = rule_uuid;
  rate_config := current_rule.rate_limit_config;
  
  -- 检查分钟限制
  IF current_rule.request_count_minute >= (rate_config->>'max_requests_per_minute')::int THEN
    RETURN false;
  END IF;
  
  -- 检查小时限制
  IF current_rule.request_count_hour >= (rate_config->>'max_requests_per_hour')::int THEN
    RETURN false;
  END IF;
  
  RETURN true;
END;
$$ LANGUAGE plpgsql;

-- RLS策略
ALTER TABLE scraper_request_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "管理员和编辑可以查看请求日志"
  ON scraper_request_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "系统可以插入请求日志"
  ON scraper_request_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

COMMENT ON TABLE scraper_request_logs IS '采集请求日志表，用于分析和调试';
COMMENT ON COLUMN scraper_rules.anti_scraping_config IS '反爬虫配置：User-Agent、延迟、Headers等';
COMMENT ON COLUMN scraper_rules.rate_limit_config IS '频率限制配置';
COMMENT ON COLUMN scraper_rules.proxy_config IS '代理配置';
/*
# CMS Content Management System - Initialize Database Structure

## 1. New Tables

### 1.1 User Role Enum
- `user_role`: User role types (admin=Administrator, editor=Editor, member=Member, visitor=Visitor)

### 1.2 profiles table - User Information
- `id` (uuid, primary key, references auth.users)
- `username` (text, unique, username)
- `email` (text, unique, email address)
- `phone` (text, phone number)
- `avatar_url` (text, avatar URL)
- `role` (user_role, default: 'member', user role)
- `created_at` (timestamptz, creation time)
- `updated_at` (timestamptz, update time)

### 1.3 categories table - Categories
- `id` (uuid, primary key)
- `name` (text, category name)
- `slug` (text, unique, URL slug)
- `type` (text, category type: article/product/question)
- `description` (text, description)
- `created_at` (timestamptz, creation time)

### 1.4 articles table - Articles
- `id` (uuid, primary key)
- `title` (text, title)
- `slug` (text, unique, URL slug)
- `content` (text, content)
- `excerpt` (text, excerpt)
- `cover_image` (text, cover image)
- `category_id` (uuid, category ID)
- `author_id` (uuid, author ID)
- `status` (text, status: draft/published/offline)
- `view_count` (int, view count)
- `created_at` (timestamptz, creation time)
- `updated_at` (timestamptz, update time)
- `published_at` (timestamptz, publish time)

### 1.5 products table - Products
- `id` (uuid, primary key)
- `name` (text, product name)
- `slug` (text, unique, URL slug)
- `description` (text, product description)
- `content` (text, detailed content)
- `price` (numeric, price)
- `category_id` (uuid, category ID)
- `status` (text, status: draft/published/offline)
- `view_count` (int, view count)
- `created_at` (timestamptz, creation time)
- `updated_at` (timestamptz, update time)

### 1.6 product_images table - Product Images
- `id` (uuid, primary key)
- `product_id` (uuid, product ID)
- `image_url` (text, image URL)
- `sort_order` (int, sort order)
- `created_at` (timestamptz, creation time)

### 1.7 questions table - Questions
- `id` (uuid, primary key)
- `title` (text, question title)
- `content` (text, question content)
- `category_id` (uuid, category ID)
- `author_id` (uuid, author ID)
- `status` (text, status: pending/approved/rejected)
- `view_count` (int, view count)
- `created_at` (timestamptz, creation time)
- `updated_at` (timestamptz, update time)

### 1.8 answers table - Answers
- `id` (uuid, primary key)
- `question_id` (uuid, question ID)
- `content` (text, answer content)
- `author_id` (uuid, author ID)
- `is_accepted` (boolean, is accepted)
- `created_at` (timestamptz, creation time)
- `updated_at` (timestamptz, update time)

### 1.9 site_settings table - Site Settings
- `id` (uuid, primary key)
- `key` (text, unique, setting key)
- `value` (text, setting value)
- `description` (text, description)
- `updated_at` (timestamptz, update time)

### 1.10 analytics table - Visit Statistics
- `id` (uuid, primary key)
- `page_path` (text, page path)
- `visitor_id` (text, visitor ID)
- `user_id` (uuid, user ID, nullable)
- `created_at` (timestamptz, visit time)

## 2. Security Policies
- profiles table: Enable RLS, admins have full access, users can view and edit their own info (cannot change role)
- categories table: Public read, admins and editors can write
- articles table: Public read for published articles, authors and admins can manage
- products table: Public read for published products, admins can manage
- product_images table: Public read, admins can manage
- questions table: Public read for approved questions, members can ask, admins and editors can manage
- answers table: Public read, members can answer, admins and editors can manage
- site_settings table: Public read, only admins can modify
- analytics table: Public write, only admins can read

## 3. Triggers
- Automatically set first registered user as admin
- Automatically update updated_at field

## 4. Storage Buckets
- cms_images: Store image files (max 1MB)
- cms_videos: Store video files
- cms_audios: Store audio files
*/

-- Create user role enum
CREATE TYPE user_role AS ENUM ('admin', 'editor', 'member', 'visitor');

-- Create content status enum
CREATE TYPE content_status AS ENUM ('draft', 'published', 'offline');

-- Create question status enum
CREATE TYPE question_status AS ENUM ('pending', 'approved', 'rejected');

-- 1. profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  email text UNIQUE,
  phone text,
  avatar_url text,
  role user_role DEFAULT 'member'::user_role NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 2. categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  type text NOT NULL CHECK (type IN ('article', 'product', 'question')),
  description text,
  created_at timestamptz DEFAULT now()
);

-- 3. articles table
CREATE TABLE IF NOT EXISTS articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  content text NOT NULL,
  excerpt text,
  cover_image text,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  author_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  status content_status DEFAULT 'draft'::content_status NOT NULL,
  view_count int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  published_at timestamptz
);

-- 4. products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  content text,
  price numeric(10, 2),
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  status content_status DEFAULT 'draft'::content_status NOT NULL,
  view_count int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 5. product_images table
CREATE TABLE IF NOT EXISTS product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- 6. questions table
CREATE TABLE IF NOT EXISTS questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  author_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  status question_status DEFAULT 'pending'::question_status NOT NULL,
  view_count int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 7. answers table
CREATE TABLE IF NOT EXISTS answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid REFERENCES questions(id) ON DELETE CASCADE,
  content text NOT NULL,
  author_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  is_accepted boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 8. site_settings table
CREATE TABLE IF NOT EXISTS site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text,
  description text,
  updated_at timestamptz DEFAULT now()
);

-- 9. analytics table
CREATE TABLE IF NOT EXISTS analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_path text NOT NULL,
  visitor_id text NOT NULL,
  user_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_articles_status ON articles(status);
CREATE INDEX idx_articles_category ON articles(category_id);
CREATE INDEX idx_articles_author ON articles(author_id);
CREATE INDEX idx_products_status ON products(status);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_questions_status ON questions(status);
CREATE INDEX idx_questions_author ON questions(author_id);
CREATE INDEX idx_answers_question ON answers(question_id);
CREATE INDEX idx_analytics_page ON analytics(page_path);
CREATE INDEX idx_analytics_created ON analytics(created_at);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics ENABLE ROW LEVEL SECURITY;

-- Create helper functions
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

CREATE OR REPLACE FUNCTION is_editor_or_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role IN ('admin'::user_role, 'editor'::user_role)
  );
$$;

-- profiles table policies
CREATE POLICY "管理员可查看所有用户" ON profiles
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "用户可查看自己的信息" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "用户可更新自己的信息但不能改角色" ON profiles
  FOR UPDATE USING (auth.uid() = id) 
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

CREATE POLICY "管理员可更新所有用户" ON profiles
  FOR UPDATE TO authenticated USING (is_admin(auth.uid()));

-- categories table policies
CREATE POLICY "所有人可查看分类" ON categories FOR SELECT USING (true);
CREATE POLICY "管理员和编辑可管理分类" ON categories FOR ALL TO authenticated USING (is_editor_or_admin(auth.uid()));

-- articles table policies
CREATE POLICY "所有人可查看已发布文章" ON articles 
  FOR SELECT USING (status = 'published'::content_status);

CREATE POLICY "作者可查看自己的文章" ON articles 
  FOR SELECT TO authenticated USING (author_id = auth.uid());

CREATE POLICY "管理员和编辑可查看所有文章" ON articles 
  FOR SELECT TO authenticated USING (is_editor_or_admin(auth.uid()));

CREATE POLICY "作者可创建文章" ON articles 
  FOR INSERT TO authenticated WITH CHECK (author_id = auth.uid());

CREATE POLICY "作者可更新自己的文章" ON articles 
  FOR UPDATE TO authenticated USING (author_id = auth.uid());

CREATE POLICY "管理员和编辑可管理所有文章" ON articles 
  FOR ALL TO authenticated USING (is_editor_or_admin(auth.uid()));

CREATE POLICY "作者可删除自己的文章" ON articles 
  FOR DELETE TO authenticated USING (author_id = auth.uid());

-- products table policies
CREATE POLICY "所有人可查看已发布产品" ON products 
  FOR SELECT USING (status = 'published'::content_status);

CREATE POLICY "管理员可管理所有产品" ON products 
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- product_images table policies
CREATE POLICY "所有人可查看产品图片" ON product_images FOR SELECT USING (true);
CREATE POLICY "管理员可管理产品图片" ON product_images FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- questions table policies
CREATE POLICY "所有人可查看已审核问题" ON questions 
  FOR SELECT USING (status = 'approved'::question_status);

CREATE POLICY "提问者可查看自己的问题" ON questions 
  FOR SELECT TO authenticated USING (author_id = auth.uid());

CREATE POLICY "管理员和编辑可查看所有问题" ON questions 
  FOR SELECT TO authenticated USING (is_editor_or_admin(auth.uid()));

CREATE POLICY "会员可提问" ON questions 
  FOR INSERT TO authenticated WITH CHECK (author_id = auth.uid());

CREATE POLICY "提问者可更新自己的问题" ON questions 
  FOR UPDATE TO authenticated USING (author_id = auth.uid());

CREATE POLICY "管理员和编辑可管理所有问题" ON questions 
  FOR ALL TO authenticated USING (is_editor_or_admin(auth.uid()));

-- answers table policies
CREATE POLICY "所有人可查看回答" ON answers FOR SELECT USING (true);

CREATE POLICY "会员可回答问题" ON answers 
  FOR INSERT TO authenticated WITH CHECK (author_id = auth.uid());

CREATE POLICY "回答者可更新自己的回答" ON answers 
  FOR UPDATE TO authenticated USING (author_id = auth.uid());

CREATE POLICY "管理员和编辑可管理所有回答" ON answers 
  FOR ALL TO authenticated USING (is_editor_or_admin(auth.uid()));

-- site_settings table policies
CREATE POLICY "所有人可查看网站设置" ON site_settings FOR SELECT USING (true);
CREATE POLICY "管理员可管理网站设置" ON site_settings FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- analytics table policies
CREATE POLICY "所有人可写入访问统计" ON analytics FOR INSERT WITH CHECK (true);
CREATE POLICY "管理员可查看访问统计" ON analytics FOR SELECT TO authenticated USING (is_admin(auth.uid()));

-- Create trigger function: auto update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Apply triggers
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_articles_updated_at BEFORE UPDATE ON articles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_questions_updated_at BEFORE UPDATE ON questions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_answers_updated_at BEFORE UPDATE ON answers
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_site_settings_updated_at BEFORE UPDATE ON site_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Create trigger: first user becomes admin automatically
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  -- 只在用户经过验证后再插入profiles
  IF OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL THEN
    -- 判断 profiles 表里有多少用户
    SELECT COUNT(*) INTO user_count FROM profiles;
    -- 插入 profiles，首位用户给 admin 角色
    INSERT INTO profiles (id, username, email, phone, role)
    VALUES (
      NEW.id,
      COALESCE(SPLIT_PART(NEW.email, '@', 1), ''),
      NEW.email,
      NEW.phone,
      CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'member'::user_role END
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
  ('app-7fshtpomqha9_cms_images', 'app-7fshtpomqha9_cms_images', true, 1048576, ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif']),
  ('app-7fshtpomqha9_cms_videos', 'app-7fshtpomqha9_cms_videos', true, 52428800, ARRAY['video/mp4', 'video/webm', 'video/ogg']),
  ('app-7fshtpomqha9_cms_audios', 'app-7fshtpomqha9_cms_audios', true, 10485760, ARRAY['audio/mpeg', 'audio/wav', 'audio/ogg'])
ON CONFLICT (id) DO NOTHING;

-- Storage bucket policy: public read
CREATE POLICY "所有人可查看图片" ON storage.objects FOR SELECT USING (bucket_id = 'app-7fshtpomqha9_cms_images');
CREATE POLICY "所有人可查看视频" ON storage.objects FOR SELECT USING (bucket_id = 'app-7fshtpomqha9_cms_videos');
CREATE POLICY "所有人可查看音频" ON storage.objects FOR SELECT USING (bucket_id = 'app-7fshtpomqha9_cms_audios');

-- Storage bucket policy: admins and editors can upload
CREATE POLICY "管理员和编辑可上传图片" ON storage.objects 
  FOR INSERT TO authenticated 
  WITH CHECK (bucket_id = 'app-7fshtpomqha9_cms_images' AND is_editor_or_admin(auth.uid()));

CREATE POLICY "管理员和编辑可上传视频" ON storage.objects 
  FOR INSERT TO authenticated 
  WITH CHECK (bucket_id = 'app-7fshtpomqha9_cms_videos' AND is_editor_or_admin(auth.uid()));

CREATE POLICY "管理员和编辑可上传音频" ON storage.objects 
  FOR INSERT TO authenticated 
  WITH CHECK (bucket_id = 'app-7fshtpomqha9_cms_audios' AND is_editor_or_admin(auth.uid()));

-- 存储桶策略: 管理员可删除
CREATE POLICY "管理员可删除图片" ON storage.objects 
  FOR DELETE TO authenticated 
  USING (bucket_id = 'app-7fshtpomqha9_cms_images' AND is_admin(auth.uid()));

CREATE POLICY "管理员可删除视频" ON storage.objects 
  FOR DELETE TO authenticated 
  USING (bucket_id = 'app-7fshtpomqha9_cms_videos' AND is_admin(auth.uid()));

CREATE POLICY "管理员可删除音频" ON storage.objects 
  FOR DELETE TO authenticated 
  USING (bucket_id = 'app-7fshtpomqha9_cms_audios' AND is_admin(auth.uid()));

-- 插入默认网站设置
INSERT INTO site_settings (key, value, description) VALUES
  ('site_name', 'CMS内容管理系统', '网站名称'),
  ('site_description', '基于现代技术栈的内容管理系统', '网站描述'),
  ('site_keywords', 'CMS,内容管理,产品展示,问答系统', '网站关键词'),
  ('seo_title', 'CMS内容管理系统 - 专业的内容管理平台', 'SEO标题'),
  ('contact_email', 'contact@cms.com', '联系邮箱')
ON CONFLICT (key) DO NOTHING;

-- 插入默认分类
INSERT INTO categories (name, slug, type, description) VALUES
  ('技术文章', 'tech', 'article', '技术相关的文章'),
  ('产品动态', 'product-news', 'article', '产品相关的动态'),
  ('企业服务', 'enterprise', 'product', '企业级服务产品'),
  ('个人工具', 'personal', 'product', '个人使用的工具产品'),
  ('技术问答', 'tech-qa', 'question', '技术相关的问答'),
  ('产品咨询', 'product-qa', 'question', '产品相关的咨询')
ON CONFLICT (slug) DO NOTHING;
/*
# 添加浏览次数增加函数

## RPC函数
- increment_article_views: 增加文章浏览次数
- increment_product_views: 增加产品浏览次数
- increment_question_views: 增加问题浏览次数
*/

-- 增加文章浏览次数
CREATE OR REPLACE FUNCTION increment_article_views(article_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE articles SET view_count = view_count + 1 WHERE id = article_id;
END;
$$;

-- 增加产品浏览次数
CREATE OR REPLACE FUNCTION increment_product_views(product_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE products SET view_count = view_count + 1 WHERE id = product_id;
END;
$$;

-- 增加问题浏览次数
CREATE OR REPLACE FUNCTION increment_question_views(question_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE questions SET view_count = view_count + 1 WHERE id = question_id;
END;
$$;
/*
# 创建存储桶用于文件上传

## 1. 新建存储桶
- `app-7fshtpomqha9_cms_images` - 用于存储CMS系统的所有图片文件
  - 支持的文件类型: image/jpeg, image/png, image/gif, image/webp, image/avif
  - 最大文件大小: 1MB
  - 公开访问: 是

- `app-7fshtpomqha9_cms_files` - 用于存储其他类型的文件
  - 支持的文件类型: 所有类型
  - 最大文件大小: 5MB
  - 公开访问: 是

## 2. 安全策略
- 所有用户都可以上传文件（因为系统没有强制登录）
- 所有用户都可以读取文件
- 只有管理员可以删除文件

## 3. 注意事项
- 文件名必须只包含英文字母和数字
- 图片超过1MB会自动压缩
*/

-- 创建图片存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-7fshtpomqha9_cms_images',
  'app-7fshtpomqha9_cms_images',
  true,
  1048576,
  ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif']
) ON CONFLICT (id) DO NOTHING;

-- 创建文件存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-7fshtpomqha9_cms_files',
  'app-7fshtpomqha9_cms_files',
  true,
  5242880,
  NULL
) ON CONFLICT (id) DO NOTHING;

-- 允许所有用户上传图片
CREATE POLICY "允许所有用户上传图片" ON storage.objects
  FOR INSERT TO public
  WITH CHECK (bucket_id = 'app-7fshtpomqha9_cms_images');

-- 允许所有用户读取图片
CREATE POLICY "允许所有用户读取图片" ON storage.objects
  FOR SELECT TO public
  USING (bucket_id = 'app-7fshtpomqha9_cms_images');

-- 允许所有用户上传文件
CREATE POLICY "允许所有用户上传文件" ON storage.objects
  FOR INSERT TO public
  WITH CHECK (bucket_id = 'app-7fshtpomqha9_cms_files');

-- 允许所有用户读取文件
CREATE POLICY "允许所有用户读取文件" ON storage.objects
  FOR SELECT TO public
  USING (bucket_id = 'app-7fshtpomqha9_cms_files');

-- 只允许管理员删除图片
CREATE POLICY "只允许管理员删除图片" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'app-7fshtpomqha9_cms_images' 
    AND is_admin(auth.uid())
  );

-- 只允许管理员删除文件
CREATE POLICY "只允许管理员删除文件" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'app-7fshtpomqha9_cms_files' 
    AND is_admin(auth.uid())
  );
/*
# 添加昵称字段到用户资料表

## 变更说明
为profiles表添加nickname字段，允许用户设置显示昵称

## 表结构变更
- `profiles` 表
  - 新增 `nickname` (text, 可选) - 用户昵称

## 注意事项
- 昵称字段为可选，不影响现有数据
- 用户可以自由设置和修改昵称
*/

-- 添加昵称字段
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS nickname text;

-- 添加注释
COMMENT ON COLUMN profiles.nickname IS '用户昵称';
/*
# 创建用户注册时自动创建profile的触发器

## 功能说明
当新用户在auth.users表中注册时，自动在profiles表中创建对应的记录

## 变更内容
1. 创建触发器函数 handle_new_user()
2. 创建触发器 on_auth_user_created
3. 从用户邮箱中提取用户名（格式：username@ifixescn.com）

## 安全性
- 新用户默认角色为 'member'
- 自动提取用户名和邮箱
*/

-- 创建处理新用户的函数
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  extracted_username text;
BEGIN
  -- 从邮箱中提取用户名（格式：username@ifixescn.com）
  extracted_username := split_part(NEW.email, '@', 1);
  
  -- 在profiles表中插入新记录
  INSERT INTO public.profiles (id, username, email, role)
  VALUES (
    NEW.id,
    extracted_username,
    NEW.email,
    'member'::user_role
  );
  
  RETURN NEW;
END;
$$;

-- 创建触发器
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- 添加注释
COMMENT ON FUNCTION public.handle_new_user() IS '当新用户注册时自动创建profile记录';
/*
# 添加字体设置

1. 新增设置项
  - `site_font` - 网站字体设置
  - 默认值：Inter（现代、清晰、适合UI）

2. 支持的字体列表
  - Inter：现代、清晰、专业，适合UI界面
  - Poppins：几何、友好、现代感强
  - Roboto：经典、专业、可读性强
  - Montserrat：都市、时尚、大气
  - Open Sans：人文主义、友好、通用性强
  - Lato：温暖、稳定、企业级
  - Raleway：优雅、精致、高端
  - Nunito：圆润、友好、现代

3. 字体加载
  - 使用Google Fonts CDN
  - 支持动态切换
  - 自动应用到全站
*/

-- 插入默认字体设置
INSERT INTO site_settings (key, value, description)
VALUES 
  ('site_font', 'Inter', 'Website font family')
ON CONFLICT (key) DO UPDATE
SET value = EXCLUDED.value,
    description = EXCLUDED.description;
/*
# 修复profile触发器的唯一约束冲突问题

## 问题说明
触发器在创建profile时遇到23505错误（唯一约束违反）
原因：username或email可能已存在

## 解决方案
使用 ON CONFLICT DO NOTHING 避免重复插入错误

## 变更内容
1. 更新 handle_new_user() 函数
2. 添加冲突处理逻辑
3. 如果记录已存在，不做任何操作
*/

-- 更新处理新用户的函数，添加冲突处理
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  extracted_username text;
BEGIN
  -- 从邮箱中提取用户名（格式：username@miaoda.com）
  extracted_username := split_part(NEW.email, '@', 1);
  
  -- 在profiles表中插入新记录，如果已存在则忽略
  INSERT INTO public.profiles (id, username, email, role)
  VALUES (
    NEW.id,
    extracted_username,
    NEW.email,
    'member'::user_role
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$;

-- 添加注释
COMMENT ON FUNCTION public.handle_new_user() IS '当新用户注册时自动创建profile记录，避免重复插入错误';
/*
# 添加编辑角色权限

## 问题说明
编辑角色无法保存产品，因为RLS策略只允许管理员操作

## 解决方案
1. 创建 is_admin_or_editor() 函数
2. 更新products表的RLS策略
3. 更新product_images表的RLS策略

## 变更内容
- 新增函数：is_admin_or_editor()
- 更新策略：允许编辑角色管理产品和产品图片
*/

-- 创建检查是否是管理员或编辑的函数
CREATE OR REPLACE FUNCTION is_admin_or_editor(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role IN ('admin'::user_role, 'editor'::user_role)
  );
$$;

-- 删除旧的产品管理策略
DROP POLICY IF EXISTS "管理员可管理所有产品" ON products;

-- 创建新的产品管理策略（管理员和编辑都可以）
CREATE POLICY "管理员和编辑可管理所有产品" ON products
  FOR ALL TO authenticated 
  USING (is_admin_or_editor(auth.uid()))
  WITH CHECK (is_admin_or_editor(auth.uid()));

-- 删除旧的产品图片管理策略
DROP POLICY IF EXISTS "管理员可管理产品图片" ON product_images;

-- 创建新的产品图片管理策略（管理员和编辑都可以）
CREATE POLICY "管理员和编辑可管理产品图片" ON product_images
  FOR ALL TO authenticated 
  USING (is_admin_or_editor(auth.uid()))
  WITH CHECK (is_admin_or_editor(auth.uid()));

-- 添加注释
COMMENT ON FUNCTION is_admin_or_editor(uuid) IS '检查用户是否是管理员或编辑角色';
/*
# 添加会员等级系统

## 1. 新增内容
- 创建member_level枚举类型（guest, member, premium, svip）
- 在profiles表添加member_level字段
- 更新默认值为member

## 2. 会员等级说明
- guest: 游客（未登录或未激活）
- member: 普通会员
- premium: 高级会员
- svip: SVIP会员

## 3. 权限设计
- 所有会员可以查看自己的等级
- 管理员可以修改会员等级
- 会员等级影响投稿等功能权限

## 4. 注意事项
- member_level与role字段独立
- role控制系统权限（admin/editor/user）
- member_level控制会员权益
*/

-- 创建会员等级枚举类型
CREATE TYPE member_level AS ENUM ('guest', 'member', 'premium', 'svip');

-- 在profiles表添加member_level字段
ALTER TABLE profiles ADD COLUMN member_level member_level DEFAULT 'member'::member_level NOT NULL;

-- 创建索引以提高查询性能
CREATE INDEX idx_profiles_member_level ON profiles(member_level);

-- 更新现有用户为普通会员
UPDATE profiles SET member_level = 'member'::member_level WHERE member_level IS NULL;

-- 添加注释
COMMENT ON COLUMN profiles.member_level IS '会员等级：guest-游客，member-普通会员，premium-高级会员，svip-SVIP会员';
/*
# 添加pending状态到content_status枚举

## 1. 修改内容
- 在content_status枚举类型中添加pending状态
- pending状态用于会员投稿文章的审核

## 2. 状态说明
- draft: 草稿
- pending: 待审核（会员投稿）
- published: 已发布
- offline: 已下线

## 3. 注意事项
- 会员投稿的文章默认为pending状态
- 管理员审核后可改为published或offline
*/

-- 添加pending状态到content_status枚举
ALTER TYPE content_status ADD VALUE IF NOT EXISTS 'pending';

-- 添加注释
COMMENT ON TYPE content_status IS '内容状态：draft-草稿，pending-待审核，published-已发布，offline-已下线';
/*
# Create Search Keywords Table

## 1. New Tables
- `search_keywords` - Search keyword tracking table
  - `id` (uuid, primary key) - Primary key
  - `keyword` (text, unique, not null) - Search keyword
  - `search_count` (integer, default 1) - Number of searches
  - `last_searched_at` (timestamptz, default now()) - Last search timestamp
  - `created_at` (timestamptz, default now()) - First search timestamp

## 2. Indexes
- Descending index on search_count (for trending searches)
- Descending index on last_searched_at (for recent searches)
- Unique index on keyword

## 3. Features
- Track user search keywords
- Count searches per keyword
- Support trending search rankings
- Support recent search history

## 4. Security
- Public table, readable by all users
- Write access controlled through RPC function
*/

-- Create search keywords table
CREATE TABLE IF NOT EXISTS search_keywords (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  keyword text UNIQUE NOT NULL,
  search_count integer DEFAULT 1 NOT NULL,
  last_searched_at timestamptz DEFAULT now() NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes
CREATE INDEX idx_search_keywords_count ON search_keywords(search_count DESC);
CREATE INDEX idx_search_keywords_last_searched ON search_keywords(last_searched_at DESC);

-- Enable RLS
ALTER TABLE search_keywords ENABLE ROW LEVEL SECURITY;

-- Allow everyone to read
CREATE POLICY "Anyone can read search keywords" ON search_keywords
  FOR SELECT TO public USING (true);

-- Create RPC function to record search keywords
CREATE OR REPLACE FUNCTION record_search_keyword(p_keyword text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO search_keywords (keyword, search_count, last_searched_at)
  VALUES (p_keyword, 1, now())
  ON CONFLICT (keyword)
  DO UPDATE SET
    search_count = search_keywords.search_count + 1,
    last_searched_at = now();
END;
$$;

-- Add comments
COMMENT ON TABLE search_keywords IS 'Search keyword statistics table';
COMMENT ON COLUMN search_keywords.keyword IS 'Search keyword';
COMMENT ON COLUMN search_keywords.search_count IS 'Number of searches';
COMMENT ON COLUMN search_keywords.last_searched_at IS 'Last search timestamp';
COMMENT ON COLUMN search_keywords.created_at IS 'First search timestamp';
/*
# 创建模块设置表

## 1. 新增枚举类型
- `module_type` - 模块类型枚举（articles, products, questions）

## 2. 新增表
- `module_settings` - 模块设置表
  - `id` (uuid, primary key) - 主键
  - `module_type` (module_type, unique, not null) - 模块类型
  - `display_name` (text, not null) - 模块显示名称
  - `banner_image` (text) - 栏目图片URL
  - `seo_title` (text) - SEO标题
  - `seo_keywords` (text) - SEO关键词
  - `seo_description` (text) - SEO描述
  - `is_enabled` (boolean, default true) - 是否启用
  - `sort_order` (integer, default 0) - 排序
  - `items_per_page` (integer, default 12) - 每页显示数量
  - `show_author` (boolean, default true) - 是否显示作者
  - `show_date` (boolean, default true) - 是否显示日期
  - `show_category` (boolean, default true) - 是否显示分类
  - `allow_comments` (boolean, default false) - 是否允许评论
  - `custom_settings` (jsonb) - 自定义设置
  - `updated_at` (timestamptz, default now()) - 更新时间
  - `created_at` (timestamptz, default now()) - 创建时间

## 3. 索引
- 模块类型唯一索引

## 4. 初始数据
- 插入三个模块的默认设置

## 5. 安全策略
- 公开表，所有用户可读
- 仅管理员可写
*/

-- 创建模块类型枚举
CREATE TYPE module_type AS ENUM ('articles', 'products', 'questions');

-- 创建模块设置表
CREATE TABLE IF NOT EXISTS module_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_type module_type UNIQUE NOT NULL,
  display_name text NOT NULL,
  banner_image text,
  seo_title text,
  seo_keywords text,
  seo_description text,
  is_enabled boolean DEFAULT true NOT NULL,
  sort_order integer DEFAULT 0 NOT NULL,
  items_per_page integer DEFAULT 12 NOT NULL,
  show_author boolean DEFAULT true NOT NULL,
  show_date boolean DEFAULT true NOT NULL,
  show_category boolean DEFAULT true NOT NULL,
  allow_comments boolean DEFAULT false NOT NULL,
  custom_settings jsonb DEFAULT '{}'::jsonb,
  updated_at timestamptz DEFAULT now() NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- 创建索引
CREATE INDEX idx_module_settings_type ON module_settings(module_type);
CREATE INDEX idx_module_settings_enabled ON module_settings(is_enabled);

-- 启用RLS
ALTER TABLE module_settings ENABLE ROW LEVEL SECURITY;

-- 允许所有人读取
CREATE POLICY "Anyone can read module settings" ON module_settings
  FOR SELECT TO public USING (true);

-- 仅管理员可以修改
CREATE POLICY "Admins can update module settings" ON module_settings
  FOR UPDATE TO authenticated USING (is_admin(auth.uid()));

-- 插入默认设置
INSERT INTO module_settings (module_type, display_name, seo_title, seo_keywords, seo_description, items_per_page, show_author, show_date, show_category)
VALUES 
  (
    'articles'::module_type,
    '文章',
    '文章列表 - CMS内容管理系统',
    '文章,博客,内容,资讯',
    '浏览我们的文章列表，获取最新资讯和深度内容',
    12,
    true,
    true,
    true
  ),
  (
    'products'::module_type,
    '产品',
    '产品展示 - CMS内容管理系统',
    '产品,服务,解决方案',
    '查看我们的产品和服务，找到适合您的解决方案',
    12,
    false,
    true,
    true
  ),
  (
    'questions'::module_type,
    '问答',
    '问答社区 - CMS内容管理系统',
    '问答,社区,帮助,支持',
    '在问答社区中提问和回答，获取帮助和分享知识',
    20,
    true,
    true,
    true
  )
ON CONFLICT (module_type) DO NOTHING;

-- 创建更新时间触发器
CREATE OR REPLACE FUNCTION update_module_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_module_settings_updated_at
  BEFORE UPDATE ON module_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_module_settings_updated_at();

-- 添加注释
COMMENT ON TABLE module_settings IS '模块设置表';
COMMENT ON COLUMN module_settings.module_type IS '模块类型';
COMMENT ON COLUMN module_settings.display_name IS '模块显示名称';
COMMENT ON COLUMN module_settings.banner_image IS '栏目图片URL';
COMMENT ON COLUMN module_settings.seo_title IS 'SEO标题';
COMMENT ON COLUMN module_settings.seo_keywords IS 'SEO关键词';
COMMENT ON COLUMN module_settings.seo_description IS 'SEO描述';
COMMENT ON COLUMN module_settings.is_enabled IS '是否启用';
COMMENT ON COLUMN module_settings.sort_order IS '排序';
COMMENT ON COLUMN module_settings.items_per_page IS '每页显示数量';
COMMENT ON COLUMN module_settings.show_author IS '是否显示作者';
COMMENT ON COLUMN module_settings.show_date IS '是否显示日期';
COMMENT ON COLUMN module_settings.show_category IS '是否显示分类';
COMMENT ON COLUMN module_settings.allow_comments IS '是否允许评论';
COMMENT ON COLUMN module_settings.custom_settings IS '自定义设置JSON';
/*
# 更新公开访问权限和问答模块权限

## 1. 权限调整说明

### 公开访问（无需登录）
- 所有人可以查看已发布的文章
- 所有人可以查看已上架的产品
- 所有人可以查看已发布的问答
- 游客可以提交问题（需要审核）

### 会员权限
- 会员可以回答问题
- 会员可以查看自己提交的问题（包括待审核的）

### 管理员权限
- 管理员可以审核问题
- 管理员可以管理所有内容

## 2. 修改内容

### 2.1 问题表权限
- 允许匿名用户查看已发布的问题
- 允许匿名用户创建问题（状态为pending）
- 允许会员查看自己的问题

### 2.2 答案表权限
- 允许匿名用户查看所有答案
- 允许会员创建答案
- 允许作者编辑自己的答案

### 2.3 产品和文章权限
- 已有策略支持公开访问，无需修改

## 3. 安全考虑
- 游客提交的问题默认为pending状态，需要管理员审核
- 会员提交的答案立即可见
- 所有修改操作需要身份验证
*/

-- ============================================
-- 1. 删除旧的问题表策略
-- ============================================

DROP POLICY IF EXISTS "所有人可查看已发布问题" ON questions;
DROP POLICY IF EXISTS "作者可查看自己的问题" ON questions;
DROP POLICY IF EXISTS "管理员和编辑可查看所有问题" ON questions;
DROP POLICY IF EXISTS "作者可创建问题" ON questions;
DROP POLICY IF EXISTS "作者可更新自己的问题" ON questions;
DROP POLICY IF EXISTS "管理员和编辑可管理所有问题" ON questions;
DROP POLICY IF EXISTS "作者可删除自己的问题" ON questions;

-- ============================================
-- 2. 创建新的问题表策略
-- ============================================

-- 2.1 所有人（包括游客）可以查看已批准的问题
CREATE POLICY "公开访问已发布问题" ON questions
  FOR SELECT 
  USING (status = 'approved'::question_status);

-- 2.2 已登录用户可以查看自己的所有问题（包括待审核的）
CREATE POLICY "用户查看自己的问题" ON questions
  FOR SELECT 
  TO authenticated 
  USING (author_id = auth.uid());

-- 2.3 管理员和编辑可以查看所有问题
CREATE POLICY "管理员查看所有问题" ON questions
  FOR SELECT 
  TO authenticated 
  USING (is_editor_or_admin(auth.uid()));

-- 2.4 所有人（包括游客）可以创建问题，但状态必须为pending
CREATE POLICY "公开创建问题" ON questions
  FOR INSERT 
  WITH CHECK (status = 'pending'::question_status);

-- 2.5 已登录用户可以更新自己的待审核问题
CREATE POLICY "用户更新自己的待审核问题" ON questions
  FOR UPDATE 
  TO authenticated 
  USING (author_id = auth.uid() AND status = 'pending'::question_status)
  WITH CHECK (status = 'pending'::question_status);

-- 2.6 管理员和编辑可以管理所有问题
CREATE POLICY "管理员管理所有问题" ON questions
  FOR ALL 
  TO authenticated 
  USING (is_editor_or_admin(auth.uid()));

-- ============================================
-- 3. 删除旧的答案表策略
-- ============================================

DROP POLICY IF EXISTS "所有人可查看答案" ON answers;
DROP POLICY IF EXISTS "作者可创建答案" ON answers;
DROP POLICY IF EXISTS "作者可更新自己的答案" ON answers;
DROP POLICY IF EXISTS "管理员和编辑可管理所有答案" ON answers;
DROP POLICY IF EXISTS "作者可删除自己的答案" ON answers;

-- ============================================
-- 4. 创建新的答案表策略
-- ============================================

-- 4.1 所有人（包括游客）可以查看所有答案
CREATE POLICY "公开访问所有答案" ON answers
  FOR SELECT 
  USING (true);

-- 4.2 已登录用户（会员）可以创建答案
CREATE POLICY "会员创建答案" ON answers
  FOR INSERT 
  TO authenticated 
  WITH CHECK (author_id = auth.uid());

-- 4.3 作者可以更新自己的答案
CREATE POLICY "作者更新自己的答案" ON answers
  FOR UPDATE 
  TO authenticated 
  USING (author_id = auth.uid());

-- 4.4 管理员和编辑可以管理所有答案
CREATE POLICY "管理员管理所有答案" ON answers
  FOR ALL 
  TO authenticated 
  USING (is_editor_or_admin(auth.uid()));

-- 4.5 作者可以删除自己的答案
CREATE POLICY "作者删除自己的答案" ON answers
  FOR DELETE 
  TO authenticated 
  USING (author_id = auth.uid());

-- ============================================
-- 5. 确保产品图片表的公开访问
-- ============================================

DROP POLICY IF EXISTS "所有人可查看产品图片" ON product_images;

CREATE POLICY "公开访问产品图片" ON product_images
  FOR SELECT 
  USING (true);

-- ============================================
-- 6. 确保分类表的公开访问
-- ============================================

DROP POLICY IF EXISTS "所有人可查看分类" ON categories;

CREATE POLICY "公开访问分类" ON categories
  FOR SELECT 
  USING (true);

-- ============================================
-- 7. 创建问题审核函数（供管理员使用）
-- ============================================

CREATE OR REPLACE FUNCTION approve_question(question_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 检查是否为管理员或编辑
  IF NOT is_editor_or_admin(auth.uid()) THEN
    RAISE EXCEPTION '只有管理员和编辑可以审核问题';
  END IF;
  
  -- 更新问题状态为已批准
  UPDATE questions 
  SET status = 'approved'::question_status, 
      updated_at = now()
  WHERE id = question_id;
END;
$$;

-- ============================================
-- 8. 创建问题拒绝函数（供管理员使用）
-- ============================================

CREATE OR REPLACE FUNCTION reject_question(question_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 检查是否为管理员或编辑
  IF NOT is_editor_or_admin(auth.uid()) THEN
    RAISE EXCEPTION '只有管理员和编辑可以拒绝问题';
  END IF;
  
  -- 删除问题
  DELETE FROM questions WHERE id = question_id;
END;
$$;

-- ============================================
-- 9. 添加游客问题提交字段（可选）
-- ============================================

-- 为游客提交的问题添加联系信息字段
ALTER TABLE questions ADD COLUMN IF NOT EXISTS guest_name text;
ALTER TABLE questions ADD COLUMN IF NOT EXISTS guest_email text;

-- 添加注释
COMMENT ON COLUMN questions.guest_name IS '游客提交问题时的姓名';
COMMENT ON COLUMN questions.guest_email IS '游客提交问题时的邮箱';
/*
# 允许公开读取用户基本信息

## 说明
为了让未登录用户能够查看文章、产品和问答的作者信息，需要允许匿名用户读取profiles表的基本信息。

## 变更内容
1. 添加策略允许所有人（包括匿名用户）读取profiles表的基本公开信息
2. 这不会暴露敏感信息，因为查询时只会选择公开字段（username, nickname, avatar_url等）

## 安全性
- 只允许SELECT操作
- 不允许INSERT、UPDATE、DELETE操作
- 敏感字段（如email、phone）在前端查询时不会被选择
*/

-- 添加策略：允许所有人（包括匿名用户）读取用户基本信息
CREATE POLICY "公开读取用户基本信息" ON profiles
  FOR SELECT TO anon, authenticated
  USING (true);
/*
# 创建LOGO图片存储桶

## 1. 新建存储桶
- 桶名称: `app-7fshtpomqha9_logos`
- 用途: 存储网站LOGO图片
- 文件大小限制: 1MB
- 允许的文件类型: image/png, image/jpeg, image/jpg, image/svg+xml, image/webp

## 2. 安全策略
- 所有人可以读取LOGO图片
- 仅管理员可以上传和删除LOGO图片

## 3. 初始化设置
- 在site_settings表中添加site_logo配置项
*/

-- 创建存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-7fshtpomqha9_logos',
  'app-7fshtpomqha9_logos',
  true,
  1048576,
  ARRAY['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- 允许所有人读取LOGO图片
CREATE POLICY "所有人可以查看LOGO图片"
ON storage.objects FOR SELECT
USING (bucket_id = 'app-7fshtpomqha9_logos');

-- 允许管理员上传LOGO图片
CREATE POLICY "管理员可以上传LOGO图片"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'app-7fshtpomqha9_logos' 
  AND is_admin(auth.uid())
);

-- 允许管理员删除LOGO图片
CREATE POLICY "管理员可以删除LOGO图片"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'app-7fshtpomqha9_logos' 
  AND is_admin(auth.uid())
);

-- 在site_settings表中添加site_logo配置项
INSERT INTO site_settings (key, value, description)
VALUES ('site_logo', '', '网站LOGO图片URL')
ON CONFLICT (key) DO NOTHING;
/*
# 创建幻灯片（Banner）表和存储桶

## 1. 新建表
- `banners` 表 - 首页幻灯片
  - `id` (uuid, 主键)
  - `title` (text, 标题)
  - `subtitle` (text, 副标题)
  - `image_url` (text, 图片URL)
  - `link_url` (text, 链接URL，可选)
  - `link_text` (text, 链接文字，可选)
  - `sort_order` (int, 排序，默认0)
  - `is_active` (boolean, 是否启用，默认true)
  - `created_at` (timestamptz, 创建时间)
  - `updated_at` (timestamptz, 更新时间)

## 2. 存储桶
- 桶名称: `app-7fshtpomqha9_banners`
- 用途: 存储幻灯片图片
- 文件大小限制: 2MB
- 允许的文件类型: image/png, image/jpeg, image/jpg, image/webp

## 3. 安全策略
- banners表: 所有人可读，仅管理员和编辑可管理
- 存储桶: 所有人可读，仅管理员和编辑可上传/删除
*/

-- 创建banners表
CREATE TABLE IF NOT EXISTS banners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  subtitle text,
  image_url text NOT NULL,
  link_url text,
  link_text text,
  sort_order int DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX idx_banners_sort_order ON banners(sort_order);
CREATE INDEX idx_banners_is_active ON banners(is_active);

-- 创建更新时间触发器
CREATE TRIGGER update_banners_updated_at 
  BEFORE UPDATE ON banners
  FOR EACH ROW 
  EXECUTE FUNCTION update_updated_at();

-- 启用RLS
ALTER TABLE banners ENABLE ROW LEVEL SECURITY;

-- 所有人可以查看启用的幻灯片
CREATE POLICY "所有人可查看启用的幻灯片" ON banners
  FOR SELECT USING (is_active = true);

-- 管理员和编辑可以查看所有幻灯片
CREATE POLICY "管理员和编辑可查看所有幻灯片" ON banners
  FOR SELECT TO authenticated
  USING (is_editor_or_admin(auth.uid()));

-- 管理员和编辑可以管理幻灯片
CREATE POLICY "管理员和编辑可管理幻灯片" ON banners
  FOR ALL TO authenticated
  USING (is_editor_or_admin(auth.uid()));

-- 创建存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-7fshtpomqha9_banners',
  'app-7fshtpomqha9_banners',
  true,
  2097152,
  ARRAY['image/png', 'image/jpeg', 'image/jpg', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- 允许所有人读取幻灯片图片
CREATE POLICY "所有人可以查看幻灯片图片"
ON storage.objects FOR SELECT
USING (bucket_id = 'app-7fshtpomqha9_banners');

-- 允许管理员和编辑上传幻灯片图片
CREATE POLICY "管理员和编辑可以上传幻灯片图片"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'app-7fshtpomqha9_banners' 
  AND is_editor_or_admin(auth.uid())
);

-- 允许管理员和编辑删除幻灯片图片
CREATE POLICY "管理员和编辑可以删除幻灯片图片"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'app-7fshtpomqha9_banners' 
  AND is_editor_or_admin(auth.uid())
);

-- 插入示例幻灯片数据
INSERT INTO banners (title, subtitle, image_url, link_url, link_text, sort_order, is_active) VALUES
('欢迎使用CMS内容管理系统', '专业的内容管理平台，集成文章发布、产品展示、问答系统等功能', 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=400&fit=crop', '/articles', '浏览文章', 1, true),
('强大的产品展示功能', '支持多图展示、详细描述、分类管理等完整的产品管理功能', 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=400&fit=crop', '/products', '查看产品', 2, true),
('互动问答社区', '会员可以提问，管理员和编辑可以回答，构建知识分享平台', 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1200&h=400&fit=crop', '/questions', '参与问答', 3, true);
/*
# 创建下载和视频模块

## 1. 新增表

### downloads 表
- `id` (uuid, 主键)
- `title` (text, 标题, 必填)
- `description` (text, 描述)
- `content` (text, 详细内容)
- `category_id` (uuid, 分类ID, 外键)
- `file_url` (text, 文件URL, 必填)
- `file_name` (text, 文件名)
- `file_size` (bigint, 文件大小，字节)
- `file_type` (text, 文件类型)
- `cover_image` (text, 封面图)
- `download_count` (integer, 下载次数, 默认0)
- `require_member` (boolean, 是否需要会员, 默认true)
- `is_published` (boolean, 是否发布, 默认false)
- `author_id` (uuid, 作者ID, 外键)
- `created_at` (timestamptz, 创建时间)
- `updated_at` (timestamptz, 更新时间)

### videos 表
- `id` (uuid, 主键)
- `title` (text, 标题, 必填)
- `description` (text, 描述)
- `content` (text, 详细内容)
- `category_id` (uuid, 分类ID, 外键)
- `video_url` (text, 视频URL, 必填)
- `cover_image` (text, 封面图)
- `duration` (integer, 时长，秒)
- `view_count` (integer, 观看次数, 默认0)
- `is_published` (boolean, 是否发布, 默认false)
- `author_id` (uuid, 作者ID, 外键)
- `created_at` (timestamptz, 创建时间)
- `updated_at` (timestamptz, 更新时间)

## 2. 存储桶
- `app-7fshtpomqha9_downloads`: 存储下载文件（最大50MB）
- `app-7fshtpomqha9_videos`: 存储视频文件（最大500MB）
- `app-7fshtpomqha9_video_covers`: 存储视频封面图（最大2MB）

## 3. 安全策略
- downloads表：公开可读已发布内容，管理员和编辑可管理
- videos表：公开可读已发布内容，管理员和编辑可管理
- 存储桶：公开可读，管理员和编辑可上传/删除

## 4. RPC函数
- increment_download_count: 增加下载次数
- increment_video_view_count: 增加视频观看次数
*/

-- 修改categories表的type约束，添加download和video类型
ALTER TABLE categories DROP CONSTRAINT IF EXISTS categories_type_check;
ALTER TABLE categories ADD CONSTRAINT categories_type_check 
  CHECK (type IN ('article', 'product', 'question', 'download', 'video'));

-- 创建downloads表
CREATE TABLE IF NOT EXISTS downloads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  content text,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  file_url text NOT NULL,
  file_name text,
  file_size bigint,
  file_type text,
  cover_image text,
  download_count integer DEFAULT 0,
  require_member boolean DEFAULT true,
  is_published boolean DEFAULT false,
  author_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建videos表
CREATE TABLE IF NOT EXISTS videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  content text,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  video_url text NOT NULL,
  cover_image text,
  duration integer,
  view_count integer DEFAULT 0,
  is_published boolean DEFAULT false,
  author_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_downloads_category ON downloads(category_id);
CREATE INDEX IF NOT EXISTS idx_downloads_author ON downloads(author_id);
CREATE INDEX IF NOT EXISTS idx_downloads_published ON downloads(is_published);
CREATE INDEX IF NOT EXISTS idx_downloads_created ON downloads(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_videos_category ON videos(category_id);
CREATE INDEX IF NOT EXISTS idx_videos_author ON videos(author_id);
CREATE INDEX IF NOT EXISTS idx_videos_published ON videos(is_published);
CREATE INDEX IF NOT EXISTS idx_videos_created ON videos(created_at DESC);

-- 启用RLS
ALTER TABLE downloads ENABLE ROW LEVEL SECURITY;
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;

-- downloads表策略
CREATE POLICY "公开可读已发布的下载" ON downloads
  FOR SELECT USING (is_published = true);

CREATE POLICY "管理员和编辑可查看所有下载" ON downloads
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "管理员和编辑可创建下载" ON downloads
  FOR INSERT TO authenticated WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "管理员和编辑可更新下载" ON downloads
  FOR UPDATE TO authenticated USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "管理员和编辑可删除下载" ON downloads
  FOR DELETE TO authenticated USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

-- videos表策略
CREATE POLICY "公开可读已发布的视频" ON videos
  FOR SELECT USING (is_published = true);

CREATE POLICY "管理员和编辑可查看所有视频" ON videos
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "管理员和编辑可创建视频" ON videos
  FOR INSERT TO authenticated WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "管理员和编辑可更新视频" ON videos
  FOR UPDATE TO authenticated USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "管理员和编辑可删除视频" ON videos
  FOR DELETE TO authenticated USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

-- 创建存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
  ('app-7fshtpomqha9_downloads', 'app-7fshtpomqha9_downloads', true, 52428800, ARRAY['application/pdf', 'application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'text/plain']),
  ('app-7fshtpomqha9_videos', 'app-7fshtpomqha9_videos', true, 524288000, ARRAY['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime']),
  ('app-7fshtpomqha9_video_covers', 'app-7fshtpomqha9_video_covers', true, 2097152, ARRAY['image/png', 'image/jpeg', 'image/jpg', 'image/webp'])
ON CONFLICT (id) DO NOTHING;

-- 存储桶策略 - downloads
CREATE POLICY "公开可查看下载文件" ON storage.objects
  FOR SELECT USING (bucket_id = 'app-7fshtpomqha9_downloads');

CREATE POLICY "管理员和编辑可上传下载文件" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (
    bucket_id = 'app-7fshtpomqha9_downloads'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "管理员和编辑可删除下载文件" ON storage.objects
  FOR DELETE TO authenticated USING (
    bucket_id = 'app-7fshtpomqha9_downloads'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

-- 存储桶策略 - videos
CREATE POLICY "公开可查看视频文件" ON storage.objects
  FOR SELECT USING (bucket_id = 'app-7fshtpomqha9_videos');

CREATE POLICY "管理员和编辑可上传视频文件" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (
    bucket_id = 'app-7fshtpomqha9_videos'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "管理员和编辑可删除视频文件" ON storage.objects
  FOR DELETE TO authenticated USING (
    bucket_id = 'app-7fshtpomqha9_videos'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

-- 存储桶策略 - video_covers
CREATE POLICY "公开可查看视频封面" ON storage.objects
  FOR SELECT USING (bucket_id = 'app-7fshtpomqha9_video_covers');

CREATE POLICY "管理员和编辑可上传视频封面" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (
    bucket_id = 'app-7fshtpomqha9_video_covers'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "管理员和编辑可删除视频封面" ON storage.objects
  FOR DELETE TO authenticated USING (
    bucket_id = 'app-7fshtpomqha9_video_covers'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

-- 创建RPC函数：增加下载次数
CREATE OR REPLACE FUNCTION increment_download_count(download_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE downloads
  SET download_count = download_count + 1
  WHERE id = download_id;
END;
$$;

-- 创建RPC函数：增加视频观看次数
CREATE OR REPLACE FUNCTION increment_video_view_count(video_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE videos
  SET view_count = view_count + 1
  WHERE id = video_id;
END;
$$;

-- 插入示例下载分类
INSERT INTO categories (name, slug, type, description)
VALUES 
  ('软件工具', 'software-tools', 'download', '各类软件和工具下载'),
  ('文档资料', 'documents', 'download', '文档、教程等资料下载'),
  ('源码模板', 'source-code', 'download', '源代码和模板下载')
ON CONFLICT DO NOTHING;

-- 插入示例视频分类
INSERT INTO categories (name, slug, type, description)
VALUES 
  ('教程视频', 'tutorial-videos', 'video', '各类教程和培训视频'),
  ('产品演示', 'product-demos', 'video', '产品功能演示视频'),
  ('活动回顾', 'event-reviews', 'video', '活动和会议回顾视频')
ON CONFLICT DO NOTHING;

-- 插入示例下载数据
INSERT INTO downloads (title, description, content, file_url, file_name, file_size, file_type, require_member, is_published, category_id)
SELECT 
  '示例下载文件',
  '这是一个示例下载文件，仅供会员下载',
  '<p>这是一个示例下载文件的详细说明。</p><p>包含以下内容：</p><ul><li>功能介绍</li><li>使用说明</li><li>注意事项</li></ul>',
  'https://example.com/sample.pdf',
  'sample.pdf',
  1024000,
  'application/pdf',
  true,
  true,
  id
FROM categories WHERE name = '文档资料' AND type = 'download'
LIMIT 1;

-- 插入示例视频数据
INSERT INTO videos (title, description, content, video_url, cover_image, duration, is_published, category_id)
SELECT 
  '示例教程视频',
  '这是一个示例教程视频',
  '<p>这是一个示例教程视频的详细介绍。</p><p>视频内容包括：</p><ul><li>基础知识讲解</li><li>实战演示</li><li>常见问题解答</li></ul>',
  'https://example.com/sample.mp4',
  'https://images.unsplash.com/photo-1492619375914-88005aa9e8fb?w=800',
  1800,
  true,
  id
FROM categories WHERE name = '教程视频' AND type = 'video'
LIMIT 1;
/*
# 添加页脚版权设置

## 说明
为网站添加页脚版权相关的配置项，包括：
- 公司名称
- 版权信息
- 关于我们
- 联系地址
- 联系电话
- 营业时间
- ICP备案号
- 公安备案号

## 新增设置项
- `company_name`: 公司/组织名称
- `copyright_text`: 版权文本（自动添加年份）
- `about_us`: 关于我们的简介
- `contact_address`: 联系地址
- `contact_phone`: 联系电话
- `business_hours`: 营业时间
- `icp_number`: ICP备案号
- `police_number`: 公安备案号
- `footer_links`: 页脚链接（JSON格式）

## 安全性
- 所有设置项公开可读
- 仅管理员可修改
*/

-- 插入页脚版权相关设置
INSERT INTO site_settings (key, value, description) VALUES
  ('company_name', 'CMS内容管理系统', '公司/组织名称'),
  ('copyright_text', 'CMS内容管理系统', '版权文本'),
  ('about_us', '我们致力于提供专业的内容管理解决方案，帮助企业和个人更好地管理和展示内容。', '关于我们简介'),
  ('contact_address', '', '联系地址'),
  ('contact_phone', '', '联系电话'),
  ('business_hours', '周一至周五 9:00-18:00', '营业时间'),
  ('icp_number', '', 'ICP备案号'),
  ('police_number', '', '公安备案号'),
  ('footer_links', '[]', '页脚链接（JSON格式）')
ON CONFLICT (key) DO UPDATE SET
  description = EXCLUDED.description;
/*
# 创建模版管理表

## 1. 新建表
- `templates`
  - `id` (uuid, 主键)
  - `name` (text, 模版名称, 必填)
  - `description` (text, 模版描述)
  - `file_path` (text, 文件路径, 必填, 唯一)
  - `content` (text, 模版源码内容, 必填)
  - `file_type` (text, 文件类型: tsx, css, json等)
  - `category` (text, 分类: page, component, style, config)
  - `is_active` (boolean, 是否启用, 默认true)
  - `created_at` (timestamptz, 创建时间)
  - `updated_at` (timestamptz, 更新时间)

## 2. 安全策略
- 不启用RLS，因为只有管理员通过后台访问
- 所有操作都在管理后台进行，由前端权限控制

## 3. 初始数据
- 添加一些默认模版文件供管理
*/

-- 创建模版表
CREATE TABLE IF NOT EXISTS templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  file_path text NOT NULL UNIQUE,
  content text NOT NULL,
  file_type text NOT NULL DEFAULT 'tsx',
  category text NOT NULL DEFAULT 'page',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX idx_templates_category ON templates(category);
CREATE INDEX idx_templates_is_active ON templates(is_active);
CREATE INDEX idx_templates_file_type ON templates(file_type);

-- 插入默认模版数据
INSERT INTO templates (name, description, file_path, content, file_type, category) VALUES
(
  '首页Banner模版',
  '首页顶部Banner区域的展示模版',
  'src/components/templates/HomeBanner.tsx',
  E'import { Link } from "react-router-dom";\nimport { Button } from "@/components/ui/button";\nimport { FileText, Package } from "lucide-react";\n\ninterface HomeBannerProps {\n  siteName: string;\n}\n\nexport default function HomeBanner({ siteName }: HomeBannerProps) {\n  return (\n    <section className="relative py-20 xl:py-32 px-4 overflow-hidden">\n      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background"></div>\n      <div className="container mx-auto relative z-10">\n        <div className="max-w-4xl mx-auto text-center space-y-6">\n          <h1 className="text-4xl xl:text-6xl font-bold tracking-tight">\n            <span className="gradient-text">{siteName}</span>\n          </h1>\n          <p className="text-xl xl:text-2xl text-muted-foreground">\n            专业的内容管理平台,集成文章发布、产品展示、问答系统等功能\n          </p>\n          <div className="flex flex-wrap gap-4 justify-center pt-4">\n            <Button size="lg" asChild>\n              <Link to="/articles">\n                <FileText className="mr-2 h-5 w-5" />\n                浏览文章\n              </Link>\n            </Button>\n            <Button size="lg" variant="outline" asChild>\n              <Link to="/products">\n                <Package className="mr-2 h-5 w-5" />\n                查看产品\n              </Link>\n            </Button>\n          </div>\n        </div>\n      </div>\n    </section>\n  );\n}',
  'tsx',
  'component'
),
(
  '文章卡片模版',
  '文章列表展示卡片组件模版',
  'src/components/templates/ArticleCard.tsx',
  E'import { Link } from "react-router-dom";\nimport { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";\nimport { Badge } from "@/components/ui/badge";\nimport { Calendar, User } from "lucide-react";\nimport type { ArticleWithAuthor } from "@/types";\n\ninterface ArticleCardProps {\n  article: ArticleWithAuthor;\n}\n\nexport default function ArticleCard({ article }: ArticleCardProps) {\n  return (\n    <Card className="hover:shadow-lg transition-shadow h-full flex flex-col">\n      <CardHeader>\n        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">\n          <Calendar className="h-4 w-4" />\n          <span>{new Date(article.created_at).toLocaleDateString()}</span>\n          <User className="h-4 w-4 ml-2" />\n          <span>{article.author?.username || "匿名"}</span>\n        </div>\n        <CardTitle className="line-clamp-2">\n          <Link to={`/articles/${article.id}`} className="hover:text-primary transition-colors">\n            {article.title}\n          </Link>\n        </CardTitle>\n      </CardHeader>\n      <CardContent className="flex-1 flex flex-col">\n        <CardDescription className="line-clamp-3 flex-1">\n          {article.summary || article.content.substring(0, 150)}\n        </CardDescription>\n        {article.category && (\n          <div className="mt-4">\n            <Badge variant="secondary">{article.category.name}</Badge>\n          </div>\n        )}\n      </CardContent>\n    </Card>\n  );\n}',
  'tsx',
  'component'
),
(
  '产品卡片模版',
  '产品列表展示卡片组件模版',
  'src/components/templates/ProductCard.tsx',
  E'import { Link } from "react-router-dom";\nimport { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";\nimport { Badge } from "@/components/ui/badge";\nimport type { ProductWithImages } from "@/types";\n\ninterface ProductCardProps {\n  product: ProductWithImages;\n}\n\nexport default function ProductCard({ product }: ProductCardProps) {\n  const mainImage = product.images?.[0]?.image_url;\n  \n  return (\n    <Card className="hover:shadow-lg transition-shadow h-full flex flex-col overflow-hidden">\n      {mainImage && (\n        <div className="aspect-video w-full overflow-hidden bg-muted">\n          <img\n            src={mainImage}\n            alt={product.name}\n            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"\n          />\n        </div>\n      )}\n      <CardHeader>\n        <CardTitle className="line-clamp-2">\n          <Link to={`/products/${product.id}`} className="hover:text-primary transition-colors">\n            {product.name}\n          </Link>\n        </CardTitle>\n      </CardHeader>\n      <CardContent className="flex-1 flex flex-col">\n        <CardDescription className="line-clamp-3 flex-1">\n          {product.description}\n        </CardDescription>\n        <div className="mt-4 flex items-center justify-between">\n          {product.price && (\n            <span className="text-2xl font-bold text-primary">\n              ¥{product.price}\n            </span>\n          )}\n          {product.category && (\n            <Badge variant="secondary">{product.category.name}</Badge>\n          )}\n        </div>\n      </CardContent>\n    </Card>\n  );\n}',
  'tsx',
  'component'
),
(
  '自定义样式模版',
  '自定义CSS样式定义',
  'src/styles/custom.css',
  E'/* 自定义样式模版 */\n\n/* 渐变文字效果 */\n.gradient-text {\n  background: linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary-glow)));\n  -webkit-background-clip: text;\n  background-clip: text;\n  -webkit-text-fill-color: transparent;\n  color: transparent;\n}\n\n/* 卡片悬停效果 */\n.card-hover {\n  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);\n}\n\n.card-hover:hover {\n  transform: translateY(-4px);\n  box-shadow: 0 10px 30px -10px hsl(var(--primary) / 0.3);\n}\n\n/* 按钮发光效果 */\n.button-glow {\n  box-shadow: 0 0 20px hsl(var(--primary) / 0.5);\n}\n\n/* 动画效果 */\n@keyframes fadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(20px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n\n.animate-fade-in {\n  animation: fadeIn 0.6s ease-out;\n}',
  'css',
  'style'
);
/*
# 添加HTML格式的动态模版

## 1. 说明
- 添加可在前端动态渲染的HTML模版
- 支持模版变量替换，如 {{title}}, {{description}} 等
- 管理员可以在后台修改这些模版，前端会自动加载最新内容

## 2. 模版类别
- banner: 首页横幅模版
- article-card: 文章卡片模版
- product-card: 产品卡片模版
- custom-section: 自定义区块模版

## 3. 使用方式
- 在前端使用 TemplateRenderer 组件加载模版
- 传入 category 和可选的 name 参数
- 传入 data 对象用于变量替换
*/

-- 插入HTML格式的动态模版
INSERT INTO templates (name, description, file_path, content, file_type, category) VALUES
(
  '首页横幅HTML模版',
  '首页顶部横幅区域，支持变量: {{siteName}}, {{description}}',
  'templates/banner/home-banner.html',
  E'<div class="relative py-20 px-4 overflow-hidden">\n  <div class="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background"></div>\n  <div class="container mx-auto relative z-10">\n    <div class="max-w-4xl mx-auto text-center space-y-6">\n      <h1 class="text-4xl xl:text-6xl font-bold tracking-tight">\n        <span class="gradient-text">{{siteName}}</span>\n      </h1>\n      <p class="text-xl xl:text-2xl text-muted-foreground">\n        {{description}}\n      </p>\n      <div class="flex flex-wrap gap-4 justify-center pt-4">\n        <a href="/articles" class="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-11 px-8">\n          浏览文章\n        </a>\n        <a href="/products" class="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-11 px-8">\n          查看产品\n        </a>\n      </div>\n    </div>\n  </div>\n</div>',
  'html',
  'banner'
),
(
  '通知横幅模版',
  '页面顶部通知横幅，支持变量: {{message}}, {{linkText}}, {{linkUrl}}',
  'templates/banner/notice-banner.html',
  E'<div class="bg-primary text-primary-foreground py-3 px-4">\n  <div class="container mx-auto">\n    <div class="flex items-center justify-center gap-4 text-sm xl:text-base">\n      <span>{{message}}</span>\n      <a href="{{linkUrl}}" class="underline hover:no-underline font-medium">\n        {{linkText}}\n      </a>\n    </div>\n  </div>\n</div>',
  'html',
  'banner'
),
(
  '特色区块模版',
  '展示网站特色功能，支持变量: {{title}}, {{subtitle}}, {{feature1}}, {{feature2}}, {{feature3}}',
  'templates/section/features.html',
  E'<div class="py-16 px-4">\n  <div class="container mx-auto">\n    <div class="text-center mb-12">\n      <h2 class="text-3xl xl:text-4xl font-bold mb-4">{{title}}</h2>\n      <p class="text-xl text-muted-foreground">{{subtitle}}</p>\n    </div>\n    <div class="grid grid-cols-1 xl:grid-cols-3 gap-8">\n      <div class="text-center p-6 rounded-lg border bg-card">\n        <div class="text-4xl mb-4">📝</div>\n        <h3 class="text-xl font-semibold mb-2">{{feature1}}</h3>\n        <p class="text-muted-foreground">专业的内容管理和发布系统</p>\n      </div>\n      <div class="text-center p-6 rounded-lg border bg-card">\n        <div class="text-4xl mb-4">📦</div>\n        <h3 class="text-xl font-semibold mb-2">{{feature2}}</h3>\n        <p class="text-muted-foreground">完善的产品展示和管理功能</p>\n      </div>\n      <div class="text-center p-6 rounded-lg border bg-card">\n        <div class="text-4xl mb-4">💬</div>\n        <h3 class="text-xl font-semibold mb-2">{{feature3}}</h3>\n        <p class="text-muted-foreground">互动问答社区系统</p>\n      </div>\n    </div>\n  </div>\n</div>',
  'html',
  'section'
),
(
  '统计数据展示模版',
  '展示网站统计数据，支持变量: {{articles}}, {{products}}, {{questions}}, {{users}}',
  'templates/section/stats.html',
  E'<div class="py-12 px-4 bg-muted/50">\n  <div class="container mx-auto">\n    <div class="grid grid-cols-2 xl:grid-cols-4 gap-8">\n      <div class="text-center">\n        <div class="text-4xl xl:text-5xl font-bold text-primary mb-2">{{articles}}</div>\n        <div class="text-muted-foreground">文章数量</div>\n      </div>\n      <div class="text-center">\n        <div class="text-4xl xl:text-5xl font-bold text-primary mb-2">{{products}}</div>\n        <div class="text-muted-foreground">产品数量</div>\n      </div>\n      <div class="text-center">\n        <div class="text-4xl xl:text-5xl font-bold text-primary mb-2">{{questions}}</div>\n        <div class="text-muted-foreground">问答数量</div>\n      </div>\n      <div class="text-center">\n        <div class="text-4xl xl:text-5xl font-bold text-primary mb-2">{{users}}</div>\n        <div class="text-muted-foreground">用户数量</div>\n      </div>\n    </div>\n  </div>\n</div>',
  'html',
  'section'
),
(
  'CTA行动号召模版',
  '引导用户行动的区块，支持变量: {{title}}, {{description}}, {{buttonText}}, {{buttonUrl}}',
  'templates/section/cta.html',
  E'<div class="py-20 px-4">\n  <div class="container mx-auto">\n    <div class="max-w-3xl mx-auto text-center bg-gradient-to-br from-primary/10 to-primary/5 rounded-2xl p-12 border border-primary/20">\n      <h2 class="text-3xl xl:text-4xl font-bold mb-4">{{title}}</h2>\n      <p class="text-xl text-muted-foreground mb-8">{{description}}</p>\n      <a href="{{buttonUrl}}" class="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-11 px-8 text-lg">\n        {{buttonText}}\n      </a>\n    </div>\n  </div>\n</div>',
  'html',
  'section'
);
/*
# Create Slides Images Storage Bucket

## Purpose
Create a dedicated Supabase Storage bucket for storing slide images with appropriate policies.

## Bucket Configuration
- Name: app-7fshtpomqha9_slides_images
- Public access: Enabled (for displaying images)
- File size limit: 1MB (enforced on frontend)
- Allowed MIME types: image/jpeg, image/png, image/gif, image/webp, image/avif

## Security Policies
- Public read access: All users can view images
- Upload access: Admins only (using is_admin function)
- Delete access: Admins only

## Notes
- Frontend will handle automatic compression for files > 1MB
- Images will be converted to WEBP format with quality 0.8
- Maximum resolution: 1080p (preserving aspect ratio)
*/

-- Create the slides images bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-7fshtpomqha9_slides_images',
  'app-7fshtpomqha9_slides_images',
  true,
  1048576, -- 1MB in bytes
  ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif']
)
ON CONFLICT (id) DO NOTHING;

-- Policy: Allow public read access to all images
CREATE POLICY "Public read access for slide images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'app-7fshtpomqha9_slides_images');

-- Policy: Allow admins to upload images
CREATE POLICY "Admins can upload slide images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'app-7fshtpomqha9_slides_images' 
  AND is_admin(auth.uid())
);

-- Policy: Allow admins to update images
CREATE POLICY "Admins can update slide images"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'app-7fshtpomqha9_slides_images' 
  AND is_admin(auth.uid())
);

-- Policy: Allow admins to delete images
CREATE POLICY "Admins can delete slide images"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'app-7fshtpomqha9_slides_images' 
  AND is_admin(auth.uid())
);
/*
# 扩展module_type枚举类型

## 说明
为module_type枚举添加download和video类型，以支持下载和视频模块的设置管理

## 更新内容
- 添加'download'到module_type枚举
- 添加'video'到module_type枚举
*/

-- 扩展module_type枚举类型，添加download和video
ALTER TYPE module_type ADD VALUE IF NOT EXISTS 'download';
ALTER TYPE module_type ADD VALUE IF NOT EXISTS 'video';
/*
# 添加下载和视频模块设置

## 说明
为下载和视频模块添加模块设置，包括权限控制功能

## 更新内容
1. 创建下载模块设置，添加require_login_to_download权限控制
2. 创建视频模块设置，添加require_login_to_watch权限控制

## 默认设置
- 默认不需要登录即可下载和观看（false）
- 管理员可以在后台修改这些设置
*/

-- 如果下载模块不存在，则创建
INSERT INTO module_settings (
  module_type,
  display_name,
  seo_title,
  seo_keywords,
  seo_description,
  is_enabled,
  sort_order,
  items_per_page,
  show_author,
  show_date,
  show_category,
  allow_comments,
  custom_settings
)
VALUES (
  'download',
  '下载中心',
  '下载中心 - 资源下载',
  '下载,资源,文件',
  '提供各类资源文件下载',
  true,
  3,
  12,
  true,
  true,
  true,
  false,
  '{"require_login_to_download": false}'::jsonb
)
ON CONFLICT (module_type) DO UPDATE
SET custom_settings = jsonb_set(
  COALESCE(module_settings.custom_settings, '{}'::jsonb),
  '{require_login_to_download}',
  'false'::jsonb
);

-- 如果视频模块不存在，则创建
INSERT INTO module_settings (
  module_type,
  display_name,
  seo_title,
  seo_keywords,
  seo_description,
  is_enabled,
  sort_order,
  items_per_page,
  show_author,
  show_date,
  show_category,
  allow_comments,
  custom_settings
)
VALUES (
  'video',
  '视频中心',
  '视频中心 - 在线视频',
  '视频,在线观看,教程',
  '提供各类视频在线观看',
  true,
  4,
  12,
  true,
  true,
  true,
  false,
  '{"require_login_to_watch": false}'::jsonb
)
ON CONFLICT (module_type) DO UPDATE
SET custom_settings = jsonb_set(
  COALESCE(module_settings.custom_settings, '{}'::jsonb),
  '{require_login_to_watch}',
  'false'::jsonb
);
/*
# 添加产品推荐功能

## 说明
为产品表添加推荐标记字段，支持在后台管理中设置推荐产品

## 更新内容
1. 添加is_featured字段到products表
   - is_featured (boolean, 默认: false) - 是否为推荐产品

## 功能说明
- 管理员可以在后台将产品标记为推荐
- 推荐产品可以在首页或特殊位置展示
- 默认所有产品不是推荐产品
*/

-- 添加is_featured字段到products表
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS is_featured boolean DEFAULT false NOT NULL;

-- 创建索引以提高推荐产品查询性能
CREATE INDEX IF NOT EXISTS idx_products_featured 
ON products(is_featured) 
WHERE is_featured = true;

-- 添加注释
COMMENT ON COLUMN products.is_featured IS '是否为推荐产品';
/*
# 会员系统升级 - Part 1: 表结构和基础函数

## 1. 扩展profiles表
## 2. 创建新表
## 3. 创建基础函数
*/

-- ============================================
-- 1. 扩展profiles表
-- ============================================

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS points int DEFAULT 0 NOT NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS level int DEFAULT 1 NOT NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS country text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS address text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS postal_code text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS bio text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS total_articles int DEFAULT 0 NOT NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS total_questions int DEFAULT 0 NOT NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS total_answers int DEFAULT 0 NOT NULL;

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_profiles_points ON profiles(points DESC);
CREATE INDEX IF NOT EXISTS idx_profiles_level ON profiles(level);

-- ============================================
-- 2. 创建会员等级配置表
-- ============================================

CREATE TABLE IF NOT EXISTS member_levels (
  id int PRIMARY KEY,
  name text NOT NULL,
  min_points int NOT NULL,
  max_points int,
  benefits jsonb DEFAULT '{}',
  badge_color text DEFAULT '#gray',
  created_at timestamptz DEFAULT now()
);

-- 插入默认等级配置
INSERT INTO member_levels (id, name, min_points, max_points, benefits, badge_color) VALUES
  (1, '新手会员', 0, 99, '{"description": "欢迎加入", "features": ["基础浏览", "提问功能"]}', '#94a3b8'),
  (2, '初级会员', 100, 499, '{"description": "积极参与", "features": ["发布文章", "优先回答", "专属徽章"]}', '#3b82f6'),
  (3, '中级会员', 500, 1999, '{"description": "活跃用户", "features": ["文章推荐", "专属标识", "优先审核"]}', '#8b5cf6'),
  (4, '高级会员', 2000, 4999, '{"description": "资深用户", "features": ["内容置顶", "专属客服", "高级权限"]}', '#f59e0b'),
  (5, 'VIP会员', 5000, NULL, '{"description": "尊贵身份", "features": ["全站特权", "专属顾问", "优先支持", "定制服务"]}', '#ef4444')
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- 3. 创建积分记录表
-- ============================================

CREATE TABLE IF NOT EXISTS member_points_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  points int NOT NULL,
  reason text NOT NULL,
  reference_type text,
  reference_id uuid,
  created_at timestamptz DEFAULT now()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_points_log_user ON member_points_log(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_points_log_reference ON member_points_log(reference_type, reference_id);

-- ============================================
-- 4. 创建浏览记录表
-- ============================================

CREATE TABLE IF NOT EXISTS browsing_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content_type text NOT NULL,
  content_id uuid NOT NULL,
  content_title text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_browsing_history_user ON browsing_history(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_browsing_history_content ON browsing_history(content_type, content_id);

-- ============================================
-- 5. 创建会员提交内容审核表
-- ============================================

CREATE TABLE IF NOT EXISTS member_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content_type text NOT NULL,
  content_id uuid NOT NULL,
  status text DEFAULT 'pending' NOT NULL,
  reviewer_id uuid REFERENCES profiles(id),
  review_note text,
  submitted_at timestamptz DEFAULT now(),
  reviewed_at timestamptz
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_submissions_user ON member_submissions(user_id, submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_submissions_status ON member_submissions(status, submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_submissions_content ON member_submissions(content_type, content_id);

-- ============================================
-- 6. 创建辅助函数 - 检查是否为编辑
-- ============================================

CREATE OR REPLACE FUNCTION is_editor(uid uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role IN ('editor'::user_role, 'admin'::user_role)
  );
$$;

-- ============================================
-- 7. 创建积分管理函数
-- ============================================

-- 更新会员等级函数
CREATE OR REPLACE FUNCTION update_member_level(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_points int;
  v_new_level int;
BEGIN
  -- 获取当前积分
  SELECT points INTO v_points
  FROM profiles
  WHERE id = p_user_id;
  
  -- 根据积分确定等级
  SELECT id INTO v_new_level
  FROM member_levels
  WHERE min_points <= v_points
    AND (max_points IS NULL OR max_points >= v_points)
  ORDER BY min_points DESC
  LIMIT 1;
  
  -- 更新等级
  IF v_new_level IS NOT NULL THEN
    UPDATE profiles
    SET level = v_new_level,
        updated_at = now()
    WHERE id = p_user_id;
  END IF;
END;
$$;

-- 添加积分函数
CREATE OR REPLACE FUNCTION add_member_points(
  p_user_id uuid,
  p_points int,
  p_reason text,
  p_reference_type text DEFAULT NULL,
  p_reference_id uuid DEFAULT NULL
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 更新用户积分
  UPDATE profiles
  SET points = points + p_points,
      updated_at = now()
  WHERE id = p_user_id;
  
  -- 记录积分变化
  INSERT INTO member_points_log (user_id, points, reason, reference_type, reference_id)
  VALUES (p_user_id, p_points, p_reason, p_reference_type, p_reference_id);
  
  -- 更新会员等级
  PERFORM update_member_level(p_user_id);
END;
$$;

-- ============================================
-- 8. 创建浏览记录函数
-- ============================================

CREATE OR REPLACE FUNCTION add_browsing_history(
  p_user_id uuid,
  p_content_type text,
  p_content_id uuid,
  p_content_title text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 删除该用户对该内容的旧记录（保持唯一性）
  DELETE FROM browsing_history
  WHERE user_id = p_user_id
    AND content_type = p_content_type
    AND content_id = p_content_id;
  
  -- 插入新记录
  INSERT INTO browsing_history (user_id, content_type, content_id, content_title)
  VALUES (p_user_id, p_content_type, p_content_id, p_content_title);
  
  -- 限制每个用户的浏览记录数量（保留最近100条）
  DELETE FROM browsing_history
  WHERE id IN (
    SELECT id FROM browsing_history
    WHERE user_id = p_user_id
    ORDER BY created_at DESC
    OFFSET 100
  );
END;
$$;

COMMENT ON TABLE member_levels IS '会员等级配置表';
COMMENT ON TABLE member_points_log IS '会员积分记录表';
COMMENT ON TABLE browsing_history IS '会员浏览记录表';
COMMENT ON TABLE member_submissions IS '会员提交内容审核表';
/*
# 会员系统升级 - 完整功能集成

## 1. 新增字段到profiles表
- `points` (int, 积分, 默认0)
- `level` (int, 会员等级, 默认1)
- `country` (text, 国家)
- `address` (text, 地址)
- `city` (text, 城市)
- `postal_code` (text, 邮编)
- `bio` (text, 个人简介)
- `total_articles` (int, 发布文章总数, 默认0)
- `total_questions` (int, 提问总数, 默认0)
- `total_answers` (int, 回答总数, 默认0)

## 2. 新建表

### 2.1 member_levels - 会员等级配置表
- `id` (int, 主键)
- `name` (text, 等级名称)
- `min_points` (int, 最低积分要求)
- `max_points` (int, 最高积分, null表示无上限)
- `benefits` (jsonb, 等级权益)
- `badge_color` (text, 徽章颜色)

### 2.2 member_points_log - 积分记录表
- `id` (uuid, 主键)
- `user_id` (uuid, 用户ID)
- `points` (int, 积分变化, 正数为增加, 负数为减少)
- `reason` (text, 原因)
- `reference_type` (text, 关联类型: article/question/answer/login/purchase)
- `reference_id` (uuid, 关联ID, 可为空)
- `created_at` (timestamptz, 创建时间)

### 2.3 browsing_history - 浏览记录表
- `id` (uuid, 主键)
- `user_id` (uuid, 用户ID)
- `content_type` (text, 内容类型: article/product/video/download/question)
- `content_id` (uuid, 内容ID)
- `content_title` (text, 内容标题)
- `created_at` (timestamptz, 浏览时间)

### 2.4 member_submissions - 会员提交内容审核表
- `id` (uuid, 主键)
- `user_id` (uuid, 用户ID)
- `content_type` (text, 内容类型: article/question)
- `content_id` (uuid, 内容ID)
- `status` (text, 状态: pending/approved/rejected)
- `reviewer_id` (uuid, 审核人ID, 可为空)
- `review_note` (text, 审核备注, 可为空)
- `submitted_at` (timestamptz, 提交时间)
- `reviewed_at` (timestamptz, 审核时间, 可为空)

## 3. 安全策略
- member_levels: 公开读取, 仅管理员可写入
- member_points_log: 用户可查看自己的记录, 管理员可查看所有
- browsing_history: 用户可查看和管理自己的记录, 管理员可查看所有
- member_submissions: 用户可查看自己的提交, 管理员和编辑可查看和审核所有

## 4. 触发器和函数
- 自动更新会员等级
- 自动统计发布数量
- 积分变化记录
*/

-- ============================================
-- 1. 扩展profiles表
-- ============================================

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS points int DEFAULT 0 NOT NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS level int DEFAULT 1 NOT NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS country text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS address text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS postal_code text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS bio text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS total_articles int DEFAULT 0 NOT NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS total_questions int DEFAULT 0 NOT NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS total_answers int DEFAULT 0 NOT NULL;

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_profiles_points ON profiles(points DESC);
CREATE INDEX IF NOT EXISTS idx_profiles_level ON profiles(level);

-- ============================================
-- 2. 创建会员等级配置表
-- ============================================

CREATE TABLE IF NOT EXISTS member_levels (
  id int PRIMARY KEY,
  name text NOT NULL,
  min_points int NOT NULL,
  max_points int,
  benefits jsonb DEFAULT '{}',
  badge_color text DEFAULT '#gray',
  created_at timestamptz DEFAULT now()
);

-- 插入默认等级配置
INSERT INTO member_levels (id, name, min_points, max_points, benefits, badge_color) VALUES
  (1, '新手会员', 0, 99, '{"description": "欢迎加入", "features": ["基础浏览", "提问功能"]}', '#94a3b8'),
  (2, '初级会员', 100, 499, '{"description": "积极参与", "features": ["发布文章", "优先回答", "专属徽章"]}', '#3b82f6'),
  (3, '中级会员', 500, 1999, '{"description": "活跃用户", "features": ["文章推荐", "专属标识", "优先审核"]}', '#8b5cf6'),
  (4, '高级会员', 2000, 4999, '{"description": "资深用户", "features": ["内容置顶", "专属客服", "高级权限"]}', '#f59e0b'),
  (5, 'VIP会员', 5000, NULL, '{"description": "尊贵身份", "features": ["全站特权", "专属顾问", "优先支持", "定制服务"]}', '#ef4444')
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- 3. 创建积分记录表
-- ============================================

CREATE TABLE IF NOT EXISTS member_points_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  points int NOT NULL,
  reason text NOT NULL,
  reference_type text,
  reference_id uuid,
  created_at timestamptz DEFAULT now()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_points_log_user ON member_points_log(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_points_log_reference ON member_points_log(reference_type, reference_id);

-- ============================================
-- 4. 创建浏览记录表
-- ============================================

CREATE TABLE IF NOT EXISTS browsing_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content_type text NOT NULL,
  content_id uuid NOT NULL,
  content_title text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_browsing_history_user ON browsing_history(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_browsing_history_content ON browsing_history(content_type, content_id);

-- ============================================
-- 5. 创建会员提交内容审核表
-- ============================================

CREATE TABLE IF NOT EXISTS member_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content_type text NOT NULL,
  content_id uuid NOT NULL,
  status text DEFAULT 'pending' NOT NULL,
  reviewer_id uuid REFERENCES profiles(id),
  review_note text,
  submitted_at timestamptz DEFAULT now(),
  reviewed_at timestamptz
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_submissions_user ON member_submissions(user_id, submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_submissions_status ON member_submissions(status, submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_submissions_content ON member_submissions(content_type, content_id);

-- ============================================
-- 6. 创建积分管理函数
-- ============================================

-- 添加积分函数
CREATE OR REPLACE FUNCTION add_member_points(
  p_user_id uuid,
  p_points int,
  p_reason text,
  p_reference_type text DEFAULT NULL,
  p_reference_id uuid DEFAULT NULL
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 更新用户积分
  UPDATE profiles
  SET points = points + p_points,
      updated_at = now()
  WHERE id = p_user_id;
  
  -- 记录积分变化
  INSERT INTO member_points_log (user_id, points, reason, reference_type, reference_id)
  VALUES (p_user_id, p_points, p_reason, p_reference_type, p_reference_id);
  
  -- 更新会员等级
  PERFORM update_member_level(p_user_id);
END;
$$;

-- 更新会员等级函数
CREATE OR REPLACE FUNCTION update_member_level(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_points int;
  v_new_level int;
BEGIN
  -- 获取当前积分
  SELECT points INTO v_points
  FROM profiles
  WHERE id = p_user_id;
  
  -- 根据积分确定等级
  SELECT id INTO v_new_level
  FROM member_levels
  WHERE min_points <= v_points
    AND (max_points IS NULL OR max_points >= v_points)
  ORDER BY min_points DESC
  LIMIT 1;
  
  -- 更新等级
  IF v_new_level IS NOT NULL THEN
    UPDATE profiles
    SET level = v_new_level,
        updated_at = now()
    WHERE id = p_user_id;
  END IF;
END;
$$;

-- ============================================
-- 7. 创建浏览记录函数
-- ============================================

CREATE OR REPLACE FUNCTION add_browsing_history(
  p_user_id uuid,
  p_content_type text,
  p_content_id uuid,
  p_content_title text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 删除该用户对该内容的旧记录（保持唯一性）
  DELETE FROM browsing_history
  WHERE user_id = p_user_id
    AND content_type = p_content_type
    AND content_id = p_content_id;
  
  -- 插入新记录
  INSERT INTO browsing_history (user_id, content_type, content_id, content_title)
  VALUES (p_user_id, p_content_type, p_content_id, p_content_title);
  
  -- 限制每个用户的浏览记录数量（保留最近100条）
  DELETE FROM browsing_history
  WHERE id IN (
    SELECT id FROM browsing_history
    WHERE user_id = p_user_id
    ORDER BY created_at DESC
    OFFSET 100
  );
END;
$$;

-- ============================================
-- 8. 创建触发器 - 文章发布时增加积分和统计
-- ============================================

CREATE OR REPLACE FUNCTION on_article_published()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 如果文章从非published状态变为published状态
  IF NEW.status = 'published' AND (OLD.status IS NULL OR OLD.status != 'published') THEN
    -- 增加积分
    PERFORM add_member_points(
      NEW.author_id,
      10,
      '发布文章',
      'article',
      NEW.id
    );
    
    -- 更新文章统计
    UPDATE profiles
    SET total_articles = total_articles + 1
    WHERE id = NEW.author_id;
  END IF;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_article_published ON articles;
CREATE TRIGGER trigger_article_published
  AFTER INSERT OR UPDATE ON articles
  FOR EACH ROW
  EXECUTE FUNCTION on_article_published();

-- ============================================
-- 9. 创建触发器 - 提问时增加积分和统计
-- ============================================

CREATE OR REPLACE FUNCTION on_question_created()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 增加积分
  PERFORM add_member_points(
    NEW.author_id,
    5,
    '提出问题',
    'question',
    NEW.id
  );
  
  -- 更新提问统计
  UPDATE profiles
  SET total_questions = total_questions + 1
  WHERE id = NEW.author_id;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_question_created ON questions;
CREATE TRIGGER trigger_question_created
  AFTER INSERT ON questions
  FOR EACH ROW
  EXECUTE FUNCTION on_question_created();

-- ============================================
-- 10. 创建触发器 - 回答时增加积分和统计
-- ============================================

CREATE OR REPLACE FUNCTION on_answer_created()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 增加积分
  PERFORM add_member_points(
    NEW.author_id,
    3,
    '回答问题',
    'answer',
    NEW.id
  );
  
  -- 更新回答统计
  UPDATE profiles
  SET total_answers = total_answers + 1
  WHERE id = NEW.author_id;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_answer_created ON answers;
CREATE TRIGGER trigger_answer_created
  AFTER INSERT ON answers
  FOR EACH ROW
  EXECUTE FUNCTION on_answer_created();

-- ============================================
-- 11. 创建触发器 - 回答被采纳时额外增加积分
-- ============================================

CREATE OR REPLACE FUNCTION on_answer_accepted()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 如果回答从未采纳变为采纳
  IF NEW.is_accepted = true AND (OLD.is_accepted IS NULL OR OLD.is_accepted = false) THEN
    -- 额外增加积分
    PERFORM add_member_points(
      NEW.author_id,
      15,
      '回答被采纳',
      'answer',
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_answer_accepted ON answers;
CREATE TRIGGER trigger_answer_accepted
  AFTER UPDATE ON answers
  FOR EACH ROW
  EXECUTE FUNCTION on_answer_accepted();

-- ============================================
-- 12. 创建辅助函数 - 检查是否为编辑
-- ============================================

CREATE OR REPLACE FUNCTION is_editor(uid uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role IN ('editor'::user_role, 'admin'::user_role)
  );
$$;

-- ============================================
-- 13. 安全策略 - member_levels
-- ============================================

ALTER TABLE member_levels ENABLE ROW LEVEL SECURITY;

-- 所有人可以查看等级配置
CREATE POLICY "Anyone can view member levels"
  ON member_levels FOR SELECT
  TO public
  USING (true);

-- 只有管理员可以修改等级配置
CREATE POLICY "Only admins can modify member levels"
  ON member_levels FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()))
  WITH CHECK (is_admin(auth.uid()));

-- ============================================
-- 14. 安全策略 - member_points_log
-- ============================================

ALTER TABLE member_points_log ENABLE ROW LEVEL SECURITY;

-- 用户可以查看自己的积分记录
CREATE POLICY "Users can view own points log"
  ON member_points_log FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR is_admin(auth.uid()));

-- 管理员可以查看所有积分记录
CREATE POLICY "Admins can view all points log"
  ON member_points_log FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

-- ============================================
-- 15. 安全策略 - browsing_history
-- ============================================

ALTER TABLE browsing_history ENABLE ROW LEVEL SECURITY;

-- 用户可以查看和删除自己的浏览记录
CREATE POLICY "Users can manage own browsing history"
  ON browsing_history FOR ALL
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- 管理员可以查看所有浏览记录
CREATE POLICY "Admins can view all browsing history"
  ON browsing_history FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

-- ============================================
-- 16. 安全策略 - member_submissions
-- ============================================

ALTER TABLE member_submissions ENABLE ROW LEVEL SECURITY;

-- 用户可以查看自己的提交记录
CREATE POLICY "Users can view own submissions"
  ON member_submissions FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR is_admin(auth.uid()) OR is_editor(auth.uid()));

-- 用户可以创建提交记录
CREATE POLICY "Users can create submissions"
  ON member_submissions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- 管理员和编辑可以更新提交记录（审核）
CREATE POLICY "Admins and editors can update submissions"
  ON member_submissions FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()) OR is_editor(auth.uid()))
  WITH CHECK (is_admin(auth.uid()) OR is_editor(auth.uid()));

-- ============================================
-- 17. 创建视图 - 会员统计信息
-- ============================================

CREATE OR REPLACE VIEW member_stats AS
SELECT 
  p.id,
  p.username,
  p.email,
  p.avatar_url,
  p.points,
  p.level,
  ml.name as level_name,
  ml.badge_color,
  p.total_articles,
  p.total_questions,
  p.total_answers,
  p.country,
  p.city,
  p.created_at,
  (SELECT COUNT(*) FROM browsing_history WHERE user_id = p.id) as total_views,
  (SELECT COUNT(*) FROM member_submissions WHERE user_id = p.id AND status = 'pending') as pending_submissions
FROM profiles p
LEFT JOIN member_levels ml ON p.level = ml.id;

-- ============================================
-- 18. 创建函数 - 获取会员排行榜
-- ============================================

CREATE OR REPLACE FUNCTION get_member_leaderboard(
  p_limit int DEFAULT 10,
  p_order_by text DEFAULT 'points'
)
RETURNS TABLE (
  id uuid,
  username text,
  avatar_url text,
  points int,
  level int,
  level_name text,
  badge_color text,
  total_articles int,
  total_questions int,
  total_answers int
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.username,
    p.avatar_url,
    p.points,
    p.level,
    ml.name as level_name,
    ml.badge_color,
    p.total_articles,
    p.total_questions,
    p.total_answers
  FROM profiles p
  LEFT JOIN member_levels ml ON p.level = ml.id
  WHERE p.role = 'member'::user_role
  ORDER BY 
    CASE 
      WHEN p_order_by = 'points' THEN p.points
      WHEN p_order_by = 'articles' THEN p.total_articles
      WHEN p_order_by = 'questions' THEN p.total_questions
      WHEN p_order_by = 'answers' THEN p.total_answers
      ELSE p.points
    END DESC
  LIMIT p_limit;
END;
$$;

COMMENT ON TABLE member_levels IS '会员等级配置表';
COMMENT ON TABLE member_points_log IS '会员积分记录表';
COMMENT ON TABLE browsing_history IS '会员浏览记录表';
COMMENT ON TABLE member_submissions IS '会员提交内容审核表';
/*
# 会员系统升级 - Part 2: 触发器和安全策略

## 1. 创建触发器
## 2. 创建安全策略
## 3. 创建视图和辅助函数
*/

-- ============================================
-- 1. 创建触发器 - 文章发布时增加积分和统计
-- ============================================

CREATE OR REPLACE FUNCTION on_article_published()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 如果文章从非published状态变为published状态
  IF NEW.status = 'published' AND (OLD.status IS NULL OR OLD.status != 'published') THEN
    -- 增加积分
    PERFORM add_member_points(
      NEW.author_id,
      10,
      '发布文章',
      'article',
      NEW.id
    );
    
    -- 更新文章统计
    UPDATE profiles
    SET total_articles = total_articles + 1
    WHERE id = NEW.author_id;
  END IF;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_article_published ON articles;
CREATE TRIGGER trigger_article_published
  AFTER INSERT OR UPDATE ON articles
  FOR EACH ROW
  EXECUTE FUNCTION on_article_published();

-- ============================================
-- 2. 创建触发器 - 提问时增加积分和统计
-- ============================================

CREATE OR REPLACE FUNCTION on_question_created()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 增加积分
  PERFORM add_member_points(
    NEW.author_id,
    5,
    '提出问题',
    'question',
    NEW.id
  );
  
  -- 更新提问统计
  UPDATE profiles
  SET total_questions = total_questions + 1
  WHERE id = NEW.author_id;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_question_created ON questions;
CREATE TRIGGER trigger_question_created
  AFTER INSERT ON questions
  FOR EACH ROW
  EXECUTE FUNCTION on_question_created();

-- ============================================
-- 3. 创建触发器 - 回答时增加积分和统计
-- ============================================

CREATE OR REPLACE FUNCTION on_answer_created()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 增加积分
  PERFORM add_member_points(
    NEW.author_id,
    3,
    '回答问题',
    'answer',
    NEW.id
  );
  
  -- 更新回答统计
  UPDATE profiles
  SET total_answers = total_answers + 1
  WHERE id = NEW.author_id;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_answer_created ON answers;
CREATE TRIGGER trigger_answer_created
  AFTER INSERT ON answers
  FOR EACH ROW
  EXECUTE FUNCTION on_answer_created();

-- ============================================
-- 4. 创建触发器 - 回答被采纳时额外增加积分
-- ============================================

CREATE OR REPLACE FUNCTION on_answer_accepted()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 如果回答从未采纳变为采纳
  IF NEW.is_accepted = true AND (OLD.is_accepted IS NULL OR OLD.is_accepted = false) THEN
    -- 额外增加积分
    PERFORM add_member_points(
      NEW.author_id,
      15,
      '回答被采纳',
      'answer',
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_answer_accepted ON answers;
CREATE TRIGGER trigger_answer_accepted
  AFTER UPDATE ON answers
  FOR EACH ROW
  EXECUTE FUNCTION on_answer_accepted();

-- ============================================
-- 5. 安全策略 - member_levels
-- ============================================

ALTER TABLE member_levels ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view member levels" ON member_levels;
CREATE POLICY "Anyone can view member levels"
  ON member_levels FOR SELECT
  TO public
  USING (true);

DROP POLICY IF EXISTS "Only admins can modify member levels" ON member_levels;
CREATE POLICY "Only admins can modify member levels"
  ON member_levels FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()))
  WITH CHECK (is_admin(auth.uid()));

-- ============================================
-- 6. 安全策略 - member_points_log
-- ============================================

ALTER TABLE member_points_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own points log" ON member_points_log;
CREATE POLICY "Users can view own points log"
  ON member_points_log FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR is_admin(auth.uid()));

-- ============================================
-- 7. 安全策略 - browsing_history
-- ============================================

ALTER TABLE browsing_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage own browsing history" ON browsing_history;
CREATE POLICY "Users can manage own browsing history"
  ON browsing_history FOR ALL
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "Admins can view all browsing history" ON browsing_history;
CREATE POLICY "Admins can view all browsing history"
  ON browsing_history FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

-- ============================================
-- 8. 安全策略 - member_submissions
-- ============================================

ALTER TABLE member_submissions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own submissions" ON member_submissions;
CREATE POLICY "Users can view own submissions"
  ON member_submissions FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR is_admin(auth.uid()) OR is_editor(auth.uid()));

DROP POLICY IF EXISTS "Users can create submissions" ON member_submissions;
CREATE POLICY "Users can create submissions"
  ON member_submissions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "Admins and editors can update submissions" ON member_submissions;
CREATE POLICY "Admins and editors can update submissions"
  ON member_submissions FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()) OR is_editor(auth.uid()))
  WITH CHECK (is_admin(auth.uid()) OR is_editor(auth.uid()));

-- ============================================
-- 9. 创建视图 - 会员统计信息
-- ============================================

CREATE OR REPLACE VIEW member_stats AS
SELECT 
  p.id,
  p.username,
  p.email,
  p.avatar_url,
  p.points,
  p.level,
  ml.name as level_name,
  ml.badge_color,
  p.total_articles,
  p.total_questions,
  p.total_answers,
  p.country,
  p.city,
  p.created_at,
  (SELECT COUNT(*) FROM browsing_history WHERE user_id = p.id) as total_views,
  (SELECT COUNT(*) FROM member_submissions WHERE user_id = p.id AND status = 'pending') as pending_submissions
FROM profiles p
LEFT JOIN member_levels ml ON p.level = ml.id;

-- ============================================
-- 10. 创建函数 - 获取会员排行榜
-- ============================================

CREATE OR REPLACE FUNCTION get_member_leaderboard(
  p_limit int DEFAULT 10,
  p_order_by text DEFAULT 'points'
)
RETURNS TABLE (
  id uuid,
  username text,
  avatar_url text,
  points int,
  level int,
  level_name text,
  badge_color text,
  total_articles int,
  total_questions int,
  total_answers int
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.username,
    p.avatar_url,
    p.points,
    p.level,
    ml.name as level_name,
    ml.badge_color,
    p.total_articles,
    p.total_questions,
    p.total_answers
  FROM profiles p
  LEFT JOIN member_levels ml ON p.level = ml.id
  WHERE p.role = 'member'::user_role
  ORDER BY 
    CASE 
      WHEN p_order_by = 'points' THEN p.points
      WHEN p_order_by = 'articles' THEN p.total_articles
      WHEN p_order_by = 'questions' THEN p.total_questions
      WHEN p_order_by = 'answers' THEN p.total_answers
      ELSE p.points
    END DESC
  LIMIT p_limit;
END;
$$;
/*
# 优化会员系统 - 增强管理员权限和英文等级

## 1. 更新会员等级为英文
## 2. 添加会员状态管理
## 3. 添加更多管理员权限
## 4. 创建会员等级配置管理函数
*/

-- ============================================
-- 1. 添加会员状态字段
-- ============================================

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS status text DEFAULT 'active' NOT NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_login_at timestamptz;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS disabled_at timestamptz;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS disabled_reason text;

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_profiles_status ON profiles(status);

-- ============================================
-- 2. 更新会员等级配置为英文
-- ============================================

-- 清空旧数据
TRUNCATE member_levels CASCADE;

-- 插入英文等级配置
INSERT INTO member_levels (id, name, min_points, max_points, benefits, badge_color) VALUES
  (1, 'Bronze', 0, 99, '{"description": "新手会员，欢迎加入", "features": ["基础浏览权限", "提问功能", "评论功能"]}', '#cd7f32'),
  (2, 'Silver', 100, 499, '{"description": "银牌会员，积极参与", "features": ["发布文章", "优先回答", "专属徽章", "每日积分加成"]}', '#c0c0c0'),
  (3, 'Gold', 500, 1999, '{"description": "金牌会员，活跃用户", "features": ["文章推荐位", "专属标识", "优先审核", "高级编辑器"]}', '#ffd700'),
  (4, 'Platinum', 2000, 4999, '{"description": "白金会员，资深用户", "features": ["内容置顶", "专属客服", "高级权限", "自定义主页"]}', '#e5e4e2'),
  (5, 'Diamond', 5000, NULL, '{"description": "钻石会员，尊贵身份", "features": ["全站特权", "专属顾问", "优先支持", "定制服务", "无限存储"]}', '#b9f2ff')
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  min_points = EXCLUDED.min_points,
  max_points = EXCLUDED.max_points,
  benefits = EXCLUDED.benefits,
  badge_color = EXCLUDED.badge_color;

-- ============================================
-- 3. 创建积分规则配置表
-- ============================================

CREATE TABLE IF NOT EXISTS points_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action text NOT NULL UNIQUE,
  points int NOT NULL,
  description text,
  enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 插入默认积分规则
INSERT INTO points_rules (action, points, description) VALUES
  ('daily_login', 5, '每日登录奖励'),
  ('publish_article', 10, '发布文章'),
  ('publish_question', 5, '发布提问'),
  ('publish_answer', 8, '发布回答'),
  ('answer_accepted', 20, '回答被采纳'),
  ('article_liked', 2, '文章被点赞'),
  ('comment_received', 1, '收到评论')
ON CONFLICT (action) DO NOTHING;

-- ============================================
-- 4. 创建管理员操作日志表
-- ============================================

CREATE TABLE IF NOT EXISTS admin_operation_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL REFERENCES profiles(id),
  operation_type text NOT NULL,
  target_type text NOT NULL,
  target_id uuid NOT NULL,
  details jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_admin_logs_admin ON admin_operation_logs(admin_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_logs_target ON admin_operation_logs(target_type, target_id);

-- ============================================
-- 5. 创建会员等级管理函数
-- ============================================

-- 更新会员等级配置
CREATE OR REPLACE FUNCTION update_member_level_config(
  p_level_id int,
  p_name text,
  p_min_points int,
  p_max_points int,
  p_benefits jsonb,
  p_badge_color text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE member_levels
  SET 
    name = p_name,
    min_points = p_min_points,
    max_points = p_max_points,
    benefits = p_benefits,
    badge_color = p_badge_color
  WHERE id = p_level_id;
END;
$$;

-- 更新积分规则
CREATE OR REPLACE FUNCTION update_points_rule(
  p_action text,
  p_points int,
  p_description text,
  p_enabled boolean
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE points_rules
  SET 
    points = p_points,
    description = p_description,
    enabled = p_enabled,
    updated_at = now()
  WHERE action = p_action;
END;
$$;

-- 禁用/启用会员账号
CREATE OR REPLACE FUNCTION toggle_member_status(
  p_user_id uuid,
  p_status text,
  p_reason text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF p_status = 'disabled' THEN
    UPDATE profiles
    SET 
      status = p_status,
      disabled_at = now(),
      disabled_reason = p_reason
    WHERE id = p_user_id;
  ELSE
    UPDATE profiles
    SET 
      status = p_status,
      disabled_at = NULL,
      disabled_reason = NULL
    WHERE id = p_user_id;
  END IF;
END;
$$;

-- 批量更新会员等级
CREATE OR REPLACE FUNCTION batch_update_member_level(
  p_user_ids uuid[],
  p_level int
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE profiles
  SET level = p_level
  WHERE id = ANY(p_user_ids);
END;
$$;

-- 批量增加积分
CREATE OR REPLACE FUNCTION batch_add_points(
  p_user_ids uuid[],
  p_points int,
  p_reason text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id uuid;
BEGIN
  FOREACH v_user_id IN ARRAY p_user_ids
  LOOP
    PERFORM add_member_points(v_user_id, p_points, p_reason, NULL, NULL);
  END LOOP;
END;
$$;

-- 记录管理员操作
CREATE OR REPLACE FUNCTION log_admin_operation(
  p_admin_id uuid,
  p_operation_type text,
  p_target_type text,
  p_target_id uuid,
  p_details jsonb DEFAULT '{}'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO admin_operation_logs (admin_id, operation_type, target_type, target_id, details)
  VALUES (p_admin_id, p_operation_type, p_target_type, p_target_id, p_details);
END;
$$;

-- ============================================
-- 6. 更新会员统计视图
-- ============================================

DROP VIEW IF EXISTS member_stats;

CREATE VIEW member_stats AS
SELECT 
  p.id,
  p.username,
  p.nickname,
  p.email,
  p.phone,
  p.avatar_url,
  p.role,
  p.status,
  p.points,
  p.level,
  ml.name as level_name,
  ml.badge_color,
  p.total_articles,
  p.total_questions,
  p.total_answers,
  p.country,
  p.city,
  p.created_at,
  p.last_login_at,
  COALESCE((SELECT COUNT(*) FROM browsing_history WHERE user_id = p.id), 0) as total_views,
  COALESCE((SELECT COUNT(*) FROM member_submissions WHERE user_id = p.id AND status = 'pending'), 0) as pending_submissions
FROM profiles p
LEFT JOIN member_levels ml ON p.level = ml.id;

-- ============================================
-- 7. 更新安全策略
-- ============================================

-- 允许管理员查看所有会员状态
DROP POLICY IF EXISTS "Admins can view all member stats" ON profiles;
CREATE POLICY "Admins can view all member stats" ON profiles
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- 允许管理员更新会员状态
DROP POLICY IF EXISTS "Admins can update member status" ON profiles;
CREATE POLICY "Admins can update member status" ON profiles
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- 积分规则表的安全策略
ALTER TABLE points_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view points rules" ON points_rules
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Admins can manage points rules" ON points_rules
  FOR ALL TO authenticated
  USING (is_admin(auth.uid()));

-- 管理员操作日志的安全策略
ALTER TABLE admin_operation_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view operation logs" ON admin_operation_logs
  FOR SELECT TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "System can insert operation logs" ON admin_operation_logs
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- ============================================
-- 8. 创建会员等级自动更新触发器
-- ============================================

CREATE OR REPLACE FUNCTION auto_update_member_level()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_new_level int;
BEGIN
  -- 根据积分自动计算等级
  SELECT id INTO v_new_level
  FROM member_levels
  WHERE NEW.points >= min_points
    AND (max_points IS NULL OR NEW.points <= max_points)
  ORDER BY min_points DESC
  LIMIT 1;

  IF v_new_level IS NOT NULL AND v_new_level != NEW.level THEN
    NEW.level := v_new_level;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_auto_update_member_level ON profiles;
CREATE TRIGGER trigger_auto_update_member_level
  BEFORE UPDATE OF points ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION auto_update_member_level();
/*
# 修复会员系统 - 确保所有字段正确

## 1. 确保profiles表有所有必需字段
## 2. 为现有数据添加默认值
## 3. 修复视图和函数
*/

-- ============================================
-- 1. 确保profiles表有所有必需字段
-- ============================================

-- 添加status字段（如果不存在）
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'profiles' AND column_name = 'status') THEN
    ALTER TABLE profiles ADD COLUMN status text DEFAULT 'active' NOT NULL;
  END IF;
END $$;

-- 添加last_login_at字段（如果不存在）
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'profiles' AND column_name = 'last_login_at') THEN
    ALTER TABLE profiles ADD COLUMN last_login_at timestamptz;
  END IF;
END $$;

-- 添加disabled_at字段（如果不存在）
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'profiles' AND column_name = 'disabled_at') THEN
    ALTER TABLE profiles ADD COLUMN disabled_at timestamptz;
  END IF;
END $$;

-- 添加disabled_reason字段（如果不存在）
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'profiles' AND column_name = 'disabled_reason') THEN
    ALTER TABLE profiles ADD COLUMN disabled_reason text;
  END IF;
END $$;

-- ============================================
-- 2. 为现有数据添加默认值
-- ============================================

-- 确保所有现有用户都有status字段
UPDATE profiles SET status = 'active' WHERE status IS NULL;

-- 确保status字段不为空
ALTER TABLE profiles ALTER COLUMN status SET DEFAULT 'active';
ALTER TABLE profiles ALTER COLUMN status SET NOT NULL;

-- ============================================
-- 3. 重新创建member_stats视图（确保包含所有字段）
-- ============================================

DROP VIEW IF EXISTS member_stats CASCADE;

CREATE OR REPLACE VIEW member_stats AS
SELECT 
  p.id,
  p.username,
  p.nickname,
  p.email,
  p.phone,
  p.avatar_url,
  p.role,
  COALESCE(p.status, 'active') as status,
  COALESCE(p.points, 0) as points,
  COALESCE(p.level, 1) as level,
  COALESCE(ml.name, 'Bronze') as level_name,
  COALESCE(ml.badge_color, '#cd7f32') as badge_color,
  COALESCE(p.total_articles, 0) as total_articles,
  COALESCE(p.total_questions, 0) as total_questions,
  COALESCE(p.total_answers, 0) as total_answers,
  p.country,
  p.city,
  p.created_at,
  p.last_login_at,
  COALESCE((SELECT COUNT(*) FROM browsing_history WHERE user_id = p.id), 0) as total_views,
  COALESCE((SELECT COUNT(*) FROM member_submissions WHERE user_id = p.id AND status = 'pending'), 0) as pending_submissions
FROM profiles p
LEFT JOIN member_levels ml ON p.level = ml.id;

-- ============================================
-- 4. 确保member_levels表有数据
-- ============================================

-- 如果member_levels表为空，插入默认数据
INSERT INTO member_levels (id, name, min_points, max_points, benefits, badge_color)
SELECT 1, 'Bronze', 0, 99, '{"description": "新手会员，欢迎加入", "features": ["基础浏览权限", "提问功能", "评论功能"]}'::jsonb, '#cd7f32'
WHERE NOT EXISTS (SELECT 1 FROM member_levels WHERE id = 1);

INSERT INTO member_levels (id, name, min_points, max_points, benefits, badge_color)
SELECT 2, 'Silver', 100, 499, '{"description": "银牌会员，积极参与", "features": ["发布文章", "优先回答", "专属徽章", "每日积分加成"]}'::jsonb, '#c0c0c0'
WHERE NOT EXISTS (SELECT 1 FROM member_levels WHERE id = 2);

INSERT INTO member_levels (id, name, min_points, max_points, benefits, badge_color)
SELECT 3, 'Gold', 500, 1999, '{"description": "金牌会员，活跃用户", "features": ["文章推荐位", "专属标识", "优先审核", "高级编辑器"]}'::jsonb, '#ffd700'
WHERE NOT EXISTS (SELECT 1 FROM member_levels WHERE id = 3);

INSERT INTO member_levels (id, name, min_points, max_points, benefits, badge_color)
SELECT 4, 'Platinum', 2000, 4999, '{"description": "白金会员，资深用户", "features": ["内容置顶", "专属客服", "高级权限", "自定义主页"]}'::jsonb, '#e5e4e2'
WHERE NOT EXISTS (SELECT 1 FROM member_levels WHERE id = 4);

INSERT INTO member_levels (id, name, min_points, max_points, benefits, badge_color)
SELECT 5, 'Diamond', 5000, NULL, '{"description": "钻石会员，尊贵身份", "features": ["全站特权", "专属顾问", "优先支持", "定制服务", "无限存储"]}'::jsonb, '#b9f2ff'
WHERE NOT EXISTS (SELECT 1 FROM member_levels WHERE id = 5);

-- ============================================
-- 5. 确保所有用户都有有效的level
-- ============================================

-- 将无效的level设置为1（Bronze）
UPDATE profiles SET level = 1 WHERE level IS NULL OR level < 1 OR level > 5;

-- ============================================
-- 6. 创建或替换必需的函数
-- ============================================

-- 切换会员状态函数
CREATE OR REPLACE FUNCTION toggle_member_status(
  p_user_id uuid,
  p_status text,
  p_reason text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF p_status = 'disabled' THEN
    UPDATE profiles
    SET 
      status = p_status,
      disabled_at = now(),
      disabled_reason = p_reason
    WHERE id = p_user_id;
  ELSE
    UPDATE profiles
    SET 
      status = p_status,
      disabled_at = NULL,
      disabled_reason = NULL
    WHERE id = p_user_id;
  END IF;
END;
$$;

-- 批量更新会员等级函数
CREATE OR REPLACE FUNCTION batch_update_member_level(
  p_user_ids uuid[],
  p_level int
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE profiles
  SET level = p_level
  WHERE id = ANY(p_user_ids);
END;
$$;

-- 批量增加积分函数
CREATE OR REPLACE FUNCTION batch_add_points(
  p_user_ids uuid[],
  p_points int,
  p_reason text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id uuid;
BEGIN
  FOREACH v_user_id IN ARRAY p_user_ids
  LOOP
    -- 检查add_member_points函数是否存在
    IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'add_member_points') THEN
      PERFORM add_member_points(v_user_id, p_points, p_reason, NULL, NULL);
    ELSE
      -- 如果函数不存在，直接更新积分
      UPDATE profiles SET points = points + p_points WHERE id = v_user_id;
    END IF;
  END LOOP;
END;
$$;

-- ============================================
-- 7. 创建积分规则表（如果不存在）
-- ============================================

CREATE TABLE IF NOT EXISTS points_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action text NOT NULL UNIQUE,
  points int NOT NULL,
  description text,
  enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 插入默认积分规则（如果不存在）
INSERT INTO points_rules (action, points, description) 
SELECT 'daily_login', 5, '每日登录奖励'
WHERE NOT EXISTS (SELECT 1 FROM points_rules WHERE action = 'daily_login');

INSERT INTO points_rules (action, points, description) 
SELECT 'publish_article', 10, '发布文章'
WHERE NOT EXISTS (SELECT 1 FROM points_rules WHERE action = 'publish_article');

INSERT INTO points_rules (action, points, description) 
SELECT 'publish_question', 5, '发布提问'
WHERE NOT EXISTS (SELECT 1 FROM points_rules WHERE action = 'publish_question');

INSERT INTO points_rules (action, points, description) 
SELECT 'publish_answer', 8, '发布回答'
WHERE NOT EXISTS (SELECT 1 FROM points_rules WHERE action = 'publish_answer');

INSERT INTO points_rules (action, points, description) 
SELECT 'answer_accepted', 20, '回答被采纳'
WHERE NOT EXISTS (SELECT 1 FROM points_rules WHERE action = 'answer_accepted');

-- 启用RLS
ALTER TABLE points_rules ENABLE ROW LEVEL SECURITY;

-- 允许所有人查看积分规则
DROP POLICY IF EXISTS "Anyone can view points rules" ON points_rules;
CREATE POLICY "Anyone can view points rules" ON points_rules
  FOR SELECT TO public USING (true);

-- 只允许管理员修改积分规则
DROP POLICY IF EXISTS "Admins can update points rules" ON points_rules;
CREATE POLICY "Admins can update points rules" ON points_rules
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- ============================================
-- 8. 创建管理员操作日志表（如果不存在）
-- ============================================

CREATE TABLE IF NOT EXISTS admin_operation_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL REFERENCES profiles(id),
  operation_type text NOT NULL,
  target_type text NOT NULL,
  target_id uuid NOT NULL,
  details jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_admin_logs_admin ON admin_operation_logs(admin_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_logs_target ON admin_operation_logs(target_type, target_id);

-- 启用RLS
ALTER TABLE admin_operation_logs ENABLE ROW LEVEL SECURITY;

-- 只允许管理员查看操作日志
DROP POLICY IF EXISTS "Admins can view operation logs" ON admin_operation_logs;
CREATE POLICY "Admins can view operation logs" ON admin_operation_logs
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- ============================================
-- 9. 添加索引以提高性能
-- ============================================

CREATE INDEX IF NOT EXISTS idx_profiles_status ON profiles(status);
CREATE INDEX IF NOT EXISTS idx_profiles_level ON profiles(level);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_points ON profiles(points DESC);
/*
# Translate Member System Data to English

## 1. Update member level benefits to English
## 2. Update points rules descriptions to English

This migration ensures all user-facing text in the member system is in English.
*/

-- ============================================
-- 1. Update Member Level Benefits to English
-- ============================================

UPDATE member_levels SET benefits = '{"description": "New member, welcome aboard", "features": ["Basic browsing access", "Ask questions", "Comment on posts"]}'::jsonb
WHERE id = 1;

UPDATE member_levels SET benefits = '{"description": "Silver member, active participant", "features": ["Publish articles", "Priority answers", "Exclusive badge", "Daily points bonus"]}'::jsonb
WHERE id = 2;

UPDATE member_levels SET benefits = '{"description": "Gold member, active user", "features": ["Featured articles", "Exclusive badge", "Priority review", "Advanced editor"]}'::jsonb
WHERE id = 3;

UPDATE member_levels SET benefits = '{"description": "Platinum member, senior user", "features": ["Pin content", "Dedicated support", "Advanced permissions", "Custom homepage"]}'::jsonb
WHERE id = 4;

UPDATE member_levels SET benefits = '{"description": "Diamond member, prestigious status", "features": ["Full site privileges", "Personal advisor", "Priority support", "Custom services", "Unlimited storage"]}'::jsonb
WHERE id = 5;

-- ============================================
-- 2. Update Points Rules Descriptions to English
-- ============================================

UPDATE points_rules SET description = 'Daily login reward' WHERE action = 'daily_login';
UPDATE points_rules SET description = 'Publish an article' WHERE action = 'publish_article';
UPDATE points_rules SET description = 'Ask a question' WHERE action = 'publish_question';
UPDATE points_rules SET description = 'Post an answer' WHERE action = 'publish_answer';
UPDATE points_rules SET description = 'Answer accepted' WHERE action = 'answer_accepted';
UPDATE points_rules SET description = 'Article liked' WHERE action = 'article_liked';
UPDATE points_rules SET description = 'Comment received' WHERE action = 'comment_received';
/*
# 修复用户注册触发器 - 确保新用户有所有必需字段

## 更新内容
1. 更新handle_new_user函数，确保新用户有status、level等字段
2. 设置合理的默认值
*/

-- 更新处理新用户的函数
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  extracted_username text;
BEGIN
  -- 从邮箱中提取用户名（格式：username@ifixescn.com）
  extracted_username := split_part(NEW.email, '@', 1);
  
  -- 在profiles表中插入新记录，包含所有必需字段
  INSERT INTO public.profiles (
    id, 
    username, 
    email, 
    role, 
    status, 
    level, 
    points,
    total_articles,
    total_questions,
    total_answers
  )
  VALUES (
    NEW.id,
    extracted_username,
    NEW.email,
    'member'::user_role,
    'active',  -- 默认状态为活跃
    1,         -- 默认等级为1（Bronze）
    0,         -- 初始积分为0
    0,         -- 初始文章数为0
    0,         -- 初始提问数为0
    0          -- 初始回答数为0
  );
  
  RETURN NEW;
END;
$$;

-- 添加注释
COMMENT ON FUNCTION public.handle_new_user() IS '当新用户注册时自动创建profile记录，包含所有必需字段和默认值';
/*
# 修复现有用户数据 - 确保所有用户都有完整的字段

## 更新内容
1. 为所有现有用户添加缺失的字段值
2. 确保数据一致性
*/

-- ============================================
-- 1. 修复status字段
-- ============================================

-- 为所有没有status的用户设置默认值
UPDATE profiles 
SET status = 'active' 
WHERE status IS NULL OR status = '';

-- ============================================
-- 2. 修复level字段
-- ============================================

-- 为所有没有level或level无效的用户设置默认值
UPDATE profiles 
SET level = 1 
WHERE level IS NULL OR level < 1 OR level > 5;

-- ============================================
-- 3. 修复points字段
-- ============================================

-- 为所有没有points的用户设置默认值
UPDATE profiles 
SET points = 0 
WHERE points IS NULL;

-- ============================================
-- 4. 修复计数字段
-- ============================================

-- 为所有没有total_articles的用户设置默认值
UPDATE profiles 
SET total_articles = 0 
WHERE total_articles IS NULL;

-- 为所有没有total_questions的用户设置默认值
UPDATE profiles 
SET total_questions = 0 
WHERE total_questions IS NULL;

-- 为所有没有total_answers的用户设置默认值
UPDATE profiles 
SET total_answers = 0 
WHERE total_answers IS NULL;

-- ============================================
-- 5. 修复role字段
-- ============================================

-- 为所有没有role的用户设置默认值
UPDATE profiles 
SET role = 'member'::user_role 
WHERE role IS NULL;

-- ============================================
-- 6. 确保字段约束
-- ============================================

-- 确保status字段不为空
ALTER TABLE profiles ALTER COLUMN status SET DEFAULT 'active';
ALTER TABLE profiles ALTER COLUMN status SET NOT NULL;

-- 确保level字段不为空
ALTER TABLE profiles ALTER COLUMN level SET DEFAULT 1;
ALTER TABLE profiles ALTER COLUMN level SET NOT NULL;

-- 确保points字段不为空
ALTER TABLE profiles ALTER COLUMN points SET DEFAULT 0;
ALTER TABLE profiles ALTER COLUMN points SET NOT NULL;

-- 确保计数字段不为空
ALTER TABLE profiles ALTER COLUMN total_articles SET DEFAULT 0;
ALTER TABLE profiles ALTER COLUMN total_articles SET NOT NULL;

ALTER TABLE profiles ALTER COLUMN total_questions SET DEFAULT 0;
ALTER TABLE profiles ALTER COLUMN total_questions SET NOT NULL;

ALTER TABLE profiles ALTER COLUMN total_answers SET DEFAULT 0;
ALTER TABLE profiles ALTER COLUMN total_answers SET NOT NULL;

-- ============================================
-- 7. 添加检查约束
-- ============================================

-- 确保status只能是有效值
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'profiles_status_check'
  ) THEN
    ALTER TABLE profiles 
    ADD CONSTRAINT profiles_status_check 
    CHECK (status IN ('active', 'disabled', 'suspended'));
  END IF;
END $$;

-- 确保level在有效范围内
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'profiles_level_check'
  ) THEN
    ALTER TABLE profiles 
    ADD CONSTRAINT profiles_level_check 
    CHECK (level >= 1 AND level <= 5);
  END IF;
END $$;

-- 确保points不为负数
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'profiles_points_check'
  ) THEN
    ALTER TABLE profiles 
    ADD CONSTRAINT profiles_points_check 
    CHECK (points >= 0);
  END IF;
END $$;
/*
# 修复会员访问权限 - 确保会员可以登录和查看所有公开内容

## 修复内容
1. 确保所有会员账号状态正常
2. 确保RLS策略允许所有人查看已发布内容
3. 添加会员登录日志更新
*/

-- ============================================
-- 1. 确保所有会员账号状态正常
-- ============================================

-- 将所有会员状态设置为active
UPDATE profiles 
SET status = 'active'
WHERE role = 'member' AND status != 'active';

-- 确保所有会员都有有效的level
UPDATE profiles 
SET level = 1
WHERE role = 'member' AND (level < 1 OR level > 5);

-- 确保所有会员都有points字段（已经有默认值，这里不需要更新）
-- UPDATE profiles 
-- SET points = 0
-- WHERE role = 'member' AND points IS NULL;

-- ============================================
-- 2. 重新创建RLS策略 - 确保所有人都能查看已发布内容
-- ============================================

-- Articles表策略
DROP POLICY IF EXISTS "所有人可查看已发布文章" ON articles;
CREATE POLICY "所有人可查看已发布文章" ON articles
  FOR SELECT 
  TO public
  USING (status = 'published'::content_status);

-- Products表策略
DROP POLICY IF EXISTS "所有人可查看已发布产品" ON products;
CREATE POLICY "所有人可查看已发布产品" ON products
  FOR SELECT 
  TO public
  USING (status = 'published'::content_status);

-- Downloads表策略
DROP POLICY IF EXISTS "公开可读已发布的下载" ON downloads;
CREATE POLICY "公开可读已发布的下载" ON downloads
  FOR SELECT 
  TO public
  USING (is_published = true);

-- Videos表策略
DROP POLICY IF EXISTS "公开可读已发布的视频" ON videos;
CREATE POLICY "公开可读已发布的视频" ON videos
  FOR SELECT 
  TO public
  USING (is_published = true);

-- Questions表策略
DROP POLICY IF EXISTS "所有人可查看已审核问题" ON questions;
CREATE POLICY "所有人可查看已审核问题" ON questions
  FOR SELECT 
  TO public
  USING (status = 'approved'::question_status);

-- Answers表策略（answers表没有status字段，所有回答都可见）
DROP POLICY IF EXISTS "所有人可查看回答" ON answers;
CREATE POLICY "所有人可查看回答" ON answers
  FOR SELECT 
  TO public
  USING (true);

-- Categories表策略（确保所有人都能查看分类）
DROP POLICY IF EXISTS "所有人可查看分类" ON categories;
CREATE POLICY "所有人可查看分类" ON categories
  FOR SELECT 
  TO public
  USING (true);

-- ============================================
-- 3. 添加会员登录时更新last_login_at的触发器
-- ============================================

-- 创建更新last_login_at的函数
CREATE OR REPLACE FUNCTION update_last_login()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE profiles
  SET last_login_at = now()
  WHERE id = NEW.id;
  RETURN NEW;
END;
$$;

-- 创建触发器（如果不存在）
DROP TRIGGER IF EXISTS on_auth_user_login ON auth.users;
CREATE TRIGGER on_auth_user_login
  AFTER UPDATE OF last_sign_in_at ON auth.users
  FOR EACH ROW
  WHEN (OLD.last_sign_in_at IS DISTINCT FROM NEW.last_sign_in_at)
  EXECUTE FUNCTION update_last_login();

-- ============================================
-- 4. 确保profiles表的RLS策略允许用户查看自己的信息
-- ============================================

-- 允许已认证用户查看自己的profile
DROP POLICY IF EXISTS "用户可查看自己的信息" ON profiles;
CREATE POLICY "用户可查看自己的信息" ON profiles
  FOR SELECT 
  TO authenticated
  USING (auth.uid() = id);

-- 允许用户更新自己的信息（但不能改role和status）
DROP POLICY IF EXISTS "用户可更新自己的信息但不能改角色" ON profiles;
CREATE POLICY "用户可更新自己的信息但不能改角色" ON profiles
  FOR UPDATE 
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- ============================================
-- 5. 确保会员可以创建内容
-- ============================================

-- 会员可以创建文章（草稿状态）
DROP POLICY IF EXISTS "会员可创建文章" ON articles;
CREATE POLICY "会员可创建文章" ON articles
  FOR INSERT 
  TO authenticated
  WITH CHECK (
    auth.uid() = author_id 
    AND status = 'draft'::content_status
  );

-- 会员可以查看自己的文章（包括草稿）
DROP POLICY IF EXISTS "作者可查看自己的文章" ON articles;
CREATE POLICY "作者可查看自己的文章" ON articles
  FOR SELECT 
  TO authenticated
  USING (auth.uid() = author_id);

-- 会员可以更新自己的文章
DROP POLICY IF EXISTS "作者可更新自己的文章" ON articles;
CREATE POLICY "作者可更新自己的文章" ON articles
  FOR UPDATE 
  TO authenticated
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

-- 会员可以删除自己的文章
DROP POLICY IF EXISTS "作者可删除自己的文章" ON articles;
CREATE POLICY "作者可删除自己的文章" ON articles
  FOR DELETE 
  TO authenticated
  USING (auth.uid() = author_id);

-- 会员可以创建问题
DROP POLICY IF EXISTS "会员可创建问题" ON questions;
CREATE POLICY "会员可创建问题" ON questions
  FOR INSERT 
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

-- 会员可以查看自己的问题
DROP POLICY IF EXISTS "提问者可查看自己的问题" ON questions;
CREATE POLICY "提问者可查看自己的问题" ON questions
  FOR SELECT 
  TO authenticated
  USING (auth.uid() = author_id);

-- 会员可以更新自己的问题
DROP POLICY IF EXISTS "提问者可更新自己的问题" ON questions;
CREATE POLICY "提问者可更新自己的问题" ON questions
  FOR UPDATE 
  TO authenticated
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

-- 会员可以创建回答
DROP POLICY IF EXISTS "会员可创建回答" ON answers;
CREATE POLICY "会员可创建回答" ON answers
  FOR INSERT 
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

-- 会员可以查看自己的回答
DROP POLICY IF EXISTS "回答者可查看自己的回答" ON answers;
CREATE POLICY "回答者可查看自己的回答" ON answers
  FOR SELECT 
  TO authenticated
  USING (auth.uid() = author_id);

-- 会员可以更新自己的回答
DROP POLICY IF EXISTS "回答者可更新自己的回答" ON answers;
CREATE POLICY "回答者可更新自己的回答" ON answers
  FOR UPDATE 
  TO authenticated
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

-- ============================================
-- 6. 添加注释
-- ============================================

COMMENT ON POLICY "所有人可查看已发布文章" ON articles IS '允许所有人（包括匿名用户和会员）查看已发布的文章';
COMMENT ON POLICY "所有人可查看已发布产品" ON products IS '允许所有人（包括匿名用户和会员）查看已发布的产品';
COMMENT ON POLICY "公开可读已发布的下载" ON downloads IS '允许所有人（包括匿名用户和会员）查看已发布的下载资源';
COMMENT ON POLICY "公开可读已发布的视频" ON videos IS '允许所有人（包括匿名用户和会员）查看已发布的视频';
COMMENT ON POLICY "所有人可查看已审核问题" ON questions IS '允许所有人（包括匿名用户和会员）查看已审核的问题';
COMMENT ON POLICY "所有人可查看回答" ON answers IS '允许所有人（包括匿名用户和会员）查看所有回答';
/*
# 修复登录时的23505错误（唯一约束违反）

## 问题描述
用户登录时出现23505错误，这是因为handle_new_user触发器尝试插入已存在的profile记录。

## 解决方案
1. 更新handle_new_user函数，使用ON CONFLICT DO NOTHING避免重复插入
2. 确保所有现有用户的confirmed_at字段都已设置
3. 添加额外的安全检查，确保不会重复创建profile
*/

-- ============================================
-- 1. 更新handle_new_user函数，添加ON CONFLICT处理
-- ============================================

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  profile_exists boolean;
BEGIN
  -- 检查profile是否已存在
  SELECT EXISTS(SELECT 1 FROM profiles WHERE id = NEW.id) INTO profile_exists;
  
  -- 如果profile已存在，直接返回
  IF profile_exists THEN
    RETURN NEW;
  END IF;
  
  -- 只在用户经过验证后再插入profiles
  IF OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL THEN
    -- 判断 profiles 表里有多少用户
    SELECT COUNT(*) INTO user_count FROM profiles;
    
    -- 插入 profiles，首位用户给 admin 角色
    -- 使用 ON CONFLICT DO NOTHING 避免重复插入
    INSERT INTO profiles (
      id, 
      username, 
      email, 
      phone, 
      role,
      status,
      level,
      points,
      total_articles,
      total_questions,
      total_answers
    )
    VALUES (
      NEW.id,
      COALESCE(SPLIT_PART(NEW.email, '@', 1), ''),
      NEW.email,
      NEW.phone,
      CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'member'::user_role END,
      'active',
      1,
      0,
      0,
      0,
      0
    )
    ON CONFLICT (id) DO NOTHING;
  END IF;
  
  RETURN NEW;
END;
$$;

-- ============================================
-- 2. 说明
-- ============================================

-- confirmed_at是Supabase自动管理的字段，不需要手动设置
-- 触发器已经添加了profile_exists检查，可以安全处理已存在的profile

-- ============================================
-- 3. 添加注释
-- ============================================

COMMENT ON FUNCTION handle_new_user() IS '处理新用户注册，自动创建profile记录。使用ON CONFLICT避免重复插入导致的23505错误。';
/*
# 修复登录时的无限递归错误

## 问题描述
用户登录后出现42P17错误（infinite recursion detected in policy for relation "profiles"）

## 根本原因
profiles表的RLS策略中存在无限递归：
- "Admins can view all member stats" 策略直接查询profiles表检查用户角色
- "Admins can update member status" 策略也直接查询profiles表
- 这导致在查询profiles表时，RLS策略又去查询profiles表，形成无限递归

## 解决方案
1. 删除导致无限递归的策略
2. 保留使用is_admin()函数的策略（因为is_admin使用SECURITY DEFINER可以绕过RLS）
3. 确保所有策略都不会直接在profiles表上查询profiles表
*/

-- ============================================
-- 1. 删除导致无限递归的策略
-- ============================================

-- 删除直接查询profiles表的策略
DROP POLICY IF EXISTS "Admins can view all member stats" ON profiles;
DROP POLICY IF EXISTS "Admins can update member status" ON profiles;

-- ============================================
-- 2. 确保基本的RLS策略存在且正确
-- ============================================

-- 公开读取用户基本信息（已存在，确保存在）
DROP POLICY IF EXISTS "公开读取用户基本信息" ON profiles;
CREATE POLICY "公开读取用户基本信息" ON profiles
  FOR SELECT
  TO public
  USING (true);

-- 用户可查看自己的信息（已存在，确保存在）
DROP POLICY IF EXISTS "用户可查看自己的信息" ON profiles;
CREATE POLICY "用户可查看自己的信息" ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- 用户可更新自己的信息但不能改角色（已存在，确保存在）
DROP POLICY IF EXISTS "用户可更新自己的信息但不能改角色" ON profiles;
CREATE POLICY "用户可更新自己的信息但不能改角色" ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- 管理员可查看所有用户（使用is_admin函数，SECURITY DEFINER可以绕过RLS）
DROP POLICY IF EXISTS "管理员可查看所有用户" ON profiles;
CREATE POLICY "管理员可查看所有用户" ON profiles
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

-- 管理员可更新所有用户（使用is_admin函数）
DROP POLICY IF EXISTS "管理员可更新所有用户" ON profiles;
CREATE POLICY "管理员可更新所有用户" ON profiles
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));

-- ============================================
-- 3. 验证is_admin函数使用SECURITY DEFINER
-- ============================================

-- 重新创建is_admin函数，确保使用SECURITY DEFINER
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- ============================================
-- 4. 添加注释
-- ============================================

COMMENT ON POLICY "公开读取用户基本信息" ON profiles IS '允许所有人（包括匿名用户）查看用户基本信息';
COMMENT ON POLICY "用户可查看自己的信息" ON profiles IS '允许已认证用户查看自己的完整信息';
COMMENT ON POLICY "用户可更新自己的信息但不能改角色" ON profiles IS '允许用户更新自己的信息，但不能修改角色字段';
COMMENT ON POLICY "管理员可查看所有用户" ON profiles IS '允许管理员查看所有用户信息。使用is_admin函数（SECURITY DEFINER）避免无限递归';
COMMENT ON POLICY "管理员可更新所有用户" ON profiles IS '允许管理员更新所有用户信息。使用is_admin函数（SECURITY DEFINER）避免无限递归';

COMMENT ON FUNCTION is_admin(uuid) IS '检查用户是否是管理员。使用SECURITY DEFINER绕过RLS，避免无限递归';
/*
# 修复登录时更新last_login_at字段的错误

## 问题描述
用户登录后出现错误：
"error update user's last_sign_in field: ERROR: relation "profilesdoes not exist (SQLSTATE 42P01)"

## 根本原因
1. update_last_login()函数没有设置search_path，可能导致找不到profiles表
2. 函数缺少错误处理，当更新失败时会导致整个登录流程失败
3. 可能存在SQL语句格式问题

## 解决方案
1. 为update_last_login()函数添加search_path设置
2. 添加异常处理，即使更新失败也不影响登录
3. 添加详细的日志记录
4. 确保SQL语句格式正确
*/

-- ============================================
-- 1. 重新创建update_last_login函数，添加完整的错误处理
-- ============================================

CREATE OR REPLACE FUNCTION update_last_login()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
BEGIN
  -- 使用异常处理，确保即使更新失败也不影响登录
  BEGIN
    -- 更新profiles表的last_login_at字段
    UPDATE public.profiles
    SET last_login_at = now()
    WHERE id = NEW.id;
    
    -- 记录成功日志（可选）
    RAISE LOG 'Successfully updated last_login_at for user %', NEW.id;
    
  EXCEPTION
    WHEN OTHERS THEN
      -- 记录错误但不抛出异常，避免影响登录流程
      RAISE WARNING 'Failed to update last_login_at for user %: % %', 
        NEW.id, SQLERRM, SQLSTATE;
  END;
  
  -- 始终返回NEW，确保触发器不会阻止操作
  RETURN NEW;
END;
$$;

-- ============================================
-- 2. 重新创建触发器，确保定义正确
-- ============================================

-- 删除旧触发器
DROP TRIGGER IF EXISTS on_auth_user_login ON auth.users;

-- 创建新触发器
CREATE TRIGGER on_auth_user_login
  AFTER UPDATE OF last_sign_in_at ON auth.users
  FOR EACH ROW
  WHEN (OLD.last_sign_in_at IS DISTINCT FROM NEW.last_sign_in_at)
  EXECUTE FUNCTION update_last_login();

-- ============================================
-- 3. 添加注释
-- ============================================

COMMENT ON FUNCTION update_last_login() IS '
更新用户的last_login_at字段。
使用SECURITY DEFINER绕过RLS。
设置search_path避免找不到表。
包含异常处理，确保更新失败不影响登录流程。
';

COMMENT ON TRIGGER on_auth_user_login ON auth.users IS '
当用户登录时（last_sign_in_at更新时）触发，更新profiles表的last_login_at字段。
';

-- ============================================
-- 4. 验证修复
-- ============================================

-- 测试函数是否可以正常执行
DO $$
DECLARE
  test_user_id uuid;
BEGIN
  -- 获取一个测试用户ID
  SELECT id INTO test_user_id FROM auth.users LIMIT 1;
  
  IF test_user_id IS NOT NULL THEN
    -- 测试更新
    UPDATE public.profiles
    SET last_login_at = now()
    WHERE id = test_user_id;
    
    RAISE NOTICE '测试成功：成功更新用户 % 的last_login_at字段', test_user_id;
  ELSE
    RAISE NOTICE '没有找到测试用户，跳过测试';
  END IF;
END $$;
/*
# 增强会员系统与整站模块的互动性

## 1. 新增功能
- 添加浏览内容的积分规则
- 为member_points_log表添加action字段
- 增强add_browsing_history函数，自动增加浏览积分
- 防止重复刷分（每个内容每天只能获得一次浏览积分）

## 2. 积分规则
- view_article: 浏览文章 +1分
- view_product: 浏览产品 +1分
- view_video: 浏览视频 +1分
- view_download: 浏览下载 +1分
- view_question: 浏览问答 +1分

## 3. 防刷分机制
- 使用member_points_log表记录积分获取时间
- 同一内容同一天只能获得一次浏览积分
*/

-- ============================================
-- 1. 为member_points_log表添加action字段
-- ============================================

ALTER TABLE member_points_log ADD COLUMN IF NOT EXISTS action text;
ALTER TABLE member_points_log ADD COLUMN IF NOT EXISTS description text;

-- 更新现有记录的action字段（从reason字段推断）
UPDATE member_points_log
SET action = CASE
  WHEN reason LIKE '%登录%' THEN 'daily_login'
  WHEN reason LIKE '%文章%' THEN 'publish_article'
  WHEN reason LIKE '%问题%' OR reason LIKE '%提问%' THEN 'publish_question'
  WHEN reason LIKE '%回答%' THEN 'publish_answer'
  ELSE 'manual'
END,
description = reason
WHERE action IS NULL;

-- 修改reference_id字段类型为text（如果需要）
ALTER TABLE member_points_log ALTER COLUMN reference_id TYPE text USING reference_id::text;

-- ============================================
-- 2. 添加浏览内容的积分规则
-- ============================================

INSERT INTO points_rules (action, points, description, enabled)
VALUES 
  ('view_article', 1, '浏览文章', true),
  ('view_product', 1, '浏览产品', true),
  ('view_video', 1, '浏览视频', true),
  ('view_download', 1, '浏览下载', true),
  ('view_question', 1, '浏览问答', true)
ON CONFLICT (action) DO UPDATE SET
  points = EXCLUDED.points,
  description = EXCLUDED.description,
  enabled = EXCLUDED.enabled,
  updated_at = now();

-- ============================================
-- 3. 增强add_browsing_history函数
-- ============================================

CREATE OR REPLACE FUNCTION add_browsing_history(
  p_user_id uuid,
  p_content_type text,
  p_content_id uuid,
  p_content_title text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_action text;
  v_points int;
  v_enabled boolean;
  v_already_earned boolean;
BEGIN
  -- 删除该用户对该内容的旧记录（保持唯一性）
  DELETE FROM browsing_history
  WHERE user_id = p_user_id
    AND content_type = p_content_type
    AND content_id = p_content_id;
  
  -- 插入新浏览记录
  INSERT INTO browsing_history (user_id, content_type, content_id, content_title)
  VALUES (p_user_id, p_content_type, p_content_id, p_content_title);
  
  -- 限制每个用户的浏览记录数量（保留最近100条）
  DELETE FROM browsing_history
  WHERE id IN (
    SELECT id FROM browsing_history
    WHERE user_id = p_user_id
    ORDER BY created_at DESC
    OFFSET 100
  );
  
  -- 根据内容类型确定积分动作
  v_action := 'view_' || p_content_type;
  
  -- 获取积分规则
  SELECT points, enabled INTO v_points, v_enabled
  FROM points_rules
  WHERE action = v_action;
  
  -- 如果积分规则存在且启用
  IF v_points IS NOT NULL AND v_enabled THEN
    -- 检查今天是否已经获得过该内容的浏览积分
    SELECT EXISTS (
      SELECT 1 FROM member_points_log
      WHERE user_id = p_user_id
        AND action = v_action
        AND reference_id = p_content_id::text
        AND created_at >= CURRENT_DATE
    ) INTO v_already_earned;
    
    -- 如果今天还没有获得过积分，则增加积分
    IF NOT v_already_earned THEN
      -- 更新用户积分
      UPDATE profiles
      SET points = points + v_points
      WHERE id = p_user_id;
      
      -- 记录积分日志
      INSERT INTO member_points_log (
        user_id,
        points,
        action,
        reason,
        description,
        reference_type,
        reference_id
      ) VALUES (
        p_user_id,
        v_points,
        v_action,
        '浏览内容获得积分',
        '浏览' || p_content_title,
        p_content_type,
        p_content_id::text
      );
      
      RAISE LOG '用户 % 浏览 % 获得 % 积分', p_user_id, p_content_title, v_points;
    END IF;
  END IF;
  
EXCEPTION
  WHEN OTHERS THEN
    -- 记录错误但不影响浏览记录的添加
    RAISE WARNING '添加浏览积分失败: % %', SQLERRM, SQLSTATE;
END;
$$;

COMMENT ON FUNCTION add_browsing_history IS '
添加浏览历史记录，并自动增加浏览积分。
- 防止重复记录：删除旧记录后插入新记录
- 限制记录数量：每个用户最多保留100条浏览记录
- 自动增加积分：根据内容类型自动增加相应积分
- 防止刷分：同一内容每天只能获得一次浏览积分
';

-- ============================================
-- 4. 创建查看用户今日积分统计的函数
-- ============================================

CREATE OR REPLACE FUNCTION get_user_daily_points_stats(p_user_id uuid)
RETURNS TABLE (
  total_points int,
  view_points int,
  publish_points int,
  interaction_points int
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    COALESCE(SUM(points), 0)::int as total_points,
    COALESCE(SUM(CASE WHEN action LIKE 'view_%' THEN points ELSE 0 END), 0)::int as view_points,
    COALESCE(SUM(CASE WHEN action LIKE 'publish_%' THEN points ELSE 0 END), 0)::int as publish_points,
    COALESCE(SUM(CASE WHEN action NOT LIKE 'view_%' AND action NOT LIKE 'publish_%' THEN points ELSE 0 END), 0)::int as interaction_points
  FROM member_points_log
  WHERE user_id = p_user_id
    AND created_at >= CURRENT_DATE;
$$;

COMMENT ON FUNCTION get_user_daily_points_stats IS '
获取用户今日积分统计，包括：
- total_points: 今日总积分
- view_points: 浏览获得的积分
- publish_points: 发布获得的积分
- interaction_points: 互动获得的积分
';

-- ============================================
-- 5. 验证修改
-- ============================================

-- 测试积分规则是否添加成功
DO $$
DECLARE
  v_count int;
BEGIN
  SELECT COUNT(*) INTO v_count
  FROM points_rules
  WHERE action LIKE 'view_%';
  
  IF v_count >= 5 THEN
    RAISE NOTICE '✓ 浏览积分规则添加成功，共 % 条规则', v_count;
  ELSE
    RAISE WARNING '✗ 浏览积分规则添加失败，只有 % 条规则', v_count;
  END IF;
END $$;

/*
# 创建SNS会员互动系统

## 1. 新增表结构

### messages（站内信表）
- id (uuid, 主键)
- sender_id (uuid, 发送者ID)
- receiver_id (uuid, 接收者ID)
- title (text, 消息标题)
- content (text, 消息内容)
- is_read (boolean, 是否已读)
- created_at (timestamptz, 创建时间)

### member_follows（关注关系表）
- id (uuid, 主键)
- follower_id (uuid, 关注者ID)
- following_id (uuid, 被关注者ID)
- created_at (timestamptz, 创建时间)
- 唯一约束：(follower_id, following_id)

### member_posts（会员动态表）
- id (uuid, 主键)
- member_id (uuid, 会员ID)
- content (text, 动态内容)
- related_type (text, 关联类型: article/question/answer)
- related_id (uuid, 关联ID)
- related_title (text, 关联标题)
- likes_count (integer, 点赞数)
- comments_count (integer, 评论数)
- created_at (timestamptz, 创建时间)

### post_likes（动态点赞表）
- id (uuid, 主键)
- post_id (uuid, 动态ID)
- member_id (uuid, 会员ID)
- created_at (timestamptz, 创建时间)
- 唯一约束：(post_id, member_id)

### post_comments（动态评论表）
- id (uuid, 主键)
- post_id (uuid, 动态ID)
- member_id (uuid, 会员ID)
- content (text, 评论内容)
- created_at (timestamptz, 创建时间)

### notifications（通知表）
- id (uuid, 主键)
- member_id (uuid, 会员ID)
- type (text, 通知类型)
- title (text, 通知标题)
- content (text, 通知内容)
- related_id (uuid, 关联ID)
- is_read (boolean, 是否已读)
- created_at (timestamptz, 创建时间)

## 2. 安全策略
- 所有表启用RLS
- 用户可以查看和管理自己的数据
- 管理员拥有完全访问权限

## 3. RPC函数
- toggle_follow: 切换关注状态
- toggle_post_like: 切换点赞状态
- get_unread_notification_count: 获取未读通知数

## 4. 触发器
- 点赞时自动创建通知
- 评论时自动创建通知
- 关注时自动创建通知
- 发送消息时自动创建通知
- 点赞时增加积分
- 评论时增加积分
- 发布动态时增加积分

## 5. Profile表扩展
- following_count (integer, 关注数)
- follower_count (integer, 粉丝数)
- post_count (integer, 动态数)
*/

-- 创建站内信表
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  receiver_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  content text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- 创建关注关系表
CREATE TABLE IF NOT EXISTS member_follows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  following_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

-- 创建会员动态表
CREATE TABLE IF NOT EXISTS member_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  content text NOT NULL,
  related_type text CHECK (related_type IN ('article', 'question', 'answer')),
  related_id uuid,
  related_title text,
  likes_count integer DEFAULT 0,
  comments_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- 创建动态点赞表
CREATE TABLE IF NOT EXISTS post_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES member_posts(id) ON DELETE CASCADE NOT NULL,
  member_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, member_id)
);

-- 创建动态评论表
CREATE TABLE IF NOT EXISTS post_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES member_posts(id) ON DELETE CASCADE NOT NULL,
  member_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 创建通知表
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL CHECK (type IN ('message', 'follow', 'like', 'comment')),
  title text NOT NULL,
  content text NOT NULL,
  related_id uuid,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- 为profiles表添加SNS统计字段
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS following_count integer DEFAULT 0;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS follower_count integer DEFAULT 0;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS post_count integer DEFAULT 0;

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_messages_receiver ON messages(receiver_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_member_follows_follower ON member_follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_member_follows_following ON member_follows(following_id);
CREATE INDEX IF NOT EXISTS idx_member_posts_member ON member_posts(member_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_post_likes_post ON post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_post_comments_post ON post_comments(post_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_member ON notifications(member_id, created_at DESC);

-- 启用RLS
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE member_follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE member_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- messages表的RLS策略
CREATE POLICY "Users can view their own messages" ON messages
  FOR SELECT USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can send messages" ON messages
  FOR INSERT WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Users can delete their own messages" ON messages
  FOR DELETE USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Admins have full access to messages" ON messages
  FOR ALL USING (is_admin(auth.uid()));

-- member_follows表的RLS策略
CREATE POLICY "Anyone can view follows" ON member_follows
  FOR SELECT USING (true);

CREATE POLICY "Users can manage their own follows" ON member_follows
  FOR ALL USING (auth.uid() = follower_id);

CREATE POLICY "Admins have full access to follows" ON member_follows
  FOR ALL USING (is_admin(auth.uid()));

-- member_posts表的RLS策略
CREATE POLICY "Anyone can view posts" ON member_posts
  FOR SELECT USING (true);

CREATE POLICY "Users can create their own posts" ON member_posts
  FOR INSERT WITH CHECK (auth.uid() = member_id);

CREATE POLICY "Users can update their own posts" ON member_posts
  FOR UPDATE USING (auth.uid() = member_id);

CREATE POLICY "Users can delete their own posts" ON member_posts
  FOR DELETE USING (auth.uid() = member_id);

CREATE POLICY "Admins have full access to posts" ON member_posts
  FOR ALL USING (is_admin(auth.uid()));

-- post_likes表的RLS策略
CREATE POLICY "Anyone can view likes" ON post_likes
  FOR SELECT USING (true);

CREATE POLICY "Users can manage their own likes" ON post_likes
  FOR ALL USING (auth.uid() = member_id);

-- post_comments表的RLS策略
CREATE POLICY "Anyone can view comments" ON post_comments
  FOR SELECT USING (true);

CREATE POLICY "Users can create comments" ON post_comments
  FOR INSERT WITH CHECK (auth.uid() = member_id);

CREATE POLICY "Users can delete their own comments" ON post_comments
  FOR DELETE USING (auth.uid() = member_id);

CREATE POLICY "Admins have full access to comments" ON post_comments
  FOR ALL USING (is_admin(auth.uid()));

-- notifications表的RLS策略
CREATE POLICY "Users can view their own notifications" ON notifications
  FOR SELECT USING (auth.uid() = member_id);

CREATE POLICY "Users can update their own notifications" ON notifications
  FOR UPDATE USING (auth.uid() = member_id);

CREATE POLICY "Users can delete their own notifications" ON notifications
  FOR DELETE USING (auth.uid() = member_id);

-- RPC函数：切换关注状态
CREATE OR REPLACE FUNCTION toggle_follow(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_id uuid;
  is_following boolean;
BEGIN
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  IF current_user_id = target_user_id THEN
    RAISE EXCEPTION 'Cannot follow yourself';
  END IF;
  
  SELECT EXISTS(
    SELECT 1 FROM member_follows 
    WHERE follower_id = current_user_id AND following_id = target_user_id
  ) INTO is_following;
  
  IF is_following THEN
    DELETE FROM member_follows 
    WHERE follower_id = current_user_id AND following_id = target_user_id;
    
    UPDATE profiles SET follower_count = GREATEST(0, follower_count - 1) 
    WHERE id = target_user_id;
    
    UPDATE profiles SET following_count = GREATEST(0, following_count - 1) 
    WHERE id = current_user_id;
    
    RETURN false;
  ELSE
    INSERT INTO member_follows (follower_id, following_id) 
    VALUES (current_user_id, target_user_id);
    
    UPDATE profiles SET follower_count = follower_count + 1 
    WHERE id = target_user_id;
    
    UPDATE profiles SET following_count = following_count + 1 
    WHERE id = current_user_id;
    
    RETURN true;
  END IF;
END;
$$;

-- RPC函数：切换点赞状态
CREATE OR REPLACE FUNCTION toggle_post_like(target_post_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_id uuid;
  is_liked boolean;
BEGIN
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  SELECT EXISTS(
    SELECT 1 FROM post_likes 
    WHERE post_id = target_post_id AND member_id = current_user_id
  ) INTO is_liked;
  
  IF is_liked THEN
    DELETE FROM post_likes 
    WHERE post_id = target_post_id AND member_id = current_user_id;
    
    UPDATE member_posts SET likes_count = GREATEST(0, likes_count - 1) 
    WHERE id = target_post_id;
    
    RETURN false;
  ELSE
    INSERT INTO post_likes (post_id, member_id) 
    VALUES (target_post_id, current_user_id);
    
    UPDATE member_posts SET likes_count = likes_count + 1 
    WHERE id = target_post_id;
    
    RETURN true;
  END IF;
END;
$$;

-- RPC函数：获取未读通知数
CREATE OR REPLACE FUNCTION get_unread_notification_count(user_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  unread_count integer;
BEGIN
  SELECT COUNT(*) INTO unread_count
  FROM notifications
  WHERE member_id = user_id AND is_read = false;
  
  RETURN unread_count;
END;
$$;

-- 触发器：点赞时创建通知
CREATE OR REPLACE FUNCTION notify_post_like()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  post_author_id uuid;
  liker_username text;
BEGIN
  SELECT member_id INTO post_author_id FROM member_posts WHERE id = NEW.post_id;
  SELECT username INTO liker_username FROM profiles WHERE id = NEW.member_id;
  
  IF post_author_id != NEW.member_id THEN
    INSERT INTO notifications (member_id, type, title, content, related_id)
    VALUES (
      post_author_id,
      'like',
      '新的点赞',
      liker_username || ' 赞了你的动态',
      NEW.post_id
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_notify_post_like
AFTER INSERT ON post_likes
FOR EACH ROW
EXECUTE FUNCTION notify_post_like();

-- 触发器：评论时创建通知
CREATE OR REPLACE FUNCTION notify_post_comment()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  post_author_id uuid;
  commenter_username text;
BEGIN
  SELECT member_id INTO post_author_id FROM member_posts WHERE id = NEW.post_id;
  SELECT username INTO commenter_username FROM profiles WHERE id = NEW.member_id;
  
  IF post_author_id != NEW.member_id THEN
    INSERT INTO notifications (member_id, type, title, content, related_id)
    VALUES (
      post_author_id,
      'comment',
      '新的评论',
      commenter_username || ' 评论了你的动态',
      NEW.post_id
    );
  END IF;
  
  UPDATE member_posts SET comments_count = comments_count + 1 WHERE id = NEW.post_id;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_notify_post_comment
AFTER INSERT ON post_comments
FOR EACH ROW
EXECUTE FUNCTION notify_post_comment();

-- 触发器：关注时创建通知
CREATE OR REPLACE FUNCTION notify_new_follow()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  follower_username text;
BEGIN
  SELECT username INTO follower_username FROM profiles WHERE id = NEW.follower_id;
  
  INSERT INTO notifications (member_id, type, title, content, related_id)
  VALUES (
    NEW.following_id,
    'follow',
    '新的关注',
    follower_username || ' 关注了你',
    NEW.follower_id
  );
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_notify_new_follow
AFTER INSERT ON member_follows
FOR EACH ROW
EXECUTE FUNCTION notify_new_follow();

-- 触发器：发送消息时创建通知
CREATE OR REPLACE FUNCTION notify_new_message()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  sender_username text;
BEGIN
  SELECT username INTO sender_username FROM profiles WHERE id = NEW.sender_id;
  
  INSERT INTO notifications (member_id, type, title, content, related_id)
  VALUES (
    NEW.receiver_id,
    'message',
    '新的站内信',
    sender_username || ' 给你发送了一条消息',
    NEW.id
  );
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_notify_new_message
AFTER INSERT ON messages
FOR EACH ROW
EXECUTE FUNCTION notify_new_message();

-- 触发器：点赞时增加积分
CREATE OR REPLACE FUNCTION add_points_for_like()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  post_author_id uuid;
BEGIN
  SELECT member_id INTO post_author_id FROM member_posts WHERE id = NEW.post_id;
  
  IF post_author_id != NEW.member_id THEN
    UPDATE profiles SET points = points + 2 WHERE id = post_author_id;
    
    INSERT INTO member_points_log (member_id, points, action, description)
    VALUES (post_author_id, 2, 'post_liked', '动态被点赞');
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_add_points_for_like
AFTER INSERT ON post_likes
FOR EACH ROW
EXECUTE FUNCTION add_points_for_like();

-- 触发器：评论时增加积分
CREATE OR REPLACE FUNCTION add_points_for_comment()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  post_author_id uuid;
BEGIN
  SELECT member_id INTO post_author_id FROM member_posts WHERE id = NEW.post_id;
  
  IF post_author_id != NEW.member_id THEN
    UPDATE profiles SET points = points + 3 WHERE id = post_author_id;
    
    INSERT INTO member_points_log (member_id, points, action, description)
    VALUES (post_author_id, 3, 'post_commented', '动态被评论');
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_add_points_for_comment
AFTER INSERT ON post_comments
FOR EACH ROW
EXECUTE FUNCTION add_points_for_comment();

-- 触发器：发布动态时增加积分
CREATE OR REPLACE FUNCTION add_points_for_post()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE profiles SET points = points + 5, post_count = post_count + 1 WHERE id = NEW.member_id;
  
  INSERT INTO member_points_log (member_id, points, action, description)
  VALUES (NEW.member_id, 5, 'create_post', '发布动态');
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_add_points_for_post
AFTER INSERT ON member_posts
FOR EACH ROW
EXECUTE FUNCTION add_points_for_post();

-- 触发器：删除动态时减少积分和计数
CREATE OR REPLACE FUNCTION remove_points_for_post()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE profiles 
  SET points = GREATEST(0, points - 5), 
      post_count = GREATEST(0, post_count - 1) 
  WHERE id = OLD.member_id;
  
  RETURN OLD;
END;
$$;

CREATE TRIGGER trigger_remove_points_for_post
AFTER DELETE ON member_posts
FOR EACH ROW
EXECUTE FUNCTION remove_points_for_post();
/*
# Extend SNS System to Support More Modules

## 1. Changes
- Extend member_posts.related_type to support 'download' and 'video'
- This allows downloads and videos to automatically create posts

## 2. Supported Module Types
- article: Article posts
- question: Question posts
- answer: Answer posts
- download: Download posts
- video: Video posts
*/

-- Drop the existing constraint
ALTER TABLE member_posts DROP CONSTRAINT IF EXISTS member_posts_related_type_check;

-- Add new constraint with extended types
ALTER TABLE member_posts ADD CONSTRAINT member_posts_related_type_check 
  CHECK (related_type IN ('article', 'question', 'answer', 'download', 'video'));
/*
# 访问流量统计系统

## 1. 新建表

### page_views (页面访问记录)
- `id` (uuid, 主键)
- `visitor_id` (text, 访客唯一标识)
- `page_url` (text, 访问页面URL)
- `page_title` (text, 页面标题)
- `referrer` (text, 来源页面)
- `user_agent` (text, 浏览器信息)
- `device_type` (text, 设备类型: desktop/mobile/tablet)
- `browser` (text, 浏览器名称)
- `os` (text, 操作系统)
- `ip_address` (text, IP地址)
- `country` (text, 国家)
- `region` (text, 地区/省份)
- `city` (text, 城市)
- `session_id` (text, 会话ID)
- `duration` (integer, 停留时长秒数)
- `created_at` (timestamptz, 访问时间)

### visitor_sessions (访客会话)
- `id` (uuid, 主键)
- `visitor_id` (text, 访客ID)
- `session_id` (text, 会话ID)
- `first_visit` (timestamptz, 首次访问时间)
- `last_visit` (timestamptz, 最后访问时间)
- `page_views_count` (integer, 页面浏览数)
- `total_duration` (integer, 总停留时长)

### analytics_summary (统计汇总 - 按天)
- `id` (uuid, 主键)
- `date` (date, 日期)
- `total_views` (integer, 总访问量)
- `unique_visitors` (integer, 独立访客数)
- `avg_duration` (integer, 平均停留时长)
- `bounce_rate` (numeric, 跳出率)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

## 2. 安全策略
- page_views表：公开读取权限（用于统计），管理员可写入
- visitor_sessions表：公开读取权限，管理员可写入
- analytics_summary表：公开读取权限，管理员可写入

## 3. 索引
- page_views: visitor_id, page_url, created_at
- visitor_sessions: visitor_id, session_id
- analytics_summary: date

## 4. RPC函数
- record_page_view: 记录页面访问
- get_analytics_summary: 获取统计汇总
*/

-- 创建页面访问记录表
CREATE TABLE IF NOT EXISTS page_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id text NOT NULL,
  page_url text NOT NULL,
  page_title text,
  referrer text,
  user_agent text,
  device_type text,
  browser text,
  os text,
  ip_address text,
  country text,
  region text,
  city text,
  session_id text NOT NULL,
  duration integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- 创建访客会话表
CREATE TABLE IF NOT EXISTS visitor_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id text NOT NULL,
  session_id text NOT NULL UNIQUE,
  first_visit timestamptz DEFAULT now(),
  last_visit timestamptz DEFAULT now(),
  page_views_count integer DEFAULT 0,
  total_duration integer DEFAULT 0
);

-- 创建统计汇总表
CREATE TABLE IF NOT EXISTS analytics_summary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL UNIQUE,
  total_views integer DEFAULT 0,
  unique_visitors integer DEFAULT 0,
  avg_duration integer DEFAULT 0,
  bounce_rate numeric(5,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_page_views_visitor_id ON page_views(visitor_id);
CREATE INDEX IF NOT EXISTS idx_page_views_page_url ON page_views(page_url);
CREATE INDEX IF NOT EXISTS idx_page_views_created_at ON page_views(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_page_views_session_id ON page_views(session_id);
CREATE INDEX IF NOT EXISTS idx_visitor_sessions_visitor_id ON visitor_sessions(visitor_id);
CREATE INDEX IF NOT EXISTS idx_visitor_sessions_session_id ON visitor_sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_analytics_summary_date ON analytics_summary(date DESC);

-- 启用RLS
ALTER TABLE page_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE visitor_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics_summary ENABLE ROW LEVEL SECURITY;

-- 创建策略：所有人可以插入访问记录
CREATE POLICY "Anyone can insert page views" ON page_views
  FOR INSERT TO anon, authenticated
  WITH CHECK (true);

-- 创建策略：所有人可以读取访问记录
CREATE POLICY "Anyone can read page views" ON page_views
  FOR SELECT TO anon, authenticated
  USING (true);

-- 创建策略：所有人可以插入会话记录
CREATE POLICY "Anyone can insert sessions" ON visitor_sessions
  FOR INSERT TO anon, authenticated
  WITH CHECK (true);

-- 创建策略：所有人可以更新会话记录
CREATE POLICY "Anyone can update sessions" ON visitor_sessions
  FOR UPDATE TO anon, authenticated
  USING (true);

-- 创建策略：所有人可以读取会话记录
CREATE POLICY "Anyone can read sessions" ON visitor_sessions
  FOR SELECT TO anon, authenticated
  USING (true);

-- 创建策略：所有人可以读取统计汇总
CREATE POLICY "Anyone can read analytics summary" ON analytics_summary
  FOR SELECT TO anon, authenticated
  USING (true);

-- 创建策略：管理员可以管理统计汇总
CREATE POLICY "Admins can manage analytics summary" ON analytics_summary
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- 创建RPC函数：记录页面访问
CREATE OR REPLACE FUNCTION record_page_view(
  p_visitor_id text,
  p_session_id text,
  p_page_url text,
  p_page_title text DEFAULT NULL,
  p_referrer text DEFAULT NULL,
  p_user_agent text DEFAULT NULL,
  p_device_type text DEFAULT NULL,
  p_browser text DEFAULT NULL,
  p_os text DEFAULT NULL,
  p_ip_address text DEFAULT NULL,
  p_country text DEFAULT NULL,
  p_region text DEFAULT NULL,
  p_city text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_view_id uuid;
  v_session_exists boolean;
BEGIN
  -- 插入页面访问记录
  INSERT INTO page_views (
    visitor_id, session_id, page_url, page_title, referrer,
    user_agent, device_type, browser, os, ip_address,
    country, region, city
  ) VALUES (
    p_visitor_id, p_session_id, p_page_url, p_page_title, p_referrer,
    p_user_agent, p_device_type, p_browser, p_os, p_ip_address,
    p_country, p_region, p_city
  ) RETURNING id INTO v_view_id;

  -- 检查会话是否存在
  SELECT EXISTS(
    SELECT 1 FROM visitor_sessions WHERE session_id = p_session_id
  ) INTO v_session_exists;

  IF v_session_exists THEN
    -- 更新现有会话
    UPDATE visitor_sessions
    SET 
      last_visit = now(),
      page_views_count = page_views_count + 1
    WHERE session_id = p_session_id;
  ELSE
    -- 创建新会话
    INSERT INTO visitor_sessions (visitor_id, session_id, page_views_count)
    VALUES (p_visitor_id, p_session_id, 1);
  END IF;

  RETURN v_view_id;
END;
$$;

-- 创建RPC函数：更新页面停留时长
CREATE OR REPLACE FUNCTION update_page_duration(
  p_view_id uuid,
  p_duration integer
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE page_views
  SET duration = p_duration
  WHERE id = p_view_id;

  -- 更新会话总时长
  UPDATE visitor_sessions vs
  SET total_duration = (
    SELECT COALESCE(SUM(duration), 0)
    FROM page_views pv
    WHERE pv.session_id = vs.session_id
  )
  WHERE session_id = (
    SELECT session_id FROM page_views WHERE id = p_view_id
  );
END;
$$;

-- 创建RPC函数：获取实时统计
CREATE OR REPLACE FUNCTION get_realtime_analytics(
  p_days integer DEFAULT 7
)
RETURNS TABLE (
  date date,
  total_views bigint,
  unique_visitors bigint,
  avg_duration numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    DATE(pv.created_at) as date,
    COUNT(*)::bigint as total_views,
    COUNT(DISTINCT pv.visitor_id)::bigint as unique_visitors,
    ROUND(AVG(pv.duration))::numeric as avg_duration
  FROM page_views pv
  WHERE pv.created_at >= CURRENT_DATE - p_days
  GROUP BY DATE(pv.created_at)
  ORDER BY date DESC;
END;
$$;

-- 创建RPC函数：获取页面访问排行
CREATE OR REPLACE FUNCTION get_top_pages(
  p_limit integer DEFAULT 10,
  p_days integer DEFAULT 7
)
RETURNS TABLE (
  page_url text,
  page_title text,
  view_count bigint,
  unique_visitors bigint,
  avg_duration numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pv.page_url,
    MAX(pv.page_title) as page_title,
    COUNT(*)::bigint as view_count,
    COUNT(DISTINCT pv.visitor_id)::bigint as unique_visitors,
    ROUND(AVG(pv.duration))::numeric as avg_duration
  FROM page_views pv
  WHERE pv.created_at >= CURRENT_DATE - p_days
  GROUP BY pv.page_url
  ORDER BY view_count DESC
  LIMIT p_limit;
END;
$$;

-- 创建RPC函数：获取地区分布
CREATE OR REPLACE FUNCTION get_location_stats(
  p_days integer DEFAULT 7
)
RETURNS TABLE (
  country text,
  region text,
  city text,
  view_count bigint,
  unique_visitors bigint
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COALESCE(pv.country, '未知') as country,
    COALESCE(pv.region, '未知') as region,
    COALESCE(pv.city, '未知') as city,
    COUNT(*)::bigint as view_count,
    COUNT(DISTINCT pv.visitor_id)::bigint as unique_visitors
  FROM page_views pv
  WHERE pv.created_at >= CURRENT_DATE - p_days
  GROUP BY pv.country, pv.region, pv.city
  ORDER BY view_count DESC;
END;
$$;

-- 创建RPC函数：获取设备统计
CREATE OR REPLACE FUNCTION get_device_stats(
  p_days integer DEFAULT 7
)
RETURNS TABLE (
  device_type text,
  browser text,
  os text,
  view_count bigint,
  unique_visitors bigint
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COALESCE(pv.device_type, '未知') as device_type,
    COALESCE(pv.browser, '未知') as browser,
    COALESCE(pv.os, '未知') as os,
    COUNT(*)::bigint as view_count,
    COUNT(DISTINCT pv.visitor_id)::bigint as unique_visitors
  FROM page_views pv
  WHERE pv.created_at >= CURRENT_DATE - p_days
  GROUP BY pv.device_type, pv.browser, pv.os
  ORDER BY view_count DESC;
END;
$$;
/*
# 为articles表添加language字段

## 说明
为articles表添加language字段，用于标识文章的语言。支持中文(zh)和英文(en)。

## 变更内容
1. 添加language字段到articles表
   - 类型：text
   - 默认值：'zh'（中文）
   - 可选值：'zh'（中文）、'en'（英文）

2. 为现有文章设置默认语言为中文

## 注意事项
- 现有文章将自动设置为中文
- 新创建的文章默认为中文，可以在创建时指定语言
*/

-- 添加language字段到articles表
ALTER TABLE articles ADD COLUMN IF NOT EXISTS language text DEFAULT 'zh' NOT NULL;

-- 为现有文章设置语言为中文
UPDATE articles SET language = 'zh' WHERE language IS NULL;

-- 添加注释
COMMENT ON COLUMN articles.language IS '文章语言：zh=中文, en=英文';
/*
# 添加新的会员等级枚举值

## 1. 新增会员等级
- bronze: 铜牌会员（注册即可获得）
- silver: 银牌会员（邮箱验证后升级）
- gold: 金牌会员（高级会员）

## 2. 注意事项
- 枚举值添加后需要在新事务中使用
*/

-- 添加新的会员等级枚举值
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'bronze' AND enumtypid = 'member_level'::regtype) THEN
    ALTER TYPE member_level ADD VALUE 'bronze';
  END IF;
END $$;

DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'silver' AND enumtypid = 'member_level'::regtype) THEN
    ALTER TYPE member_level ADD VALUE 'silver';
  END IF;
END $$;

DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'gold' AND enumtypid = 'member_level'::regtype) THEN
    ALTER TYPE member_level ADD VALUE 'gold';
  END IF;
END $$;
/*
# 会员社交功能增强

## 1. 新增表结构
- `message_templates` - 消息模板表
- `follows` - 关注关系表
- `direct_messages` - 站内信表

## 2. profiles表扩展
- 邮箱验证相关字段
- 个人主页相关字段

## 3. 安全策略
- 消息模板：管理员可管理，所有人可读
- 关注关系：用户可管理自己的关注，所有人可查看
- 站内信：仅发送者和接收者可见

## 4. 初始数据
- 插入欢迎消息模板（英文）
*/

-- 1. 扩展profiles表
ALTER TABLE profiles 
  ADD COLUMN IF NOT EXISTS email_verified boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS email_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS bio text,
  ADD COLUMN IF NOT EXISTS avatar_url text,
  ADD COLUMN IF NOT EXISTS website text,
  ADD COLUMN IF NOT EXISTS location text;

-- 更新现有用户为bronze等级
UPDATE profiles SET member_level = 'bronze'::member_level 
WHERE member_level IN ('member'::member_level, 'guest'::member_level);

-- 2. 创建消息模板表
CREATE TABLE IF NOT EXISTS message_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_key text UNIQUE NOT NULL,
  template_name text NOT NULL,
  subject text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 3. 创建关注关系表
CREATE TABLE IF NOT EXISTS follows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  following_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

CREATE INDEX IF NOT EXISTS idx_follows_follower ON follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following ON follows(following_id);

-- 4. 创建站内信表
CREATE TABLE IF NOT EXISTS direct_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  receiver_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  CHECK (sender_id != receiver_id)
);

CREATE INDEX IF NOT EXISTS idx_direct_messages_sender ON direct_messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_direct_messages_receiver ON direct_messages(receiver_id);
CREATE INDEX IF NOT EXISTS idx_direct_messages_created ON direct_messages(created_at DESC);

-- 5. 安全策略

-- message_templates 策略
ALTER TABLE message_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "所有人可查看消息模板" ON message_templates
  FOR SELECT TO authenticated, anon USING (true);

CREATE POLICY "管理员可管理消息模板" ON message_templates
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- follows 策略
ALTER TABLE follows ENABLE ROW LEVEL SECURITY;

CREATE POLICY "所有人可查看关注关系" ON follows
  FOR SELECT TO authenticated, anon USING (true);

CREATE POLICY "用户可关注他人" ON follows
  FOR INSERT TO authenticated 
  WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "用户可取消关注" ON follows
  FOR DELETE TO authenticated 
  USING (auth.uid() = follower_id);

-- direct_messages 策略
ALTER TABLE direct_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "用户可查看自己的消息" ON direct_messages
  FOR SELECT TO authenticated 
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "用户可发送消息" ON direct_messages
  FOR INSERT TO authenticated 
  WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "接收者可标记已读" ON direct_messages
  FOR UPDATE TO authenticated 
  USING (auth.uid() = receiver_id)
  WITH CHECK (auth.uid() = receiver_id);

-- 6. 创建辅助函数

-- 检查是否为好友（相互关注）
CREATE OR REPLACE FUNCTION are_friends(user1_id uuid, user2_id uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM follows 
    WHERE follower_id = user1_id AND following_id = user2_id
  ) AND EXISTS (
    SELECT 1 FROM follows 
    WHERE follower_id = user2_id AND following_id = user1_id
  );
$$;

-- 获取用户关注数
CREATE OR REPLACE FUNCTION get_following_count(user_id uuid)
RETURNS bigint LANGUAGE sql SECURITY DEFINER AS $$
  SELECT COUNT(*) FROM follows WHERE follower_id = user_id;
$$;

-- 获取用户粉丝数
CREATE OR REPLACE FUNCTION get_followers_count(user_id uuid)
RETURNS bigint LANGUAGE sql SECURITY DEFINER AS $$
  SELECT COUNT(*) FROM follows WHERE following_id = user_id;
$$;

-- 获取未读消息数
CREATE OR REPLACE FUNCTION get_unread_messages_count(user_id uuid)
RETURNS bigint LANGUAGE sql SECURITY DEFINER AS $$
  SELECT COUNT(*) FROM direct_messages 
  WHERE receiver_id = user_id AND is_read = false;
$$;

-- 验证邮箱并升级会员等级
CREATE OR REPLACE FUNCTION verify_email_and_upgrade(user_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE profiles 
  SET 
    email_verified = true,
    email_verified_at = now(),
    member_level = 'silver'::member_level
  WHERE id = user_id AND email_verified = false;
END;
$$;

-- 7. 插入默认消息模板

INSERT INTO message_templates (template_key, template_name, subject, content) VALUES
('welcome_message', 'Welcome Message', 'Welcome to Our Community!', 
'Dear Member,

Welcome to our community! We are thrilled to have you here.

As a Bronze member, you can now:
- Browse and read all articles
- Ask questions and get answers
- Participate in community discussions

To unlock more features and become a Silver member, please verify your email address.

Best regards,
The Team')
ON CONFLICT (template_key) DO NOTHING;

-- 8. 创建触发器：新用户注册时发送欢迎消息

CREATE OR REPLACE FUNCTION send_welcome_notification()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  welcome_template record;
BEGIN
  -- 获取欢迎消息模板
  SELECT subject, content INTO welcome_template 
  FROM message_templates 
  WHERE template_key = 'welcome_message';
  
  -- 插入通知
  IF welcome_template IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, content, is_read)
    VALUES (NEW.id, 'system', welcome_template.subject, welcome_template.content, false);
  END IF;
  
  RETURN NEW;
END;
$$;

-- 删除旧触发器（如果存在）
DROP TRIGGER IF EXISTS trigger_send_welcome_notification ON profiles;

-- 创建新触发器
CREATE TRIGGER trigger_send_welcome_notification
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION send_welcome_notification();
/*
# 添加个人主页设置功能

1. 扩展profiles表
  - 添加 `profile_visibility` 字段：个人主页可见性（public/friends/private）
  - 添加 `show_email` 字段：是否显示邮箱
  - 添加 `show_articles` 字段：是否显示文章
  - 添加 `show_questions` 字段：是否显示问答
  - 添加 `show_sns` 字段：是否显示动态

2. 安全策略
  - 用户可以查看和编辑自己的个人主页设置
  - 管理员可以查看和管理所有用户的个人主页设置
*/

-- 创建个人主页可见性枚举类型
CREATE TYPE profile_visibility AS ENUM ('public', 'friends', 'private');

-- 添加个人主页设置字段
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS profile_visibility profile_visibility DEFAULT 'public'::profile_visibility NOT NULL,
ADD COLUMN IF NOT EXISTS show_email boolean DEFAULT false NOT NULL,
ADD COLUMN IF NOT EXISTS show_articles boolean DEFAULT true NOT NULL,
ADD COLUMN IF NOT EXISTS show_questions boolean DEFAULT true NOT NULL,
ADD COLUMN IF NOT EXISTS show_sns boolean DEFAULT true NOT NULL;

-- 创建个人主页访问权限检查函数
CREATE OR REPLACE FUNCTION can_view_profile(viewer_id uuid, profile_owner_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  visibility profile_visibility;
  is_friend boolean;
BEGIN
  -- 如果是查看自己的主页，总是允许
  IF viewer_id = profile_owner_id THEN
    RETURN true;
  END IF;

  -- 如果是管理员，总是允许
  IF is_admin(viewer_id) THEN
    RETURN true;
  END IF;

  -- 获取主页可见性设置
  SELECT profile_visibility INTO visibility
  FROM profiles
  WHERE id = profile_owner_id;

  -- 如果是公开的，允许访问
  IF visibility = 'public' THEN
    RETURN true;
  END IF;

  -- 如果是私密的，不允许访问
  IF visibility = 'private' THEN
    RETURN false;
  END IF;

  -- 如果是仅好友可见，检查是否是好友
  IF visibility = 'friends' THEN
    SELECT are_friends(viewer_id, profile_owner_id) INTO is_friend;
    RETURN is_friend;
  END IF;

  RETURN false;
END;
$$;

-- 创建个人主页管理表（用于管理后台）
CREATE TABLE IF NOT EXISTS profile_management_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  admin_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  action text NOT NULL,
  reason text,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- 为profile_management_logs表启用RLS
ALTER TABLE profile_management_logs ENABLE ROW LEVEL SECURITY;

-- 只有管理员可以查看和操作管理日志
CREATE POLICY "管理员可以查看所有管理日志" ON profile_management_logs
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "管理员可以创建管理日志" ON profile_management_logs
  FOR INSERT TO authenticated WITH CHECK (is_admin(auth.uid()));

-- 创建索引以提高查询性能
CREATE INDEX IF NOT EXISTS idx_profile_management_logs_profile_id ON profile_management_logs(profile_id);
CREATE INDEX IF NOT EXISTS idx_profile_management_logs_admin_id ON profile_management_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_profile_management_logs_created_at ON profile_management_logs(created_at DESC);
/*
# Auto-enable Profile for Silver+ Members

## Overview
Automatically enable profile settings for Silver and above members when they register or upgrade.

## Changes
1. Create trigger function to auto-enable profile settings
2. Add trigger on profiles table for INSERT and UPDATE operations
3. Set default profile_visibility to 'public' for Silver+ members

## Implementation Details
- When a new profile is created with member_level >= 'silver', automatically set:
  - profile_visibility = 'public'
  - show_articles = true
  - show_questions = true
  - show_sns = true
  - show_email = false (for privacy)
- When an existing profile is upgraded to Silver+, apply the same settings if not already configured

## Security
- Function runs with SECURITY DEFINER to ensure proper permissions
- Only affects profiles with member_level of 'silver', 'gold', 'premium', or 'svip'
*/

-- 创建自动开通个人主页的触发器函数
CREATE OR REPLACE FUNCTION auto_enable_profile_for_silver_plus()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 检查会员等级是否为Silver及以上
  IF NEW.member_level IN ('silver', 'gold', 'premium', 'svip') THEN
    -- 如果是新插入或等级升级，自动设置个人主页为公开
    IF (TG_OP = 'INSERT') OR 
       (TG_OP = 'UPDATE' AND OLD.member_level NOT IN ('silver', 'gold', 'premium', 'svip')) THEN
      
      -- 设置默认的个人主页配置
      NEW.profile_visibility := 'public';
      NEW.show_articles := true;
      NEW.show_questions := true;
      NEW.show_sns := true;
      NEW.show_email := COALESCE(NEW.show_email, false);
      
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- 创建触发器
DROP TRIGGER IF EXISTS trigger_auto_enable_profile ON profiles;
CREATE TRIGGER trigger_auto_enable_profile
  BEFORE INSERT OR UPDATE OF member_level ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION auto_enable_profile_for_silver_plus();

-- 为现有的Silver+会员更新个人主页设置（如果尚未设置）
UPDATE profiles
SET 
  profile_visibility = 'public',
  show_articles = true,
  show_questions = true,
  show_sns = true,
  show_email = COALESCE(show_email, false)
WHERE 
  member_level IN ('silver', 'gold', 'premium', 'svip')
  AND profile_visibility IS NULL;
/*
# 添加邮箱验证和欢迎消息功能

## 概述
1. 添加系统设置表，用于存储欢迎消息模板
2. 创建自动发送欢迎消息的触发器
3. 添加邮箱验证后自动升级为Silver会员的功能
4. 添加管理员手动设置邮箱验证状态的RPC函数

## 表结构
- system_settings: 系统设置表
  - id (uuid): 主键
  - setting_key (text): 设置键名
  - setting_value (jsonb): 设置值
  - description (text): 设置描述
  - updated_at (timestamptz): 更新时间
  - updated_by (uuid): 更新者ID

## 功能
1. 新会员注册时自动发送欢迎消息
2. 邮箱验证后自动升级为Silver会员
3. 管理员可以手动设置会员的邮箱验证状态
4. 管理员可以编辑欢迎消息模板

## 安全性
- system_settings表启用RLS
- 只有管理员可以修改系统设置
- 所有用户可以读取系统设置
*/

-- 创建系统设置表
CREATE TABLE IF NOT EXISTS system_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value jsonb NOT NULL DEFAULT '{}'::jsonb,
  description text,
  updated_at timestamptz DEFAULT now(),
  updated_by uuid REFERENCES profiles(id)
);

-- 启用RLS
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- 所有人可以读取系统设置
CREATE POLICY "Anyone can read system settings" ON system_settings
  FOR SELECT USING (true);

-- 只有管理员可以修改系统设置
CREATE POLICY "Only admins can modify system settings" ON system_settings
  FOR ALL USING (is_admin(auth.uid()));

-- 插入默认欢迎消息模板
INSERT INTO system_settings (setting_key, setting_value, description)
VALUES (
  'welcome_message_template',
  jsonb_build_object(
    'enabled', true,
    'title', '欢迎加入iFixes官方平台！',
    'content', '亲爱的 {username}，\n\n欢迎您注册成为iFixes官方平台的会员！\n\n我们很高兴您的加入。在这里，您可以：\n- 与技术专家在线交流\n- 获取最新的技术资讯\n- 享受会员专属服务\n\n温馨提示：验证您的邮箱后，您将自动升级为Silver会员，享受更多特权！\n\n如有任何问题，请随时联系我们的客服团队。\n\n祝您使用愉快！\n\niFixes团队'
  ),
  '新会员注册欢迎消息模板'
) ON CONFLICT (setting_key) DO NOTHING;

-- 创建自动发送欢迎消息的触发器函数
CREATE OR REPLACE FUNCTION send_welcome_message_on_register()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  welcome_settings jsonb;
  message_title text;
  message_content text;
BEGIN
  -- 获取欢迎消息设置
  SELECT setting_value INTO welcome_settings
  FROM system_settings
  WHERE setting_key = 'welcome_message_template';

  -- 检查是否启用欢迎消息
  IF welcome_settings IS NOT NULL AND (welcome_settings->>'enabled')::boolean = true THEN
    -- 获取消息标题和内容
    message_title := welcome_settings->>'title';
    message_content := welcome_settings->>'content';
    
    -- 替换占位符
    message_content := replace(message_content, '{username}', COALESCE(NEW.username, NEW.nickname, '用户'));
    
    -- 插入站内消息
    INSERT INTO messages (
      sender_id,
      receiver_id,
      title,
      content,
      message_type
    ) VALUES (
      NULL,  -- 系统消息，sender_id为NULL
      NEW.id,
      message_title,
      message_content,
      'system'
    );
  END IF;

  RETURN NEW;
END;
$$;

-- 创建触发器：新用户注册时发送欢迎消息
DROP TRIGGER IF EXISTS trigger_send_welcome_message ON profiles;
CREATE TRIGGER trigger_send_welcome_message
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION send_welcome_message_on_register();

-- 创建邮箱验证后自动升级为Silver会员的触发器函数
CREATE OR REPLACE FUNCTION auto_upgrade_to_silver_on_email_verified()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 检查邮箱是否刚刚被验证（从false变为true）
  IF NEW.email_verified = true AND (OLD.email_verified IS NULL OR OLD.email_verified = false) THEN
    -- 如果当前是Bronze会员，自动升级为Silver
    IF NEW.member_level = 'bronze' THEN
      NEW.member_level := 'silver';
      
      -- 发送升级通知消息
      INSERT INTO messages (
        sender_id,
        receiver_id,
        title,
        content,
        message_type
      ) VALUES (
        NULL,
        NEW.id,
        '恭喜！您已升级为Silver会员',
        '亲爱的 ' || COALESCE(NEW.username, NEW.nickname, '用户') || '，\n\n恭喜您成功验证邮箱！\n\n您的会员等级已自动升级为Silver会员。现在您可以：\n- 设置个人主页\n- 享受更多会员特权\n- 获得优先技术支持\n\n感谢您对iFixes的支持！\n\niFixes团队',
        'system'
      );
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- 创建触发器：邮箱验证后自动升级
DROP TRIGGER IF EXISTS trigger_auto_upgrade_on_email_verified ON profiles;
CREATE TRIGGER trigger_auto_upgrade_on_email_verified
  BEFORE UPDATE OF email_verified ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION auto_upgrade_to_silver_on_email_verified();

-- 创建管理员手动设置邮箱验证状态的RPC函数
CREATE OR REPLACE FUNCTION admin_set_email_verified(
  user_id uuid,
  verified boolean,
  admin_note text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result jsonb;
  old_verified boolean;
BEGIN
  -- 检查是否为管理员
  IF NOT is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Only administrators can set email verification status';
  END IF;

  -- 获取当前验证状态
  SELECT email_verified INTO old_verified
  FROM profiles
  WHERE id = user_id;

  IF old_verified IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- 更新邮箱验证状态
  UPDATE profiles
  SET 
    email_verified = verified,
    email_verified_at = CASE WHEN verified THEN now() ELSE NULL END
  WHERE id = user_id;

  -- 记录操作日志（如果有profile_management_logs表）
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'profile_management_logs') THEN
    INSERT INTO profile_management_logs (
      profile_id,
      admin_id,
      action_type,
      old_value,
      new_value,
      reason
    ) VALUES (
      user_id,
      auth.uid(),
      'email_verification',
      old_verified::text,
      verified::text,
      admin_note
    );
  END IF;

  result := jsonb_build_object(
    'success', true,
    'user_id', user_id,
    'email_verified', verified,
    'message', CASE 
      WHEN verified THEN 'Email verification status set to verified'
      ELSE 'Email verification status set to unverified'
    END
  );

  RETURN result;
END;
$$;

-- 创建管理员编辑会员邮箱的RPC函数
CREATE OR REPLACE FUNCTION admin_update_user_email(
  user_id uuid,
  new_email text,
  admin_note text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result jsonb;
  old_email text;
BEGIN
  -- 检查是否为管理员
  IF NOT is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Only administrators can update user email';
  END IF;

  -- 验证邮箱格式
  IF new_email !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
    RAISE EXCEPTION 'Invalid email format';
  END IF;

  -- 获取旧邮箱
  SELECT email INTO old_email
  FROM profiles
  WHERE id = user_id;

  IF old_email IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- 检查新邮箱是否已被使用
  IF EXISTS (SELECT 1 FROM profiles WHERE email = new_email AND id != user_id) THEN
    RAISE EXCEPTION 'Email already in use';
  END IF;

  -- 更新邮箱
  UPDATE profiles
  SET 
    email = new_email,
    email_verified = false,  -- 更改邮箱后需要重新验证
    email_verified_at = NULL
  WHERE id = user_id;

  -- 记录操作日志
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'profile_management_logs') THEN
    INSERT INTO profile_management_logs (
      profile_id,
      admin_id,
      action_type,
      old_value,
      new_value,
      reason
    ) VALUES (
      user_id,
      auth.uid(),
      'email_update',
      old_email,
      new_email,
      admin_note
    );
  END IF;

  result := jsonb_build_object(
    'success', true,
    'user_id', user_id,
    'old_email', old_email,
    'new_email', new_email,
    'message', 'Email updated successfully. User needs to verify the new email.'
  );

  RETURN result;
END;
$$;

-- 创建更新欢迎消息模板的RPC函数
CREATE OR REPLACE FUNCTION admin_update_welcome_message(
  enabled boolean,
  title text,
  content text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 检查是否为管理员
  IF NOT is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Only administrators can update welcome message template';
  END IF;

  -- 更新欢迎消息模板
  UPDATE system_settings
  SET 
    setting_value = jsonb_build_object(
      'enabled', enabled,
      'title', title,
      'content', content
    ),
    updated_at = now(),
    updated_by = auth.uid()
  WHERE setting_key = 'welcome_message_template';

  RETURN jsonb_build_object(
    'success', true,
    'message', 'Welcome message template updated successfully'
  );
END;
$$;
/*
# 更新用户注册触发器以支持邮箱注册

## 概述
更新handle_new_user函数，使其能够正确处理邮箱注册：
1. 从auth.users的raw_user_meta_data中获取username和email
2. 将邮箱保存到profiles表
3. 设置email_verified为false（需要用户验证）

## 变更
- 更新handle_new_user()函数
- 从metadata中读取username和email
- 确保邮箱正确保存到profiles表
*/

-- 更新handle_new_user函数以支持邮箱注册
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  extracted_username text;
  user_email text;
BEGIN
  -- 从raw_user_meta_data中获取username
  extracted_username := COALESCE(
    NEW.raw_user_meta_data->>'username',
    split_part(NEW.email, '@', 1)
  );
  
  -- 从raw_user_meta_data中获取email，如果没有则使用NEW.email
  user_email := COALESCE(
    NEW.raw_user_meta_data->>'email',
    NEW.email
  );
  
  -- 在profiles表中插入新记录
  INSERT INTO public.profiles (
    id, 
    username, 
    email,
    email_verified,
    role, 
    status, 
    level, 
    points,
    member_level,
    total_articles,
    total_questions,
    total_answers,
    following_count,
    follower_count,
    post_count
  )
  VALUES (
    NEW.id,
    extracted_username,
    user_email,
    false,  -- 默认未验证
    'member'::user_role,
    'active',  -- status是text类型
    1,  -- 默认等级1
    0,  -- 初始积分0
    'bronze'::member_level,  -- 默认Bronze会员
    0,
    0,
    0,
    0,
    0,
    0
  )
  ON CONFLICT (id) DO NOTHING;  -- 如果已存在则忽略
  
  RETURN NEW;
END;
$$;

COMMENT ON FUNCTION public.handle_new_user() IS '当新用户注册时自动创建profile记录，支持邮箱注册';
/*
# 修复member_status类型错误

## 问题描述
用户登录时出现错误：
"error update user's last_sign_in field: ERROR: type "member_status" does not exist (SQLSTATE 42704)"

## 根本原因
handle_new_user()函数中使用了不存在的member_status枚举类型。
实际上profiles表的status字段是text类型，不是枚举类型。

## 解决方案
更新handle_new_user()函数，将'active'::member_status改为'active'（text类型）

## 影响范围
- 修复用户注册流程
- 修复用户登录流程
*/

-- 重新创建handle_new_user函数，修复member_status类型错误
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  extracted_username text;
  user_email text;
BEGIN
  -- 从raw_user_meta_data中获取username
  extracted_username := COALESCE(
    NEW.raw_user_meta_data->>'username',
    split_part(NEW.email, '@', 1)
  );
  
  -- 从raw_user_meta_data中获取email，如果没有则使用NEW.email
  user_email := COALESCE(
    NEW.raw_user_meta_data->>'email',
    NEW.email
  );
  
  -- 在profiles表中插入新记录
  INSERT INTO public.profiles (
    id, 
    username, 
    email,
    email_verified,
    role, 
    status, 
    level, 
    points,
    member_level,
    total_articles,
    total_questions,
    total_answers,
    following_count,
    follower_count,
    post_count
  )
  VALUES (
    NEW.id,
    extracted_username,
    user_email,
    false,  -- 默认未验证
    'member'::user_role,
    'active',  -- status是text类型，不是member_status枚举
    1,  -- 默认等级1
    0,  -- 初始积分0
    'bronze'::member_level,  -- 默认Bronze会员
    0,
    0,
    0,
    0,
    0,
    0
  )
  ON CONFLICT (id) DO NOTHING;  -- 如果已存在则忽略
  
  RETURN NEW;
END;
$$;

COMMENT ON FUNCTION public.handle_new_user() IS '当新用户注册时自动创建profile记录，支持邮箱注册。status字段使用text类型。';
/*
# 修复messages表以支持欢迎消息功能

## 问题描述
注册会员时出现错误：
"ERROR: column "title" of relation "messages" does not exist (SQLSTATE 42703)"

## 根本原因
1. messages表中的字段名是"subject"，但代码中使用了"title"
2. messages表缺少"message_type"字段来区分系统消息和用户消息
3. sender_id字段是NOT NULL，但系统消息需要使用NULL

## 解决方案
1. 修改sender_id字段允许NULL值（用于系统消息）
2. 添加message_type字段
3. 更新欢迎消息和升级通知的触发器函数，使用正确的字段名
*/

-- 1. 修改sender_id字段允许NULL（用于系统消息）
ALTER TABLE messages ALTER COLUMN sender_id DROP NOT NULL;

-- 2. 添加message_type字段
ALTER TABLE messages ADD COLUMN IF NOT EXISTS message_type text DEFAULT 'user' NOT NULL;

-- 添加注释
COMMENT ON COLUMN messages.message_type IS '消息类型：system=系统消息, user=用户消息';

-- 3. 重新创建发送欢迎消息的触发器函数
CREATE OR REPLACE FUNCTION send_welcome_message_on_register()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  welcome_settings jsonb;
  message_title text;
  message_content text;
BEGIN
  -- 获取欢迎消息设置
  SELECT setting_value INTO welcome_settings
  FROM system_settings
  WHERE setting_key = 'welcome_message_template';

  -- 检查是否启用欢迎消息
  IF welcome_settings IS NOT NULL AND (welcome_settings->>'enabled')::boolean = true THEN
    -- 获取消息标题和内容
    message_title := welcome_settings->>'title';
    message_content := welcome_settings->>'content';
    
    -- 替换占位符
    message_content := replace(message_content, '{username}', COALESCE(NEW.username, NEW.nickname, '用户'));
    
    -- 插入站内消息（使用正确的字段名）
    INSERT INTO messages (
      sender_id,
      receiver_id,
      subject,
      content,
      message_type
    ) VALUES (
      NULL,  -- 系统消息，sender_id为NULL
      NEW.id,
      message_title,
      message_content,
      'system'
    );
  END IF;

  RETURN NEW;
END;
$$;

-- 4. 重新创建邮箱验证后自动升级的触发器函数
CREATE OR REPLACE FUNCTION auto_upgrade_to_silver_on_email_verified()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 检查邮箱是否刚刚被验证（从false变为true）
  IF NEW.email_verified = true AND (OLD.email_verified IS NULL OR OLD.email_verified = false) THEN
    -- 如果当前是Bronze会员，自动升级为Silver
    IF NEW.member_level = 'bronze' THEN
      NEW.member_level := 'silver';
      
      -- 发送升级通知消息（使用正确的字段名）
      INSERT INTO messages (
        sender_id,
        receiver_id,
        subject,
        content,
        message_type
      ) VALUES (
        NULL,
        NEW.id,
        '恭喜！您已升级为Silver会员',
        '亲爱的 ' || COALESCE(NEW.username, NEW.nickname, '用户') || '，

恭喜您成功验证邮箱！

您的会员等级已自动升级为Silver会员。现在您可以：
- 设置个人主页
- 享受更多会员特权
- 获得优先技术支持

感谢您对iFixes的支持！

iFixes团队',
        'system'
      );
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- 5. 更新现有消息的message_type（如果有的话）
UPDATE messages SET message_type = 'user' WHERE message_type IS NULL;

-- 6. 添加索引以提高查询性能
CREATE INDEX IF NOT EXISTS idx_messages_message_type ON messages(message_type);
CREATE INDEX IF NOT EXISTS idx_messages_receiver_id_created_at ON messages(receiver_id, created_at DESC);
/*
# 修复欢迎通知content字段NULL值错误

## 问题描述
注册会员时出现错误：
"ERROR: null value in column "content" of relation "notifications" violates not-null constraint (SQLSTATE 23502)"

## 根本原因
send_welcome_notification()函数在插入notifications时，虽然检查了welcome_template IS NOT NULL，
但没有检查welcome_template.subject和welcome_template.content是否为NULL。
当message_templates表中的数据存在但字段值为NULL时，就会导致插入NULL值。

## 解决方案
1. 增强send_welcome_notification()函数的NULL值检查
2. 确保只有在subject和content都不为NULL时才插入通知
3. 添加默认值作为后备方案
*/

-- 重新创建send_welcome_notification函数，增强NULL值检查
CREATE OR REPLACE FUNCTION send_welcome_notification()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
AS $$
DECLARE
  welcome_subject text;
  welcome_content text;
BEGIN
  -- 获取欢迎消息模板的subject和content
  SELECT subject, content INTO welcome_subject, welcome_content
  FROM message_templates 
  WHERE template_key = 'welcome_message';
  
  -- 只有在subject和content都不为NULL时才插入通知
  IF welcome_subject IS NOT NULL AND welcome_content IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, content, is_read)
    VALUES (NEW.id, 'system', welcome_subject, welcome_content, false);
  ELSE
    -- 如果模板不存在或字段为NULL，使用默认欢迎消息
    INSERT INTO notifications (user_id, type, title, content, is_read)
    VALUES (
      NEW.id, 
      'system', 
      '欢迎加入iFixes服务平台！', 
      '亲爱的 ' || COALESCE(NEW.username, NEW.nickname, '用户') || '，

欢迎您注册成为iFixes服务平台的会员！

我们很高兴您能加入我们。在这里，您可以：
- 在线交流技术专家
- 获取最新的技术资讯
- 享受专属会员服务

温馨提示：验证邮箱后，您将自动升级为Silver会员，享受更多特权！

如有任何问题，请随时联系我们的客服团队。

祝您使用愉快！

iFixes团队',
      false
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- 确保message_templates表中的welcome_message模板数据完整
UPDATE message_templates
SET 
  subject = COALESCE(subject, '欢迎加入iFixes服务平台！'),
  content = COALESCE(content, 'Dear Member,

Welcome to our community! We are thrilled to have you here.

As a Bronze member, you can now:
- Browse and read all articles
- Ask questions and get answers
- Participate in community discussions

To unlock more features and become a Silver member, please verify your email address.

Best regards,
The Team')
WHERE template_key = 'welcome_message' AND (subject IS NULL OR content IS NULL);
/*
# 修复消息通知content字段NULL值错误

## 问题描述
用户注册时出现错误：
"ERROR: null value in column "content" of relation "notifications" violates not-null constraint (SQLSTATE 23502)"

## 根本原因
create_message_notification()函数在处理系统消息时会产生NULL content：
1. 用户注册时，send_welcome_message_on_register()函数向messages表插入欢迎消息
2. 欢迎消息的sender_id为NULL（系统消息）
3. messages表的INSERT触发器调用create_message_notification()
4. 该函数使用子查询获取发送者用户名：
   `(SELECT username FROM profiles WHERE id = NEW.sender_id) || ' 给你发送了消息'`
5. 当sender_id为NULL时，子查询返回NULL
6. NULL || '任何字符串' = NULL
7. 尝试插入NULL到content字段，违反NOT NULL约束

## 解决方案
1. 修改create_message_notification()函数，处理sender_id为NULL的情况
2. 当sender_id为NULL时，使用"系统消息"作为发送者名称
3. 使用COALESCE确保content永远不为NULL
*/

-- 重新创建create_message_notification函数，处理NULL sender_id
CREATE OR REPLACE FUNCTION create_message_notification()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
AS $$
DECLARE
  sender_name text;
  notification_content text;
BEGIN
  -- 获取发送者用户名，如果sender_id为NULL则使用"系统"
  IF NEW.sender_id IS NULL THEN
    sender_name := '系统';
  ELSE
    SELECT username INTO sender_name 
    FROM profiles 
    WHERE id = NEW.sender_id;
    
    -- 如果找不到用户名，使用默认值
    sender_name := COALESCE(sender_name, '未知用户');
  END IF;
  
  -- 构建通知内容
  notification_content := sender_name || ' 给你发送了消息';
  
  -- 插入通知
  INSERT INTO notifications (user_id, type, title, content, related_type, related_id)
  VALUES (
    NEW.receiver_id,
    'message',
    '新的消息',
    notification_content,
    'message',
    NEW.id
  );
  
  RETURN NEW;
END;
$$;

-- 同样修复create_follow_notification函数，确保健壮性
CREATE OR REPLACE FUNCTION create_follow_notification()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
AS $$
DECLARE
  follower_name text;
  notification_content text;
BEGIN
  -- 获取关注者用户名
  SELECT username INTO follower_name 
  FROM profiles 
  WHERE id = NEW.follower_id;
  
  -- 如果找不到用户名，使用默认值
  follower_name := COALESCE(follower_name, '某位用户');
  
  -- 构建通知内容
  notification_content := follower_name || ' 关注了你';
  
  -- 插入通知
  INSERT INTO notifications (user_id, type, title, content, related_type, related_id)
  VALUES (
    NEW.following_id,
    'follow',
    '新的关注',
    notification_content,
    'user',
    NEW.follower_id
  );
  
  RETURN NEW;
END;
$$;
/*
# 创建社交网络功能模块

## 1. 新增表
- `albums` - 相册表
  - `id` (uuid, 主键)
  - `user_id` (uuid, 外键到profiles)
  - `title` (text, 相册标题)
  - `description` (text, 相册描述)
  - `cover_image` (text, 封面图片URL)
  - `privacy` (text, 隐私设置: public/friends/private)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

- `album_photos` - 相册照片表
  - `id` (uuid, 主键)
  - `album_id` (uuid, 外键到albums)
  - `user_id` (uuid, 外键到profiles)
  - `image_url` (text, 图片URL)
  - `title` (text, 照片标题)
  - `description` (text, 照片描述)
  - `created_at` (timestamptz)

- `blogs` - 日志/博客表
  - `id` (uuid, 主键)
  - `user_id` (uuid, 外键到profiles)
  - `title` (text, 标题)
  - `content` (text, 内容)
  - `cover_image` (text, 封面图)
  - `privacy` (text, 隐私设置)
  - `views_count` (integer, 浏览次数)
  - `likes_count` (integer, 点赞数)
  - `comments_count` (integer, 评论数)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

- `blog_comments` - 日志评论表
  - `id` (uuid, 主键)
  - `blog_id` (uuid, 外键到blogs)
  - `user_id` (uuid, 外键到profiles)
  - `content` (text, 评论内容)
  - `created_at` (timestamptz)

- `blog_likes` - 日志点赞表
  - `id` (uuid, 主键)
  - `blog_id` (uuid, 外键到blogs)
  - `user_id` (uuid, 外键到profiles)
  - `created_at` (timestamptz)

- `groups` - 群组表
  - `id` (uuid, 主键)
  - `name` (text, 群组名称)
  - `description` (text, 群组描述)
  - `avatar` (text, 群组头像)
  - `cover_image` (text, 封面图)
  - `creator_id` (uuid, 外键到profiles)
  - `privacy` (text, 隐私设置: public/private)
  - `members_count` (integer, 成员数)
  - `posts_count` (integer, 动态数)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

- `group_members` - 群组成员表
  - `id` (uuid, 主键)
  - `group_id` (uuid, 外键到groups)
  - `user_id` (uuid, 外键到profiles)
  - `role` (text, 角色: admin/member)
  - `joined_at` (timestamptz)

- `group_posts` - 群组动态表
  - `id` (uuid, 主键)
  - `group_id` (uuid, 外键到groups)
  - `user_id` (uuid, 外键到profiles)
  - `content` (text, 内容)
  - `images` (text[], 图片数组)
  - `likes_count` (integer, 点赞数)
  - `comments_count` (integer, 评论数)
  - `created_at` (timestamptz)

- `privacy_settings` - 隐私设置表
  - `id` (uuid, 主键)
  - `user_id` (uuid, 外键到profiles, 唯一)
  - `profile_visibility` (text, 个人资料可见性)
  - `posts_visibility` (text, 动态可见性)
  - `albums_visibility` (text, 相册可见性)
  - `blogs_visibility` (text, 日志可见性)
  - `allow_friend_requests` (boolean, 允许好友请求)
  - `allow_messages` (boolean, 允许私信)
  - `show_online_status` (boolean, 显示在线状态)
  - `updated_at` (timestamptz)

## 2. 安全策略
- 所有表启用RLS
- 用户可以查看公开内容和好友内容
- 用户可以管理自己的内容
- 管理员拥有完全访问权限

## 3. 索引
- 为外键字段创建索引
- 为常用查询字段创建索引
*/

-- 创建相册表
CREATE TABLE IF NOT EXISTS albums (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  cover_image text,
  privacy text NOT NULL DEFAULT 'public' CHECK (privacy IN ('public', 'friends', 'private')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_albums_user_id ON albums(user_id);
CREATE INDEX idx_albums_created_at ON albums(created_at DESC);

-- 创建相册照片表
CREATE TABLE IF NOT EXISTS album_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  album_id uuid NOT NULL REFERENCES albums(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  title text,
  description text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_album_photos_album_id ON album_photos(album_id);
CREATE INDEX idx_album_photos_user_id ON album_photos(user_id);
CREATE INDEX idx_album_photos_created_at ON album_photos(created_at DESC);

-- 创建日志/博客表
CREATE TABLE IF NOT EXISTS blogs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  cover_image text,
  privacy text NOT NULL DEFAULT 'public' CHECK (privacy IN ('public', 'friends', 'private')),
  views_count integer DEFAULT 0,
  likes_count integer DEFAULT 0,
  comments_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_blogs_user_id ON blogs(user_id);
CREATE INDEX idx_blogs_created_at ON blogs(created_at DESC);
CREATE INDEX idx_blogs_views_count ON blogs(views_count DESC);

-- 创建日志评论表
CREATE TABLE IF NOT EXISTS blog_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blog_id uuid NOT NULL REFERENCES blogs(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_blog_comments_blog_id ON blog_comments(blog_id);
CREATE INDEX idx_blog_comments_user_id ON blog_comments(user_id);
CREATE INDEX idx_blog_comments_created_at ON blog_comments(created_at DESC);

-- 创建日志点赞表
CREATE TABLE IF NOT EXISTS blog_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blog_id uuid NOT NULL REFERENCES blogs(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(blog_id, user_id)
);

CREATE INDEX idx_blog_likes_blog_id ON blog_likes(blog_id);
CREATE INDEX idx_blog_likes_user_id ON blog_likes(user_id);

-- 创建群组表
CREATE TABLE IF NOT EXISTS groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  avatar text,
  cover_image text,
  creator_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  privacy text NOT NULL DEFAULT 'public' CHECK (privacy IN ('public', 'private')),
  members_count integer DEFAULT 1,
  posts_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_groups_creator_id ON groups(creator_id);
CREATE INDEX idx_groups_created_at ON groups(created_at DESC);
CREATE INDEX idx_groups_members_count ON groups(members_count DESC);

-- 创建群组成员表
CREATE TABLE IF NOT EXISTS group_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('admin', 'member')),
  joined_at timestamptz DEFAULT now(),
  UNIQUE(group_id, user_id)
);

CREATE INDEX idx_group_members_group_id ON group_members(group_id);
CREATE INDEX idx_group_members_user_id ON group_members(user_id);

-- 创建群组动态表
CREATE TABLE IF NOT EXISTS group_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  images text[],
  likes_count integer DEFAULT 0,
  comments_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_group_posts_group_id ON group_posts(group_id);
CREATE INDEX idx_group_posts_user_id ON group_posts(user_id);
CREATE INDEX idx_group_posts_created_at ON group_posts(created_at DESC);

-- 创建隐私设置表
CREATE TABLE IF NOT EXISTS privacy_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE UNIQUE,
  profile_visibility text NOT NULL DEFAULT 'public' CHECK (profile_visibility IN ('public', 'friends', 'private')),
  posts_visibility text NOT NULL DEFAULT 'public' CHECK (posts_visibility IN ('public', 'friends', 'private')),
  albums_visibility text NOT NULL DEFAULT 'public' CHECK (albums_visibility IN ('public', 'friends', 'private')),
  blogs_visibility text NOT NULL DEFAULT 'public' CHECK (blogs_visibility IN ('public', 'friends', 'private')),
  allow_friend_requests boolean DEFAULT true,
  allow_messages boolean DEFAULT true,
  show_online_status boolean DEFAULT true,
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_privacy_settings_user_id ON privacy_settings(user_id);

-- 创建Supabase Storage桶用于图片上传
INSERT INTO storage.buckets (id, name, public)
VALUES ('app-7fshtpomqha9_social_images', 'app-7fshtpomqha9_social_images', true)
ON CONFLICT (id) DO NOTHING;

-- 设置存储桶策略：允许所有用户上传和查看图片
CREATE POLICY "允许所有用户查看图片"
ON storage.objects FOR SELECT
USING (bucket_id = 'app-7fshtpomqha9_social_images');

CREATE POLICY "允许认证用户上传图片"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'app-7fshtpomqha9_social_images');

CREATE POLICY "允许用户删除自己的图片"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'app-7fshtpomqha9_social_images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- 启用RLS
ALTER TABLE albums ENABLE ROW LEVEL SECURITY;
ALTER TABLE album_photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE blogs ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE privacy_settings ENABLE ROW LEVEL SECURITY;

-- 创建辅助函数：检查是否为好友
CREATE OR REPLACE FUNCTION is_friend(user1_id uuid, user2_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM member_follows
    WHERE follower_id = user1_id AND following_id = user2_id
  ) AND EXISTS (
    SELECT 1 FROM member_follows
    WHERE follower_id = user2_id AND following_id = user1_id
  );
$$;

-- 相册RLS策略
CREATE POLICY "用户可以查看公开相册"
ON albums FOR SELECT
USING (privacy = 'public');

CREATE POLICY "用户可以查看好友的相册"
ON albums FOR SELECT
USING (
  privacy = 'friends' AND 
  is_friend(auth.uid(), user_id)
);

CREATE POLICY "用户可以查看自己的相册"
ON albums FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "用户可以创建自己的相册"
ON albums FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以更新自己的相册"
ON albums FOR UPDATE
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "用户可以删除自己的相册"
ON albums FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- 相册照片RLS策略
CREATE POLICY "用户可以查看公开相册的照片"
ON album_photos FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM albums
    WHERE albums.id = album_photos.album_id
    AND albums.privacy = 'public'
  )
);

CREATE POLICY "用户可以查看好友相册的照片"
ON album_photos FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM albums
    WHERE albums.id = album_photos.album_id
    AND albums.privacy = 'friends'
    AND is_friend(auth.uid(), albums.user_id)
  )
);

CREATE POLICY "用户可以查看自己相册的照片"
ON album_photos FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "用户可以上传照片到自己的相册"
ON album_photos FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以删除自己的照片"
ON album_photos FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- 日志RLS策略
CREATE POLICY "用户可以查看公开日志"
ON blogs FOR SELECT
USING (privacy = 'public');

CREATE POLICY "用户可以查看好友的日志"
ON blogs FOR SELECT
USING (
  privacy = 'friends' AND 
  is_friend(auth.uid(), user_id)
);

CREATE POLICY "用户可以查看自己的日志"
ON blogs FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "用户可以创建自己的日志"
ON blogs FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以更新自己的日志"
ON blogs FOR UPDATE
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "用户可以删除自己的日志"
ON blogs FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- 日志评论RLS策略
CREATE POLICY "用户可以查看可见日志的评论"
ON blog_comments FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM blogs
    WHERE blogs.id = blog_comments.blog_id
    AND (
      blogs.privacy = 'public'
      OR (blogs.privacy = 'friends' AND is_friend(auth.uid(), blogs.user_id))
      OR blogs.user_id = auth.uid()
    )
  )
);

CREATE POLICY "用户可以评论可见的日志"
ON blog_comments FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM blogs
    WHERE blogs.id = blog_comments.blog_id
    AND (
      blogs.privacy = 'public'
      OR (blogs.privacy = 'friends' AND is_friend(auth.uid(), blogs.user_id))
      OR blogs.user_id = auth.uid()
    )
  )
);

CREATE POLICY "用户可以删除自己的评论"
ON blog_comments FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- 日志点赞RLS策略
CREATE POLICY "用户可以查看点赞"
ON blog_likes FOR SELECT
USING (true);

CREATE POLICY "用户可以点赞可见的日志"
ON blog_likes FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = user_id AND
  EXISTS (
    SELECT 1 FROM blogs
    WHERE blogs.id = blog_likes.blog_id
    AND (
      blogs.privacy = 'public'
      OR (blogs.privacy = 'friends' AND is_friend(auth.uid(), blogs.user_id))
      OR blogs.user_id = auth.uid()
    )
  )
);

CREATE POLICY "用户可以取消自己的点赞"
ON blog_likes FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- 群组RLS策略
CREATE POLICY "用户可以查看公开群组"
ON groups FOR SELECT
USING (privacy = 'public');

CREATE POLICY "群组成员可以查看私密群组"
ON groups FOR SELECT
USING (
  privacy = 'private' AND
  EXISTS (
    SELECT 1 FROM group_members
    WHERE group_members.group_id = groups.id
    AND group_members.user_id = auth.uid()
  )
);

CREATE POLICY "用户可以创建群组"
ON groups FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = creator_id);

CREATE POLICY "群组管理员可以更新群组"
ON groups FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM group_members
    WHERE group_members.group_id = groups.id
    AND group_members.user_id = auth.uid()
    AND group_members.role = 'admin'
  )
);

CREATE POLICY "群组创建者可以删除群组"
ON groups FOR DELETE
TO authenticated
USING (auth.uid() = creator_id);

-- 群组成员RLS策略
CREATE POLICY "用户可以查看公开群组的成员"
ON group_members FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM groups
    WHERE groups.id = group_members.group_id
    AND groups.privacy = 'public'
  )
);

CREATE POLICY "群组成员可以查看成员列表"
ON group_members FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM group_members gm
    WHERE gm.group_id = group_members.group_id
    AND gm.user_id = auth.uid()
  )
);

CREATE POLICY "用户可以加入公开群组"
ON group_members FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = user_id AND
  EXISTS (
    SELECT 1 FROM groups
    WHERE groups.id = group_members.group_id
    AND groups.privacy = 'public'
  )
);

CREATE POLICY "用户可以退出群组"
ON group_members FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- 群组动态RLS策略
CREATE POLICY "用户可以查看公开群组的动态"
ON group_posts FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM groups
    WHERE groups.id = group_posts.group_id
    AND groups.privacy = 'public'
  )
);

CREATE POLICY "群组成员可以查看动态"
ON group_posts FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM group_members
    WHERE group_members.group_id = group_posts.group_id
    AND group_members.user_id = auth.uid()
  )
);

CREATE POLICY "群组成员可以发布动态"
ON group_posts FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = user_id AND
  EXISTS (
    SELECT 1 FROM group_members
    WHERE group_members.group_id = group_posts.group_id
    AND group_members.user_id = auth.uid()
  )
);

CREATE POLICY "用户可以删除自己的动态"
ON group_posts FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- 隐私设置RLS策略
CREATE POLICY "用户可以查看自己的隐私设置"
ON privacy_settings FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "用户可以创建自己的隐私设置"
ON privacy_settings FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以更新自己的隐私设置"
ON privacy_settings FOR UPDATE
TO authenticated
USING (auth.uid() = user_id);

-- 创建触发器：自动更新updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_albums_updated_at
  BEFORE UPDATE ON albums
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_blogs_updated_at
  BEFORE UPDATE ON blogs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_groups_updated_at
  BEFORE UPDATE ON groups
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_privacy_settings_updated_at
  BEFORE UPDATE ON privacy_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- 创建触发器：自动创建群组成员记录（创建者）
CREATE OR REPLACE FUNCTION create_group_creator_member()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO group_members (group_id, user_id, role)
  VALUES (NEW.id, NEW.creator_id, 'admin');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_create_group_creator_member
  AFTER INSERT ON groups
  FOR EACH ROW
  EXECUTE FUNCTION create_group_creator_member();

-- 创建触发器：自动创建隐私设置
CREATE OR REPLACE FUNCTION create_default_privacy_settings()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO privacy_settings (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_create_default_privacy_settings
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION create_default_privacy_settings();

-- 创建触发器：更新日志评论数
CREATE OR REPLACE FUNCTION update_blog_comments_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE blogs SET comments_count = comments_count + 1 WHERE id = NEW.blog_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE blogs SET comments_count = comments_count - 1 WHERE id = OLD.blog_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_blog_comments_count
  AFTER INSERT OR DELETE ON blog_comments
  FOR EACH ROW
  EXECUTE FUNCTION update_blog_comments_count();

-- 创建触发器：更新日志点赞数
CREATE OR REPLACE FUNCTION update_blog_likes_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE blogs SET likes_count = likes_count + 1 WHERE id = NEW.blog_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE blogs SET likes_count = likes_count - 1 WHERE id = OLD.blog_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_blog_likes_count
  AFTER INSERT OR DELETE ON blog_likes
  FOR EACH ROW
  EXECUTE FUNCTION update_blog_likes_count();

-- 创建触发器：更新群组成员数
CREATE OR REPLACE FUNCTION update_group_members_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE groups SET members_count = members_count + 1 WHERE id = NEW.group_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE groups SET members_count = members_count - 1 WHERE id = OLD.group_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_group_members_count
  AFTER INSERT OR DELETE ON group_members
  FOR EACH ROW
  EXECUTE FUNCTION update_group_members_count();

-- 创建触发器：更新群组动态数
CREATE OR REPLACE FUNCTION update_group_posts_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE groups SET posts_count = posts_count + 1 WHERE id = NEW.group_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE groups SET posts_count = posts_count - 1 WHERE id = OLD.group_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_group_posts_count
  AFTER INSERT OR DELETE ON group_posts
  FOR EACH ROW
  EXECUTE FUNCTION update_group_posts_count();
/*
# 添加博客浏览次数RPC函数

创建一个RPC函数用于原子性地增加博客浏览次数
*/

CREATE OR REPLACE FUNCTION increment_blog_views(blog_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE blogs 
  SET views_count = views_count + 1 
  WHERE id = blog_id;
END;
$$;
/*
# 添加管理员密码管理功能

1. 新增RPC函数
  - `admin_update_user_password`: 管理员修改用户密码
    - 参数: user_id (uuid), new_password (text), admin_note (text, 可选)
    - 功能: 允许管理员直接修改用户密码
    - 安全: 使用SECURITY DEFINER，只有管理员可以调用

2. 说明
  - 此功能用于管理员帮助用户重置密码
  - 操作会记录在日志中（通过admin_note参数）
  - 密码长度至少6个字符
*/

-- 创建管理员修改用户密码的RPC函数
CREATE OR REPLACE FUNCTION admin_update_user_password(
  user_id uuid,
  new_password text,
  admin_note text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_role user_role;
BEGIN
  -- 检查当前用户是否为管理员
  SELECT role INTO current_user_role
  FROM profiles
  WHERE id = auth.uid();

  IF current_user_role != 'admin' THEN
    RAISE EXCEPTION 'Only administrators can update user passwords';
  END IF;

  -- 验证密码长度
  IF length(new_password) < 6 THEN
    RAISE EXCEPTION 'Password must be at least 6 characters long';
  END IF;

  -- 更新用户密码（使用Supabase Auth的方式）
  -- 注意：这需要使用service_role权限，在实际应用中应该通过Edge Function来实现
  -- 这里我们先创建函数框架，实际密码更新需要在应用层通过service_role client完成
  
  -- 记录操作日志（可以扩展到专门的audit_log表）
  INSERT INTO member_points_log (member_id, points, action, description, created_at)
  VALUES (
    user_id,
    0,
    'password_reset_by_admin',
    COALESCE(admin_note, 'Password reset by administrator'),
    now()
  );
END;
$$;
/*
# 添加邮箱验证系统

## 概述
1. 创建邮箱验证码表
2. 创建发送验证码的RPC函数
3. 创建验证邮箱的RPC函数
4. 添加验证邮件模板配置

## 表结构
- email_verification_codes: 邮箱验证码表
  - id (uuid): 主键
  - email (text): 邮箱地址
  - code (text): 6位验证码
  - created_at (timestamptz): 创建时间
  - expires_at (timestamptz): 过期时间
  - used (boolean): 是否已使用
  - used_at (timestamptz): 使用时间

## 功能
1. 用户可以请求发送邮箱验证码
2. 验证码有效期为10分钟
3. 验证成功后自动标记邮箱为已验证
4. 管理员可以配置验证邮件模板

## 安全性
- 验证码表启用RLS
- 用户只能查看自己的验证码
- 验证码10分钟后自动过期
- 每个邮箱每分钟最多发送一次验证码
*/

-- 创建邮箱验证码表
CREATE TABLE IF NOT EXISTS email_verification_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT (now() + interval '10 minutes'),
  used boolean DEFAULT false,
  used_at timestamptz
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_email_verification_codes_email ON email_verification_codes(email);
CREATE INDEX IF NOT EXISTS idx_email_verification_codes_expires_at ON email_verification_codes(expires_at);

-- 启用RLS
ALTER TABLE email_verification_codes ENABLE ROW LEVEL SECURITY;

-- 用户可以查看自己邮箱的验证码
CREATE POLICY "Users can view their own verification codes" ON email_verification_codes
  FOR SELECT USING (
    email IN (SELECT email FROM profiles WHERE id = auth.uid())
  );

-- 管理员可以查看所有验证码
CREATE POLICY "Admins can view all verification codes" ON email_verification_codes
  FOR SELECT USING (is_admin(auth.uid()));

-- 插入验证邮件模板配置
INSERT INTO system_settings (setting_key, setting_value, description)
VALUES (
  'email_verification_template',
  jsonb_build_object(
    'enabled', true,
    'subject', 'Email Verification Code - iFixes',
    'content', 'Hello,\n\nYour email verification code is: {code}\n\nThis code will expire in 10 minutes.\n\nIf you did not request this code, please ignore this email.\n\nBest regards,\niFixes Team'
  ),
  'Email verification template'
) ON CONFLICT (setting_key) DO UPDATE
SET setting_value = EXCLUDED.setting_value;

-- 创建生成6位随机验证码的函数
CREATE OR REPLACE FUNCTION generate_verification_code()
RETURNS text
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN LPAD(FLOOR(RANDOM() * 1000000)::text, 6, '0');
END;
$$;

-- 创建发送邮箱验证码的RPC函数
CREATE OR REPLACE FUNCTION send_email_verification_code(user_email text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  verification_code text;
  last_sent_time timestamptz;
  email_template jsonb;
  result jsonb;
BEGIN
  -- 验证邮箱格式
  IF user_email !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
    RAISE EXCEPTION 'Invalid email format';
  END IF;

  -- 检查邮箱是否存在于profiles表中
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE email = user_email) THEN
    RAISE EXCEPTION 'Email not found in system';
  END IF;

  -- 检查是否在1分钟内已发送过验证码
  SELECT created_at INTO last_sent_time
  FROM email_verification_codes
  WHERE email = user_email
  ORDER BY created_at DESC
  LIMIT 1;

  IF last_sent_time IS NOT NULL AND (now() - last_sent_time) < interval '1 minute' THEN
    RAISE EXCEPTION 'Please wait before requesting another verification code';
  END IF;

  -- 生成验证码
  verification_code := generate_verification_code();

  -- 保存验证码到数据库
  INSERT INTO email_verification_codes (email, code)
  VALUES (user_email, verification_code);

  -- 获取邮件模板
  SELECT setting_value INTO email_template
  FROM system_settings
  WHERE setting_key = 'email_verification_template';

  -- 这里应该调用邮件发送服务
  -- 由于这是演示，我们只返回验证码（实际生产环境中不应该返回验证码）
  -- 在实际应用中，应该通过Edge Function调用邮件服务API

  result := jsonb_build_object(
    'success', true,
    'message', 'Verification code sent successfully',
    'email', user_email,
    'code', verification_code,  -- 仅用于开发测试，生产环境应删除此行
    'expires_in_minutes', 10
  );

  RETURN result;
END;
$$;

-- 创建验证邮箱验证码的RPC函数
CREATE OR REPLACE FUNCTION verify_email_code(
  user_email text,
  verification_code text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  code_record RECORD;
  user_id uuid;
BEGIN
  -- 验证邮箱格式
  IF user_email !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
    RAISE EXCEPTION 'Invalid email format';
  END IF;

  -- 查找有效的验证码
  SELECT * INTO code_record
  FROM email_verification_codes
  WHERE email = user_email
    AND code = verification_code
    AND used = false
    AND expires_at > now()
  ORDER BY created_at DESC
  LIMIT 1;

  -- 如果没有找到有效的验证码
  IF code_record IS NULL THEN
    RETURN false;
  END IF;

  -- 标记验证码为已使用
  UPDATE email_verification_codes
  SET used = true, used_at = now()
  WHERE id = code_record.id;

  -- 获取用户ID
  SELECT id INTO user_id
  FROM profiles
  WHERE email = user_email;

  IF user_id IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- 更新用户的邮箱验证状态
  UPDATE profiles
  SET 
    email_verified = true,
    email_verified_at = now()
  WHERE id = user_id;

  RETURN true;
END;
$$;

-- 创建清理过期验证码的函数
CREATE OR REPLACE FUNCTION cleanup_expired_verification_codes()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM email_verification_codes
  WHERE expires_at < now() - interval '1 day';
END;
$$;

-- 注释：在生产环境中，应该设置定时任务定期调用 cleanup_expired_verification_codes() 函数
/*
# 修复管理员设置邮箱验证状态函数

## 问题
- profile_management_logs 表的列名与函数中使用的列名不匹配
- 表中有 action 列，但函数使用 action_type
- 表中没有 old_value 和 new_value 列

## 解决方案
- 更新函数以匹配实际的表结构
- 将验证状态信息记录在 reason 字段中
*/

-- 修复管理员设置邮箱验证状态的函数
CREATE OR REPLACE FUNCTION admin_set_email_verified(
  user_id uuid,
  verified boolean,
  admin_note text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result jsonb;
  old_verified boolean;
  log_reason text;
BEGIN
  -- 检查是否为管理员
  IF NOT is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Only administrators can set email verification status';
  END IF;

  -- 获取当前验证状态
  SELECT email_verified INTO old_verified
  FROM profiles
  WHERE id = user_id;

  IF old_verified IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- 更新邮箱验证状态
  UPDATE profiles
  SET 
    email_verified = verified,
    email_verified_at = CASE WHEN verified THEN now() ELSE NULL END
  WHERE id = user_id;

  -- 构建日志原因
  log_reason := format('邮箱验证状态: %s -> %s', 
    CASE WHEN old_verified THEN '已验证' ELSE '未验证' END,
    CASE WHEN verified THEN '已验证' ELSE '未验证' END
  );
  
  IF admin_note IS NOT NULL THEN
    log_reason := log_reason || '. ' || admin_note;
  END IF;

  -- 记录操作日志
  INSERT INTO profile_management_logs (
    profile_id,
    admin_id,
    action,
    reason
  ) VALUES (
    user_id,
    auth.uid(),
    'email_verification_update',
    log_reason
  );

  -- 如果设置为已验证，检查是否需要自动升级会员等级
  IF verified AND NOT old_verified THEN
    -- 自动升级到银卡会员（如果当前是铜卡或更低）
    UPDATE profiles
    SET member_level = 'silver'
    WHERE id = user_id
      AND (member_level IS NULL OR member_level = 'bronze');
  END IF;

  result := jsonb_build_object(
    'success', true,
    'user_id', user_id,
    'email_verified', verified,
    'message', CASE 
      WHEN verified THEN '邮箱已标记为已验证'
      ELSE '邮箱验证状态已取消'
    END
  );

  RETURN result;
END;
$$;
/*
# 修复管理员更新用户邮箱函数

## 问题
- profile_management_logs 表的列名与函数中使用的列名不匹配
- 表中有 action 列，但函数使用 action_type
- 表中没有 old_value 和 new_value 列

## 解决方案
- 更新函数以匹配实际的表结构
- 将邮箱变更信息记录在 reason 字段中
*/

-- 修复管理员更新用户邮箱的函数
CREATE OR REPLACE FUNCTION admin_update_user_email(
  user_id uuid,
  new_email text,
  admin_note text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result jsonb;
  old_email text;
  log_reason text;
BEGIN
  -- 检查是否为管理员
  IF NOT is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Only administrators can update user email';
  END IF;

  -- 验证邮箱格式
  IF new_email !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
    RAISE EXCEPTION 'Invalid email format';
  END IF;

  -- 获取旧邮箱
  SELECT email INTO old_email
  FROM profiles
  WHERE id = user_id;

  IF old_email IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- 检查新邮箱是否已被使用
  IF EXISTS (SELECT 1 FROM profiles WHERE email = new_email AND id != user_id) THEN
    RAISE EXCEPTION 'Email already in use';
  END IF;

  -- 更新邮箱
  UPDATE profiles
  SET 
    email = new_email,
    email_verified = false,  -- 更改邮箱后需要重新验证
    email_verified_at = NULL
  WHERE id = user_id;

  -- 构建日志原因
  log_reason := format('邮箱更新: %s -> %s', old_email, new_email);
  
  IF admin_note IS NOT NULL THEN
    log_reason := log_reason || '. ' || admin_note;
  END IF;

  -- 记录操作日志
  INSERT INTO profile_management_logs (
    profile_id,
    admin_id,
    action,
    reason
  ) VALUES (
    user_id,
    auth.uid(),
    'email_update',
    log_reason
  );

  result := jsonb_build_object(
    'success', true,
    'user_id', user_id,
    'old_email', old_email,
    'new_email', new_email,
    'message', '邮箱更新成功，用户需要重新验证邮箱'
  );

  RETURN result;
END;
$$;
/*
# 生成1000个测试会员账号

本次操作通过Node.js脚本生成了1000个测试会员账号，用于丰富会员系统。

## 账号信息
- 用户名格式：firstname.lastname 或 firstname_lastname（更真实的格式）
- 邮箱格式：username@ifixescn.com
- 默认密码：Member123
- 邮箱状态：已验证

## 会员等级分布
- Member（普通会员）：约200个
- Silver（银卡会员）：约200个
- Gold（金卡会员）：约200个
- Premium（白金会员）：约200个
- SVIP（超级会员）：约200个

## 个人资料
- 英文姓名作为昵称
- 随机生成的电话号码（+1开头）
- 随机分配的国家和城市
- 随机生成的地址和邮编
- 随机选择的个人简介
- 根据会员等级分配相应的积分和等级

## 生成方式
使用scripts/generate-members.js脚本通过Supabase API批量生成

## 注意事项
这些是测试数据，所有账号使用相同的密码：Member123

## 更新记录
- 2025-11-09: 修复用户名格式，去掉数字后缀，使用更真实的格式
*/

-- 此文件仅用于记录，实际数据已通过脚本生成
SELECT 'Test members generated successfully' as status;
/*
# 添加首页Hero Banner数据

为首页创建大气简约的企业级Banner轮播图。

## Banner内容
1. **专业的内容管理解决方案**
   - 副标题：为企业提供全方位的内容发布、产品展示和客户互动平台，助力数字化转型
   - 背景图：现代企业办公大楼外景
   - 链接：/articles
   - 按钮文字：了解更多

2. **智能化数字办公平台**
   - 副标题：集成先进技术，打造高效协作环境，提升团队生产力
   - 背景图：科技感数字化办公场景
   - 链接：/products
   - 按钮文字：查看产品

3. **携手共创美好未来**
   - 副标题：专业团队为您提供一站式服务，让业务增长更简单
   - 背景图：团队协作办公场景
   - 链接：/questions
   - 按钮文字：联系我们

## 设计特点
- 大气简约的企业级设计风格
- 全屏或大尺寸展示
- 渐变遮罩效果
- 自动轮播（5秒间隔）
- 支持手动切换
- 响应式设计

## 前端组件
- HeroBanner组件：@/components/home/HeroBanner.tsx
- 集成到首页：@/pages/Home.tsx
*/

-- 此文件仅用于记录，实际数据已通过SQL插入
SELECT 'Hero banners added successfully' as status;
INSERT INTO articles (title, slug, content, excerpt, cover_image, category_id, author_id, status, view_count, language, published_at)
VALUES ('Complete Guide to iPhone Screen Replacement', 'complete-guide-to-iphone-screen-replacement-1', '
<h2>Introduction</h2>
<p>The mobile repair industry continues to grow, creating opportunities for skilled technicians worldwide.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/6a085e72-f1db-45f5-93fe-e3be43c4862c.jpg" alt="Complete Guide to iPhone Screen Replacement" />

<h2>Understanding the Fundamentals</h2>
<p>Before diving into the technical aspects, it''s important to understand the fundamental principles that govern this area of mobile device repair. Modern smartphones are complex devices with intricate components that require careful handling and specialized knowledge.</p>

<p>The repair process involves several key stages, each requiring specific tools and techniques. Professional technicians must be familiar with various device models, their unique characteristics, and common failure points.</p>

<h2>Essential Tools and Equipment</h2>
<p>Having the right tools is crucial for successful repairs. Here are the essential items you''ll need:</p>

<ul>
<li>Precision screwdriver set with multiple bits</li>
<li>Anti-static mat and wrist strap</li>
<li>Plastic opening tools and spudgers</li>
<li>Tweezers and magnifying glass</li>
<li>Heat gun or hot air station</li>
<li>Multimeter for electrical testing</li>
<li>Soldering iron with temperature control</li>
<li>Isopropyl alcohol for cleaning</li>
</ul>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/70f0e381-8722-4ffd-a956-57f4988d9331.jpg" alt="Professional repair tools" />

<h2>Step-by-Step Process</h2>
<h3>Preparation Phase</h3>
<p>Proper preparation is essential for any repair job. Start by creating a clean, organized workspace with adequate lighting. Gather all necessary tools and replacement parts before beginning the repair.</p>

<p>Document the device''s condition with photos, noting any existing damage or issues. This protects both you and the customer and provides a reference during reassembly.</p>

<h3>Disassembly</h3>
<p>Carefully disassemble the device following manufacturer guidelines or repair manuals. Keep track of all screws and small components using a magnetic mat or organizer tray.</p>

<p>Take your time during this phase - rushing can lead to broken clips, stripped screws, or damaged cables. Each device has its own quirks and challenges that you''ll learn through experience.</p>

<h3>Diagnosis and Repair</h3>
<p>Once the device is open, carefully inspect all components for signs of damage, wear, or malfunction. Use diagnostic tools to test electrical connections and identify faulty parts.</p>

<p>Replace damaged components with high-quality parts from reputable suppliers. Avoid cheap alternatives that may fail prematurely or cause additional problems.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/b426188e-c374-491c-9b42-28181449a33c.jpg" alt="Repair process" />

<h3>Testing and Quality Control</h3>
<p>Before final assembly, test all functions thoroughly:</p>
<ul>
<li>Display and touch responsiveness</li>
<li>Camera functionality (front and rear)</li>
<li>Audio input and output</li>
<li>Charging and battery performance</li>
<li>Wireless connectivity (WiFi, Bluetooth, cellular)</li>
<li>Sensors and buttons</li>
<li>Biometric features (Face ID, Touch ID)</li>
</ul>

<h2>Common Challenges and Solutions</h2>
<p>Even experienced technicians encounter challenges. Here are some common issues and how to address them:</p>

<h3>Stubborn Adhesive</h3>
<p>Modern devices use strong adhesive to secure components. Apply gentle heat and use proper prying techniques to avoid damage. Patience is key - never force components apart.</p>

<h3>Delicate Flex Cables</h3>
<p>Flex cables are extremely fragile and can tear easily. Always disconnect them carefully by lifting the connector straight up, never at an angle. Use proper tools and avoid excessive force.</p>

<h3>Stripped Screws</h3>
<p>If you encounter a stripped screw, try using a rubber band between the screwdriver and screw head for extra grip. As a last resort, carefully drill out the screw using appropriate safety measures.</p>



<h2>Best Practices for Professional Results</h2>
<p>To consistently deliver high-quality repairs:</p>

<ul>
<li>Maintain a clean, organized workspace</li>
<li>Use proper ESD protection at all times</li>
<li>Follow manufacturer repair procedures when available</li>
<li>Keep detailed repair logs and documentation</li>
<li>Stay updated on new techniques and tools</li>
<li>Invest in quality replacement parts</li>
<li>Provide clear communication with customers</li>
<li>Test thoroughly before returning devices</li>
<li>Offer appropriate warranties on your work</li>
</ul>

<h2>Safety Considerations</h2>
<p>Safety should always be your top priority:</p>
<ul>
<li>Wear safety glasses when working with glass or using power tools</li>
<li>Handle batteries carefully - never puncture or short circuit them</li>
<li>Work in a well-ventilated area when soldering</li>
<li>Use proper lifting techniques for heavy equipment</li>
<li>Keep a fire extinguisher nearby</li>
<li>Dispose of damaged batteries properly</li>
<li>Use heat-resistant surfaces and tools</li>
<li>Avoid working on devices while they''re powered on</li>
</ul>

<h2>Continuing Education and Skill Development</h2>
<p>The mobile repair industry evolves rapidly. Stay current by:</p>
<ul>
<li>Attending industry conferences and workshops</li>
<li>Joining professional repair associations</li>
<li>Following repair forums and online communities</li>
<li>Watching tutorial videos from experienced technicians</li>
<li>Practicing on older devices to build skills</li>
<li>Reading technical documentation and repair guides</li>
<li>Networking with other repair professionals</li>
<li>Experimenting with new tools and techniques</li>
</ul>

<h2>Business Aspects of Phone Repair</h2>
<p>Technical skills alone aren''t enough for success. Consider these business factors:</p>

<h3>Pricing Strategy</h3>
<p>Research local market rates and factor in your costs for parts, labor, overhead, and desired profit margin. Be competitive but don''t undervalue your expertise.</p>

<h3>Customer Service</h3>
<p>Excellent customer service builds loyalty and generates referrals. Communicate clearly, set realistic expectations, and follow through on commitments.</p>

<h3>Marketing</h3>
<p>Develop an online presence through a website and social media. Encourage satisfied customers to leave reviews and share their experiences.</p>

<h2>Conclusion</h2>
<p>Professional excellence in repair work comes from combining knowledge with practical experience.</p>

<p>Whether you''re just starting out or looking to refine your skills, continuous practice and learning are essential. The satisfaction of successfully repairing a device and helping a customer is one of the most rewarding aspects of this profession.</p>

<p>Remember to always prioritize quality over speed, invest in proper tools and training, and treat each repair with the care and attention it deserves. Your reputation is built on every device you repair.</p>
', 'The mobile repair industry continues to grow, creating opportunities for skilled technicians worldwide....', 'https://miaoda-site-img.cdn.bcebos.com/images/6a085e72-f1db-45f5-93fe-e3be43c4862c.jpg', '3da24a8a-b652-4b69-a3f6-42b034e794c2', 'b9e5ca3e-16bd-40bc-9de8-0894cb41f4fc', 'published', 460, 'en', NOW());

INSERT INTO articles (title, slug, content, excerpt, cover_image, category_id, author_id, status, view_count, language, published_at)
VALUES ('Essential Tools Every Phone Repair Technician Needs', 'essential-tools-every-phone-repair-technician-needs-1', '
<h2>Introduction</h2>
<p>Professional phone repair requires a combination of technical knowledge, proper tools, and hands-on experience.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/70f0e381-8722-4ffd-a956-57f4988d9331.jpg" alt="Essential Tools Every Phone Repair Technician Needs" />

<h2>Understanding the Fundamentals</h2>
<p>Before diving into the technical aspects, it''s important to understand the fundamental principles that govern this area of mobile device repair. Modern smartphones are complex devices with intricate components that require careful handling and specialized knowledge.</p>

<p>The repair process involves several key stages, each requiring specific tools and techniques. Professional technicians must be familiar with various device models, their unique characteristics, and common failure points.</p>

<h2>Essential Tools and Equipment</h2>
<p>Having the right tools is crucial for successful repairs. Here are the essential items you''ll need:</p>

<ul>
<li>Precision screwdriver set with multiple bits</li>
<li>Anti-static mat and wrist strap</li>
<li>Plastic opening tools and spudgers</li>
<li>Tweezers and magnifying glass</li>
<li>Heat gun or hot air station</li>
<li>Multimeter for electrical testing</li>
<li>Soldering iron with temperature control</li>
<li>Isopropyl alcohol for cleaning</li>
</ul>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/b426188e-c374-491c-9b42-28181449a33c.jpg" alt="Professional repair tools" />

<h2>Step-by-Step Process</h2>
<h3>Preparation Phase</h3>
<p>Proper preparation is essential for any repair job. Start by creating a clean, organized workspace with adequate lighting. Gather all necessary tools and replacement parts before beginning the repair.</p>

<p>Document the device''s condition with photos, noting any existing damage or issues. This protects both you and the customer and provides a reference during reassembly.</p>

<h3>Disassembly</h3>
<p>Carefully disassemble the device following manufacturer guidelines or repair manuals. Keep track of all screws and small components using a magnetic mat or organizer tray.</p>

<p>Take your time during this phase - rushing can lead to broken clips, stripped screws, or damaged cables. Each device has its own quirks and challenges that you''ll learn through experience.</p>

<h3>Diagnosis and Repair</h3>
<p>Once the device is open, carefully inspect all components for signs of damage, wear, or malfunction. Use diagnostic tools to test electrical connections and identify faulty parts.</p>

<p>Replace damaged components with high-quality parts from reputable suppliers. Avoid cheap alternatives that may fail prematurely or cause additional problems.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/99ebdc0e-e01a-49bb-8810-a7a8ca61a80d.jpg" alt="Repair process" />

<h3>Testing and Quality Control</h3>
<p>Before final assembly, test all functions thoroughly:</p>
<ul>
<li>Display and touch responsiveness</li>
<li>Camera functionality (front and rear)</li>
<li>Audio input and output</li>
<li>Charging and battery performance</li>
<li>Wireless connectivity (WiFi, Bluetooth, cellular)</li>
<li>Sensors and buttons</li>
<li>Biometric features (Face ID, Touch ID)</li>
</ul>

<h2>Common Challenges and Solutions</h2>
<p>Even experienced technicians encounter challenges. Here are some common issues and how to address them:</p>

<h3>Stubborn Adhesive</h3>
<p>Modern devices use strong adhesive to secure components. Apply gentle heat and use proper prying techniques to avoid damage. Patience is key - never force components apart.</p>

<h3>Delicate Flex Cables</h3>
<p>Flex cables are extremely fragile and can tear easily. Always disconnect them carefully by lifting the connector straight up, never at an angle. Use proper tools and avoid excessive force.</p>

<h3>Stripped Screws</h3>
<p>If you encounter a stripped screw, try using a rubber band between the screwdriver and screw head for extra grip. As a last resort, carefully drill out the screw using appropriate safety measures.</p>



<h2>Best Practices for Professional Results</h2>
<p>To consistently deliver high-quality repairs:</p>

<ul>
<li>Maintain a clean, organized workspace</li>
<li>Use proper ESD protection at all times</li>
<li>Follow manufacturer repair procedures when available</li>
<li>Keep detailed repair logs and documentation</li>
<li>Stay updated on new techniques and tools</li>
<li>Invest in quality replacement parts</li>
<li>Provide clear communication with customers</li>
<li>Test thoroughly before returning devices</li>
<li>Offer appropriate warranties on your work</li>
</ul>

<h2>Safety Considerations</h2>
<p>Safety should always be your top priority:</p>
<ul>
<li>Wear safety glasses when working with glass or using power tools</li>
<li>Handle batteries carefully - never puncture or short circuit them</li>
<li>Work in a well-ventilated area when soldering</li>
<li>Use proper lifting techniques for heavy equipment</li>
<li>Keep a fire extinguisher nearby</li>
<li>Dispose of damaged batteries properly</li>
<li>Use heat-resistant surfaces and tools</li>
<li>Avoid working on devices while they''re powered on</li>
</ul>

<h2>Continuing Education and Skill Development</h2>
<p>The mobile repair industry evolves rapidly. Stay current by:</p>
<ul>
<li>Attending industry conferences and workshops</li>
<li>Joining professional repair associations</li>
<li>Following repair forums and online communities</li>
<li>Watching tutorial videos from experienced technicians</li>
<li>Practicing on older devices to build skills</li>
<li>Reading technical documentation and repair guides</li>
<li>Networking with other repair professionals</li>
<li>Experimenting with new tools and techniques</li>
</ul>

<h2>Business Aspects of Phone Repair</h2>
<p>Technical skills alone aren''t enough for success. Consider these business factors:</p>

<h3>Pricing Strategy</h3>
<p>Research local market rates and factor in your costs for parts, labor, overhead, and desired profit margin. Be competitive but don''t undervalue your expertise.</p>

<h3>Customer Service</h3>
<p>Excellent customer service builds loyalty and generates referrals. Communicate clearly, set realistic expectations, and follow through on commitments.</p>

<h3>Marketing</h3>
<p>Develop an online presence through a website and social media. Encourage satisfied customers to leave reviews and share their experiences.</p>

<h2>Conclusion</h2>
<p>Remember that quality repairs require patience, proper tools, and continuous learning.</p>

<p>Whether you''re just starting out or looking to refine your skills, continuous practice and learning are essential. The satisfaction of successfully repairing a device and helping a customer is one of the most rewarding aspects of this profession.</p>

<p>Remember to always prioritize quality over speed, invest in proper tools and training, and treat each repair with the care and attention it deserves. Your reputation is built on every device you repair.</p>
', 'Professional phone repair requires a combination of technical knowledge, proper tools, and hands-on experience....', 'https://miaoda-site-img.cdn.bcebos.com/images/70f0e381-8722-4ffd-a956-57f4988d9331.jpg', '3e48c97c-75b3-410d-873b-dc97e4053d67', 'b9e5ca3e-16bd-40bc-9de8-0894cb41f4fc', 'published', 333, 'en', NOW());

INSERT INTO articles (title, slug, content, excerpt, cover_image, category_id, author_id, status, view_count, language, published_at)
VALUES ('How to Fix Water Damaged Smartphones', 'how-to-fix-water-damaged-smartphones-1', '
<h2>Introduction</h2>
<p>Modern smartphones are sophisticated devices that demand careful handling and specialized expertise.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/b426188e-c374-491c-9b42-28181449a33c.jpg" alt="How to Fix Water Damaged Smartphones" />

<h2>Understanding the Fundamentals</h2>
<p>Before diving into the technical aspects, it''s important to understand the fundamental principles that govern this area of mobile device repair. Modern smartphones are complex devices with intricate components that require careful handling and specialized knowledge.</p>

<p>The repair process involves several key stages, each requiring specific tools and techniques. Professional technicians must be familiar with various device models, their unique characteristics, and common failure points.</p>

<h2>Essential Tools and Equipment</h2>
<p>Having the right tools is crucial for successful repairs. Here are the essential items you''ll need:</p>

<ul>
<li>Precision screwdriver set with multiple bits</li>
<li>Anti-static mat and wrist strap</li>
<li>Plastic opening tools and spudgers</li>
<li>Tweezers and magnifying glass</li>
<li>Heat gun or hot air station</li>
<li>Multimeter for electrical testing</li>
<li>Soldering iron with temperature control</li>
<li>Isopropyl alcohol for cleaning</li>
</ul>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/99ebdc0e-e01a-49bb-8810-a7a8ca61a80d.jpg" alt="Professional repair tools" />

<h2>Step-by-Step Process</h2>
<h3>Preparation Phase</h3>
<p>Proper preparation is essential for any repair job. Start by creating a clean, organized workspace with adequate lighting. Gather all necessary tools and replacement parts before beginning the repair.</p>

<p>Document the device''s condition with photos, noting any existing damage or issues. This protects both you and the customer and provides a reference during reassembly.</p>

<h3>Disassembly</h3>
<p>Carefully disassemble the device following manufacturer guidelines or repair manuals. Keep track of all screws and small components using a magnetic mat or organizer tray.</p>

<p>Take your time during this phase - rushing can lead to broken clips, stripped screws, or damaged cables. Each device has its own quirks and challenges that you''ll learn through experience.</p>

<h3>Diagnosis and Repair</h3>
<p>Once the device is open, carefully inspect all components for signs of damage, wear, or malfunction. Use diagnostic tools to test electrical connections and identify faulty parts.</p>

<p>Replace damaged components with high-quality parts from reputable suppliers. Avoid cheap alternatives that may fail prematurely or cause additional problems.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/d31e2fc6-38d9-4496-9999-671b1f34a410.jpg" alt="Repair process" />

<h3>Testing and Quality Control</h3>
<p>Before final assembly, test all functions thoroughly:</p>
<ul>
<li>Display and touch responsiveness</li>
<li>Camera functionality (front and rear)</li>
<li>Audio input and output</li>
<li>Charging and battery performance</li>
<li>Wireless connectivity (WiFi, Bluetooth, cellular)</li>
<li>Sensors and buttons</li>
<li>Biometric features (Face ID, Touch ID)</li>
</ul>

<h2>Common Challenges and Solutions</h2>
<p>Even experienced technicians encounter challenges. Here are some common issues and how to address them:</p>

<h3>Stubborn Adhesive</h3>
<p>Modern devices use strong adhesive to secure components. Apply gentle heat and use proper prying techniques to avoid damage. Patience is key - never force components apart.</p>

<h3>Delicate Flex Cables</h3>
<p>Flex cables are extremely fragile and can tear easily. Always disconnect them carefully by lifting the connector straight up, never at an angle. Use proper tools and avoid excessive force.</p>

<h3>Stripped Screws</h3>
<p>If you encounter a stripped screw, try using a rubber band between the screwdriver and screw head for extra grip. As a last resort, carefully drill out the screw using appropriate safety measures.</p>



<h2>Best Practices for Professional Results</h2>
<p>To consistently deliver high-quality repairs:</p>

<ul>
<li>Maintain a clean, organized workspace</li>
<li>Use proper ESD protection at all times</li>
<li>Follow manufacturer repair procedures when available</li>
<li>Keep detailed repair logs and documentation</li>
<li>Stay updated on new techniques and tools</li>
<li>Invest in quality replacement parts</li>
<li>Provide clear communication with customers</li>
<li>Test thoroughly before returning devices</li>
<li>Offer appropriate warranties on your work</li>
</ul>

<h2>Safety Considerations</h2>
<p>Safety should always be your top priority:</p>
<ul>
<li>Wear safety glasses when working with glass or using power tools</li>
<li>Handle batteries carefully - never puncture or short circuit them</li>
<li>Work in a well-ventilated area when soldering</li>
<li>Use proper lifting techniques for heavy equipment</li>
<li>Keep a fire extinguisher nearby</li>
<li>Dispose of damaged batteries properly</li>
<li>Use heat-resistant surfaces and tools</li>
<li>Avoid working on devices while they''re powered on</li>
</ul>

<h2>Continuing Education and Skill Development</h2>
<p>The mobile repair industry evolves rapidly. Stay current by:</p>
<ul>
<li>Attending industry conferences and workshops</li>
<li>Joining professional repair associations</li>
<li>Following repair forums and online communities</li>
<li>Watching tutorial videos from experienced technicians</li>
<li>Practicing on older devices to build skills</li>
<li>Reading technical documentation and repair guides</li>
<li>Networking with other repair professionals</li>
<li>Experimenting with new tools and techniques</li>
</ul>

<h2>Business Aspects of Phone Repair</h2>
<p>Technical skills alone aren''t enough for success. Consider these business factors:</p>

<h3>Pricing Strategy</h3>
<p>Research local market rates and factor in your costs for parts, labor, overhead, and desired profit margin. Be competitive but don''t undervalue your expertise.</p>

<h3>Customer Service</h3>
<p>Excellent customer service builds loyalty and generates referrals. Communicate clearly, set realistic expectations, and follow through on commitments.</p>

<h3>Marketing</h3>
<p>Develop an online presence through a website and social media. Encourage satisfied customers to leave reviews and share their experiences.</p>

<h2>Conclusion</h2>
<p>With practice and dedication, these techniques will help you become a more proficient repair technician.</p>

<p>Whether you''re just starting out or looking to refine your skills, continuous practice and learning are essential. The satisfaction of successfully repairing a device and helping a customer is one of the most rewarding aspects of this profession.</p>

<p>Remember to always prioritize quality over speed, invest in proper tools and training, and treat each repair with the care and attention it deserves. Your reputation is built on every device you repair.</p>
', 'Modern smartphones are sophisticated devices that demand careful handling and specialized expertise....', 'https://miaoda-site-img.cdn.bcebos.com/images/b426188e-c374-491c-9b42-28181449a33c.jpg', '749ba4ef-ad43-4a4b-a9fb-8b44186c7970', 'b9e5ca3e-16bd-40bc-9de8-0894cb41f4fc', 'published', 94, 'en', NOW());

INSERT INTO articles (title, slug, content, excerpt, cover_image, category_id, author_id, status, view_count, language, published_at)
VALUES ('Mastering Smartphone Battery Replacement Techniques', 'mastering-smartphone-battery-replacement-techniques-1', '
<h2>Introduction</h2>
<p>The mobile repair industry continues to grow, creating opportunities for skilled technicians worldwide.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/99ebdc0e-e01a-49bb-8810-a7a8ca61a80d.jpg" alt="Mastering Smartphone Battery Replacement Techniques" />

<h2>Understanding the Fundamentals</h2>
<p>Before diving into the technical aspects, it''s important to understand the fundamental principles that govern this area of mobile device repair. Modern smartphones are complex devices with intricate components that require careful handling and specialized knowledge.</p>

<p>The repair process involves several key stages, each requiring specific tools and techniques. Professional technicians must be familiar with various device models, their unique characteristics, and common failure points.</p>

<h2>Essential Tools and Equipment</h2>
<p>Having the right tools is crucial for successful repairs. Here are the essential items you''ll need:</p>

<ul>
<li>Precision screwdriver set with multiple bits</li>
<li>Anti-static mat and wrist strap</li>
<li>Plastic opening tools and spudgers</li>
<li>Tweezers and magnifying glass</li>
<li>Heat gun or hot air station</li>
<li>Multimeter for electrical testing</li>
<li>Soldering iron with temperature control</li>
<li>Isopropyl alcohol for cleaning</li>
</ul>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/d31e2fc6-38d9-4496-9999-671b1f34a410.jpg" alt="Professional repair tools" />

<h2>Step-by-Step Process</h2>
<h3>Preparation Phase</h3>
<p>Proper preparation is essential for any repair job. Start by creating a clean, organized workspace with adequate lighting. Gather all necessary tools and replacement parts before beginning the repair.</p>

<p>Document the device''s condition with photos, noting any existing damage or issues. This protects both you and the customer and provides a reference during reassembly.</p>

<h3>Disassembly</h3>
<p>Carefully disassemble the device following manufacturer guidelines or repair manuals. Keep track of all screws and small components using a magnetic mat or organizer tray.</p>

<p>Take your time during this phase - rushing can lead to broken clips, stripped screws, or damaged cables. Each device has its own quirks and challenges that you''ll learn through experience.</p>

<h3>Diagnosis and Repair</h3>
<p>Once the device is open, carefully inspect all components for signs of damage, wear, or malfunction. Use diagnostic tools to test electrical connections and identify faulty parts.</p>

<p>Replace damaged components with high-quality parts from reputable suppliers. Avoid cheap alternatives that may fail prematurely or cause additional problems.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/f18b8341-4616-4f72-af94-956774ad3321.jpg" alt="Repair process" />

<h3>Testing and Quality Control</h3>
<p>Before final assembly, test all functions thoroughly:</p>
<ul>
<li>Display and touch responsiveness</li>
<li>Camera functionality (front and rear)</li>
<li>Audio input and output</li>
<li>Charging and battery performance</li>
<li>Wireless connectivity (WiFi, Bluetooth, cellular)</li>
<li>Sensors and buttons</li>
<li>Biometric features (Face ID, Touch ID)</li>
</ul>

<h2>Common Challenges and Solutions</h2>
<p>Even experienced technicians encounter challenges. Here are some common issues and how to address them:</p>

<h3>Stubborn Adhesive</h3>
<p>Modern devices use strong adhesive to secure components. Apply gentle heat and use proper prying techniques to avoid damage. Patience is key - never force components apart.</p>

<h3>Delicate Flex Cables</h3>
<p>Flex cables are extremely fragile and can tear easily. Always disconnect them carefully by lifting the connector straight up, never at an angle. Use proper tools and avoid excessive force.</p>

<h3>Stripped Screws</h3>
<p>If you encounter a stripped screw, try using a rubber band between the screwdriver and screw head for extra grip. As a last resort, carefully drill out the screw using appropriate safety measures.</p>



<h2>Best Practices for Professional Results</h2>
<p>To consistently deliver high-quality repairs:</p>

<ul>
<li>Maintain a clean, organized workspace</li>
<li>Use proper ESD protection at all times</li>
<li>Follow manufacturer repair procedures when available</li>
<li>Keep detailed repair logs and documentation</li>
<li>Stay updated on new techniques and tools</li>
<li>Invest in quality replacement parts</li>
<li>Provide clear communication with customers</li>
<li>Test thoroughly before returning devices</li>
<li>Offer appropriate warranties on your work</li>
</ul>

<h2>Safety Considerations</h2>
<p>Safety should always be your top priority:</p>
<ul>
<li>Wear safety glasses when working with glass or using power tools</li>
<li>Handle batteries carefully - never puncture or short circuit them</li>
<li>Work in a well-ventilated area when soldering</li>
<li>Use proper lifting techniques for heavy equipment</li>
<li>Keep a fire extinguisher nearby</li>
<li>Dispose of damaged batteries properly</li>
<li>Use heat-resistant surfaces and tools</li>
<li>Avoid working on devices while they''re powered on</li>
</ul>

<h2>Continuing Education and Skill Development</h2>
<p>The mobile repair industry evolves rapidly. Stay current by:</p>
<ul>
<li>Attending industry conferences and workshops</li>
<li>Joining professional repair associations</li>
<li>Following repair forums and online communities</li>
<li>Watching tutorial videos from experienced technicians</li>
<li>Practicing on older devices to build skills</li>
<li>Reading technical documentation and repair guides</li>
<li>Networking with other repair professionals</li>
<li>Experimenting with new tools and techniques</li>
</ul>

<h2>Business Aspects of Phone Repair</h2>
<p>Technical skills alone aren''t enough for success. Consider these business factors:</p>

<h3>Pricing Strategy</h3>
<p>Research local market rates and factor in your costs for parts, labor, overhead, and desired profit margin. Be competitive but don''t undervalue your expertise.</p>

<h3>Customer Service</h3>
<p>Excellent customer service builds loyalty and generates referrals. Communicate clearly, set realistic expectations, and follow through on commitments.</p>

<h3>Marketing</h3>
<p>Develop an online presence through a website and social media. Encourage satisfied customers to leave reviews and share their experiences.</p>

<h2>Conclusion</h2>
<p>By following these guidelines, you''ll be well-equipped to handle a wide range of repair challenges.</p>

<p>Whether you''re just starting out or looking to refine your skills, continuous practice and learning are essential. The satisfaction of successfully repairing a device and helping a customer is one of the most rewarding aspects of this profession.</p>

<p>Remember to always prioritize quality over speed, invest in proper tools and training, and treat each repair with the care and attention it deserves. Your reputation is built on every device you repair.</p>
', 'The mobile repair industry continues to grow, creating opportunities for skilled technicians worldwide....', 'https://miaoda-site-img.cdn.bcebos.com/images/99ebdc0e-e01a-49bb-8810-a7a8ca61a80d.jpg', 'a3d51711-4268-480a-9733-70941ef08159', 'b9e5ca3e-16bd-40bc-9de8-0894cb41f4fc', 'published', 322, 'en', NOW());

INSERT INTO articles (title, slug, content, excerpt, cover_image, category_id, author_id, status, view_count, language, published_at)
VALUES ('Professional Guide to Charging Port Repair', 'professional-guide-to-charging-port-repair-1', '
<h2>Introduction</h2>
<p>Modern smartphones are sophisticated devices that demand careful handling and specialized expertise.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/d31e2fc6-38d9-4496-9999-671b1f34a410.jpg" alt="Professional Guide to Charging Port Repair" />

<h2>Understanding the Fundamentals</h2>
<p>Before diving into the technical aspects, it''s important to understand the fundamental principles that govern this area of mobile device repair. Modern smartphones are complex devices with intricate components that require careful handling and specialized knowledge.</p>

<p>The repair process involves several key stages, each requiring specific tools and techniques. Professional technicians must be familiar with various device models, their unique characteristics, and common failure points.</p>

<h2>Essential Tools and Equipment</h2>
<p>Having the right tools is crucial for successful repairs. Here are the essential items you''ll need:</p>

<ul>
<li>Precision screwdriver set with multiple bits</li>
<li>Anti-static mat and wrist strap</li>
<li>Plastic opening tools and spudgers</li>
<li>Tweezers and magnifying glass</li>
<li>Heat gun or hot air station</li>
<li>Multimeter for electrical testing</li>
<li>Soldering iron with temperature control</li>
<li>Isopropyl alcohol for cleaning</li>
</ul>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/f18b8341-4616-4f72-af94-956774ad3321.jpg" alt="Professional repair tools" />

<h2>Step-by-Step Process</h2>
<h3>Preparation Phase</h3>
<p>Proper preparation is essential for any repair job. Start by creating a clean, organized workspace with adequate lighting. Gather all necessary tools and replacement parts before beginning the repair.</p>

<p>Document the device''s condition with photos, noting any existing damage or issues. This protects both you and the customer and provides a reference during reassembly.</p>

<h3>Disassembly</h3>
<p>Carefully disassemble the device following manufacturer guidelines or repair manuals. Keep track of all screws and small components using a magnetic mat or organizer tray.</p>

<p>Take your time during this phase - rushing can lead to broken clips, stripped screws, or damaged cables. Each device has its own quirks and challenges that you''ll learn through experience.</p>

<h3>Diagnosis and Repair</h3>
<p>Once the device is open, carefully inspect all components for signs of damage, wear, or malfunction. Use diagnostic tools to test electrical connections and identify faulty parts.</p>

<p>Replace damaged components with high-quality parts from reputable suppliers. Avoid cheap alternatives that may fail prematurely or cause additional problems.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/63ef6cad-92c0-4e66-bb1a-2fc5340e2f2e.jpg" alt="Repair process" />

<h3>Testing and Quality Control</h3>
<p>Before final assembly, test all functions thoroughly:</p>
<ul>
<li>Display and touch responsiveness</li>
<li>Camera functionality (front and rear)</li>
<li>Audio input and output</li>
<li>Charging and battery performance</li>
<li>Wireless connectivity (WiFi, Bluetooth, cellular)</li>
<li>Sensors and buttons</li>
<li>Biometric features (Face ID, Touch ID)</li>
</ul>

<h2>Common Challenges and Solutions</h2>
<p>Even experienced technicians encounter challenges. Here are some common issues and how to address them:</p>

<h3>Stubborn Adhesive</h3>
<p>Modern devices use strong adhesive to secure components. Apply gentle heat and use proper prying techniques to avoid damage. Patience is key - never force components apart.</p>

<h3>Delicate Flex Cables</h3>
<p>Flex cables are extremely fragile and can tear easily. Always disconnect them carefully by lifting the connector straight up, never at an angle. Use proper tools and avoid excessive force.</p>

<h3>Stripped Screws</h3>
<p>If you encounter a stripped screw, try using a rubber band between the screwdriver and screw head for extra grip. As a last resort, carefully drill out the screw using appropriate safety measures.</p>



<h2>Best Practices for Professional Results</h2>
<p>To consistently deliver high-quality repairs:</p>

<ul>
<li>Maintain a clean, organized workspace</li>
<li>Use proper ESD protection at all times</li>
<li>Follow manufacturer repair procedures when available</li>
<li>Keep detailed repair logs and documentation</li>
<li>Stay updated on new techniques and tools</li>
<li>Invest in quality replacement parts</li>
<li>Provide clear communication with customers</li>
<li>Test thoroughly before returning devices</li>
<li>Offer appropriate warranties on your work</li>
</ul>

<h2>Safety Considerations</h2>
<p>Safety should always be your top priority:</p>
<ul>
<li>Wear safety glasses when working with glass or using power tools</li>
<li>Handle batteries carefully - never puncture or short circuit them</li>
<li>Work in a well-ventilated area when soldering</li>
<li>Use proper lifting techniques for heavy equipment</li>
<li>Keep a fire extinguisher nearby</li>
<li>Dispose of damaged batteries properly</li>
<li>Use heat-resistant surfaces and tools</li>
<li>Avoid working on devices while they''re powered on</li>
</ul>

<h2>Continuing Education and Skill Development</h2>
<p>The mobile repair industry evolves rapidly. Stay current by:</p>
<ul>
<li>Attending industry conferences and workshops</li>
<li>Joining professional repair associations</li>
<li>Following repair forums and online communities</li>
<li>Watching tutorial videos from experienced technicians</li>
<li>Practicing on older devices to build skills</li>
<li>Reading technical documentation and repair guides</li>
<li>Networking with other repair professionals</li>
<li>Experimenting with new tools and techniques</li>
</ul>

<h2>Business Aspects of Phone Repair</h2>
<p>Technical skills alone aren''t enough for success. Consider these business factors:</p>

<h3>Pricing Strategy</h3>
<p>Research local market rates and factor in your costs for parts, labor, overhead, and desired profit margin. Be competitive but don''t undervalue your expertise.</p>

<h3>Customer Service</h3>
<p>Excellent customer service builds loyalty and generates referrals. Communicate clearly, set realistic expectations, and follow through on commitments.</p>

<h3>Marketing</h3>
<p>Develop an online presence through a website and social media. Encourage satisfied customers to leave reviews and share their experiences.</p>

<h2>Conclusion</h2>
<p>Practice these techniques regularly to maintain and improve your skills.</p>

<p>Whether you''re just starting out or looking to refine your skills, continuous practice and learning are essential. The satisfaction of successfully repairing a device and helping a customer is one of the most rewarding aspects of this profession.</p>

<p>Remember to always prioritize quality over speed, invest in proper tools and training, and treat each repair with the care and attention it deserves. Your reputation is built on every device you repair.</p>
', 'Modern smartphones are sophisticated devices that demand careful handling and specialized expertise....', 'https://miaoda-site-img.cdn.bcebos.com/images/d31e2fc6-38d9-4496-9999-671b1f34a410.jpg', '3da24a8a-b652-4b69-a3f6-42b034e794c2', 'b9e5ca3e-16bd-40bc-9de8-0894cb41f4fc', 'published', 94, 'en', NOW());

INSERT INTO articles (title, slug, content, excerpt, cover_image, category_id, author_id, status, view_count, language, published_at)
VALUES ('Understanding Smartphone Motherboard Components', 'understanding-smartphone-motherboard-components-1', '
<h2>Introduction</h2>
<p>This detailed tutorial will help you develop the skills needed for professional-quality repairs.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/f18b8341-4616-4f72-af94-956774ad3321.jpg" alt="Understanding Smartphone Motherboard Components" />

<h2>Understanding the Fundamentals</h2>
<p>Before diving into the technical aspects, it''s important to understand the fundamental principles that govern this area of mobile device repair. Modern smartphones are complex devices with intricate components that require careful handling and specialized knowledge.</p>

<p>The repair process involves several key stages, each requiring specific tools and techniques. Professional technicians must be familiar with various device models, their unique characteristics, and common failure points.</p>

<h2>Essential Tools and Equipment</h2>
<p>Having the right tools is crucial for successful repairs. Here are the essential items you''ll need:</p>

<ul>
<li>Precision screwdriver set with multiple bits</li>
<li>Anti-static mat and wrist strap</li>
<li>Plastic opening tools and spudgers</li>
<li>Tweezers and magnifying glass</li>
<li>Heat gun or hot air station</li>
<li>Multimeter for electrical testing</li>
<li>Soldering iron with temperature control</li>
<li>Isopropyl alcohol for cleaning</li>
</ul>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/63ef6cad-92c0-4e66-bb1a-2fc5340e2f2e.jpg" alt="Professional repair tools" />

<h2>Step-by-Step Process</h2>
<h3>Preparation Phase</h3>
<p>Proper preparation is essential for any repair job. Start by creating a clean, organized workspace with adequate lighting. Gather all necessary tools and replacement parts before beginning the repair.</p>

<p>Document the device''s condition with photos, noting any existing damage or issues. This protects both you and the customer and provides a reference during reassembly.</p>

<h3>Disassembly</h3>
<p>Carefully disassemble the device following manufacturer guidelines or repair manuals. Keep track of all screws and small components using a magnetic mat or organizer tray.</p>

<p>Take your time during this phase - rushing can lead to broken clips, stripped screws, or damaged cables. Each device has its own quirks and challenges that you''ll learn through experience.</p>

<h3>Diagnosis and Repair</h3>
<p>Once the device is open, carefully inspect all components for signs of damage, wear, or malfunction. Use diagnostic tools to test electrical connections and identify faulty parts.</p>

<p>Replace damaged components with high-quality parts from reputable suppliers. Avoid cheap alternatives that may fail prematurely or cause additional problems.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/7e412fe2-421b-4f0e-82f5-525175df7f9c.jpg" alt="Repair process" />

<h3>Testing and Quality Control</h3>
<p>Before final assembly, test all functions thoroughly:</p>
<ul>
<li>Display and touch responsiveness</li>
<li>Camera functionality (front and rear)</li>
<li>Audio input and output</li>
<li>Charging and battery performance</li>
<li>Wireless connectivity (WiFi, Bluetooth, cellular)</li>
<li>Sensors and buttons</li>
<li>Biometric features (Face ID, Touch ID)</li>
</ul>

<h2>Common Challenges and Solutions</h2>
<p>Even experienced technicians encounter challenges. Here are some common issues and how to address them:</p>

<h3>Stubborn Adhesive</h3>
<p>Modern devices use strong adhesive to secure components. Apply gentle heat and use proper prying techniques to avoid damage. Patience is key - never force components apart.</p>

<h3>Delicate Flex Cables</h3>
<p>Flex cables are extremely fragile and can tear easily. Always disconnect them carefully by lifting the connector straight up, never at an angle. Use proper tools and avoid excessive force.</p>

<h3>Stripped Screws</h3>
<p>If you encounter a stripped screw, try using a rubber band between the screwdriver and screw head for extra grip. As a last resort, carefully drill out the screw using appropriate safety measures.</p>



<h2>Best Practices for Professional Results</h2>
<p>To consistently deliver high-quality repairs:</p>

<ul>
<li>Maintain a clean, organized workspace</li>
<li>Use proper ESD protection at all times</li>
<li>Follow manufacturer repair procedures when available</li>
<li>Keep detailed repair logs and documentation</li>
<li>Stay updated on new techniques and tools</li>
<li>Invest in quality replacement parts</li>
<li>Provide clear communication with customers</li>
<li>Test thoroughly before returning devices</li>
<li>Offer appropriate warranties on your work</li>
</ul>

<h2>Safety Considerations</h2>
<p>Safety should always be your top priority:</p>
<ul>
<li>Wear safety glasses when working with glass or using power tools</li>
<li>Handle batteries carefully - never puncture or short circuit them</li>
<li>Work in a well-ventilated area when soldering</li>
<li>Use proper lifting techniques for heavy equipment</li>
<li>Keep a fire extinguisher nearby</li>
<li>Dispose of damaged batteries properly</li>
<li>Use heat-resistant surfaces and tools</li>
<li>Avoid working on devices while they''re powered on</li>
</ul>

<h2>Continuing Education and Skill Development</h2>
<p>The mobile repair industry evolves rapidly. Stay current by:</p>
<ul>
<li>Attending industry conferences and workshops</li>
<li>Joining professional repair associations</li>
<li>Following repair forums and online communities</li>
<li>Watching tutorial videos from experienced technicians</li>
<li>Practicing on older devices to build skills</li>
<li>Reading technical documentation and repair guides</li>
<li>Networking with other repair professionals</li>
<li>Experimenting with new tools and techniques</li>
</ul>

<h2>Business Aspects of Phone Repair</h2>
<p>Technical skills alone aren''t enough for success. Consider these business factors:</p>

<h3>Pricing Strategy</h3>
<p>Research local market rates and factor in your costs for parts, labor, overhead, and desired profit margin. Be competitive but don''t undervalue your expertise.</p>

<h3>Customer Service</h3>
<p>Excellent customer service builds loyalty and generates referrals. Communicate clearly, set realistic expectations, and follow through on commitments.</p>

<h3>Marketing</h3>
<p>Develop an online presence through a website and social media. Encourage satisfied customers to leave reviews and share their experiences.</p>

<h2>Conclusion</h2>
<p>Practice these techniques regularly to maintain and improve your skills.</p>

<p>Whether you''re just starting out or looking to refine your skills, continuous practice and learning are essential. The satisfaction of successfully repairing a device and helping a customer is one of the most rewarding aspects of this profession.</p>

<p>Remember to always prioritize quality over speed, invest in proper tools and training, and treat each repair with the care and attention it deserves. Your reputation is built on every device you repair.</p>
', 'This detailed tutorial will help you develop the skills needed for professional-quality repairs....', 'https://miaoda-site-img.cdn.bcebos.com/images/f18b8341-4616-4f72-af94-956774ad3321.jpg', '3e48c97c-75b3-410d-873b-dc97e4053d67', 'b9e5ca3e-16bd-40bc-9de8-0894cb41f4fc', 'published', 476, 'en', NOW());

INSERT INTO articles (title, slug, content, excerpt, cover_image, category_id, author_id, status, view_count, language, published_at)
VALUES ('Complete Tutorial: Back Glass Replacement', 'complete-tutorial-back-glass-replacement-1', '
<h2>Introduction</h2>
<p>Professional phone repair requires a combination of technical knowledge, proper tools, and hands-on experience.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/63ef6cad-92c0-4e66-bb1a-2fc5340e2f2e.jpg" alt="Complete Tutorial: Back Glass Replacement" />

<h2>Understanding the Fundamentals</h2>
<p>Before diving into the technical aspects, it''s important to understand the fundamental principles that govern this area of mobile device repair. Modern smartphones are complex devices with intricate components that require careful handling and specialized knowledge.</p>

<p>The repair process involves several key stages, each requiring specific tools and techniques. Professional technicians must be familiar with various device models, their unique characteristics, and common failure points.</p>

<h2>Essential Tools and Equipment</h2>
<p>Having the right tools is crucial for successful repairs. Here are the essential items you''ll need:</p>

<ul>
<li>Precision screwdriver set with multiple bits</li>
<li>Anti-static mat and wrist strap</li>
<li>Plastic opening tools and spudgers</li>
<li>Tweezers and magnifying glass</li>
<li>Heat gun or hot air station</li>
<li>Multimeter for electrical testing</li>
<li>Soldering iron with temperature control</li>
<li>Isopropyl alcohol for cleaning</li>
</ul>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/7e412fe2-421b-4f0e-82f5-525175df7f9c.jpg" alt="Professional repair tools" />

<h2>Step-by-Step Process</h2>
<h3>Preparation Phase</h3>
<p>Proper preparation is essential for any repair job. Start by creating a clean, organized workspace with adequate lighting. Gather all necessary tools and replacement parts before beginning the repair.</p>

<p>Document the device''s condition with photos, noting any existing damage or issues. This protects both you and the customer and provides a reference during reassembly.</p>

<h3>Disassembly</h3>
<p>Carefully disassemble the device following manufacturer guidelines or repair manuals. Keep track of all screws and small components using a magnetic mat or organizer tray.</p>

<p>Take your time during this phase - rushing can lead to broken clips, stripped screws, or damaged cables. Each device has its own quirks and challenges that you''ll learn through experience.</p>

<h3>Diagnosis and Repair</h3>
<p>Once the device is open, carefully inspect all components for signs of damage, wear, or malfunction. Use diagnostic tools to test electrical connections and identify faulty parts.</p>

<p>Replace damaged components with high-quality parts from reputable suppliers. Avoid cheap alternatives that may fail prematurely or cause additional problems.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/c61dedc7-c308-4a0d-8346-3f1131a752a1.jpg" alt="Repair process" />

<h3>Testing and Quality Control</h3>
<p>Before final assembly, test all functions thoroughly:</p>
<ul>
<li>Display and touch responsiveness</li>
<li>Camera functionality (front and rear)</li>
<li>Audio input and output</li>
<li>Charging and battery performance</li>
<li>Wireless connectivity (WiFi, Bluetooth, cellular)</li>
<li>Sensors and buttons</li>
<li>Biometric features (Face ID, Touch ID)</li>
</ul>

<h2>Common Challenges and Solutions</h2>
<p>Even experienced technicians encounter challenges. Here are some common issues and how to address them:</p>

<h3>Stubborn Adhesive</h3>
<p>Modern devices use strong adhesive to secure components. Apply gentle heat and use proper prying techniques to avoid damage. Patience is key - never force components apart.</p>

<h3>Delicate Flex Cables</h3>
<p>Flex cables are extremely fragile and can tear easily. Always disconnect them carefully by lifting the connector straight up, never at an angle. Use proper tools and avoid excessive force.</p>

<h3>Stripped Screws</h3>
<p>If you encounter a stripped screw, try using a rubber band between the screwdriver and screw head for extra grip. As a last resort, carefully drill out the screw using appropriate safety measures.</p>



<h2>Best Practices for Professional Results</h2>
<p>To consistently deliver high-quality repairs:</p>

<ul>
<li>Maintain a clean, organized workspace</li>
<li>Use proper ESD protection at all times</li>
<li>Follow manufacturer repair procedures when available</li>
<li>Keep detailed repair logs and documentation</li>
<li>Stay updated on new techniques and tools</li>
<li>Invest in quality replacement parts</li>
<li>Provide clear communication with customers</li>
<li>Test thoroughly before returning devices</li>
<li>Offer appropriate warranties on your work</li>
</ul>

<h2>Safety Considerations</h2>
<p>Safety should always be your top priority:</p>
<ul>
<li>Wear safety glasses when working with glass or using power tools</li>
<li>Handle batteries carefully - never puncture or short circuit them</li>
<li>Work in a well-ventilated area when soldering</li>
<li>Use proper lifting techniques for heavy equipment</li>
<li>Keep a fire extinguisher nearby</li>
<li>Dispose of damaged batteries properly</li>
<li>Use heat-resistant surfaces and tools</li>
<li>Avoid working on devices while they''re powered on</li>
</ul>

<h2>Continuing Education and Skill Development</h2>
<p>The mobile repair industry evolves rapidly. Stay current by:</p>
<ul>
<li>Attending industry conferences and workshops</li>
<li>Joining professional repair associations</li>
<li>Following repair forums and online communities</li>
<li>Watching tutorial videos from experienced technicians</li>
<li>Practicing on older devices to build skills</li>
<li>Reading technical documentation and repair guides</li>
<li>Networking with other repair professionals</li>
<li>Experimenting with new tools and techniques</li>
</ul>

<h2>Business Aspects of Phone Repair</h2>
<p>Technical skills alone aren''t enough for success. Consider these business factors:</p>

<h3>Pricing Strategy</h3>
<p>Research local market rates and factor in your costs for parts, labor, overhead, and desired profit margin. Be competitive but don''t undervalue your expertise.</p>

<h3>Customer Service</h3>
<p>Excellent customer service builds loyalty and generates referrals. Communicate clearly, set realistic expectations, and follow through on commitments.</p>

<h3>Marketing</h3>
<p>Develop an online presence through a website and social media. Encourage satisfied customers to leave reviews and share their experiences.</p>

<h2>Conclusion</h2>
<p>Apply these principles consistently to build a reputation for excellent repair work.</p>

<p>Whether you''re just starting out or looking to refine your skills, continuous practice and learning are essential. The satisfaction of successfully repairing a device and helping a customer is one of the most rewarding aspects of this profession.</p>

<p>Remember to always prioritize quality over speed, invest in proper tools and training, and treat each repair with the care and attention it deserves. Your reputation is built on every device you repair.</p>
', 'Professional phone repair requires a combination of technical knowledge, proper tools, and hands-on experience....', 'https://miaoda-site-img.cdn.bcebos.com/images/63ef6cad-92c0-4e66-bb1a-2fc5340e2f2e.jpg', '749ba4ef-ad43-4a4b-a9fb-8b44186c7970', 'b9e5ca3e-16bd-40bc-9de8-0894cb41f4fc', 'published', 287, 'en', NOW());

INSERT INTO articles (title, slug, content, excerpt, cover_image, category_id, author_id, status, view_count, language, published_at)
VALUES ('Advanced Soldering Techniques for Phone Repair', 'advanced-soldering-techniques-for-phone-repair-1', '
<h2>Introduction</h2>
<p>The mobile repair industry continues to grow, creating opportunities for skilled technicians worldwide.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/7e412fe2-421b-4f0e-82f5-525175df7f9c.jpg" alt="Advanced Soldering Techniques for Phone Repair" />

<h2>Understanding the Fundamentals</h2>
<p>Before diving into the technical aspects, it''s important to understand the fundamental principles that govern this area of mobile device repair. Modern smartphones are complex devices with intricate components that require careful handling and specialized knowledge.</p>

<p>The repair process involves several key stages, each requiring specific tools and techniques. Professional technicians must be familiar with various device models, their unique characteristics, and common failure points.</p>

<h2>Essential Tools and Equipment</h2>
<p>Having the right tools is crucial for successful repairs. Here are the essential items you''ll need:</p>

<ul>
<li>Precision screwdriver set with multiple bits</li>
<li>Anti-static mat and wrist strap</li>
<li>Plastic opening tools and spudgers</li>
<li>Tweezers and magnifying glass</li>
<li>Heat gun or hot air station</li>
<li>Multimeter for electrical testing</li>
<li>Soldering iron with temperature control</li>
<li>Isopropyl alcohol for cleaning</li>
</ul>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/c61dedc7-c308-4a0d-8346-3f1131a752a1.jpg" alt="Professional repair tools" />

<h2>Step-by-Step Process</h2>
<h3>Preparation Phase</h3>
<p>Proper preparation is essential for any repair job. Start by creating a clean, organized workspace with adequate lighting. Gather all necessary tools and replacement parts before beginning the repair.</p>

<p>Document the device''s condition with photos, noting any existing damage or issues. This protects both you and the customer and provides a reference during reassembly.</p>

<h3>Disassembly</h3>
<p>Carefully disassemble the device following manufacturer guidelines or repair manuals. Keep track of all screws and small components using a magnetic mat or organizer tray.</p>

<p>Take your time during this phase - rushing can lead to broken clips, stripped screws, or damaged cables. Each device has its own quirks and challenges that you''ll learn through experience.</p>

<h3>Diagnosis and Repair</h3>
<p>Once the device is open, carefully inspect all components for signs of damage, wear, or malfunction. Use diagnostic tools to test electrical connections and identify faulty parts.</p>

<p>Replace damaged components with high-quality parts from reputable suppliers. Avoid cheap alternatives that may fail prematurely or cause additional problems.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/23bc515c-cf89-4382-948a-bfa72ccf488d.jpg" alt="Repair process" />

<h3>Testing and Quality Control</h3>
<p>Before final assembly, test all functions thoroughly:</p>
<ul>
<li>Display and touch responsiveness</li>
<li>Camera functionality (front and rear)</li>
<li>Audio input and output</li>
<li>Charging and battery performance</li>
<li>Wireless connectivity (WiFi, Bluetooth, cellular)</li>
<li>Sensors and buttons</li>
<li>Biometric features (Face ID, Touch ID)</li>
</ul>

<h2>Common Challenges and Solutions</h2>
<p>Even experienced technicians encounter challenges. Here are some common issues and how to address them:</p>

<h3>Stubborn Adhesive</h3>
<p>Modern devices use strong adhesive to secure components. Apply gentle heat and use proper prying techniques to avoid damage. Patience is key - never force components apart.</p>

<h3>Delicate Flex Cables</h3>
<p>Flex cables are extremely fragile and can tear easily. Always disconnect them carefully by lifting the connector straight up, never at an angle. Use proper tools and avoid excessive force.</p>

<h3>Stripped Screws</h3>
<p>If you encounter a stripped screw, try using a rubber band between the screwdriver and screw head for extra grip. As a last resort, carefully drill out the screw using appropriate safety measures.</p>



<h2>Best Practices for Professional Results</h2>
<p>To consistently deliver high-quality repairs:</p>

<ul>
<li>Maintain a clean, organized workspace</li>
<li>Use proper ESD protection at all times</li>
<li>Follow manufacturer repair procedures when available</li>
<li>Keep detailed repair logs and documentation</li>
<li>Stay updated on new techniques and tools</li>
<li>Invest in quality replacement parts</li>
<li>Provide clear communication with customers</li>
<li>Test thoroughly before returning devices</li>
<li>Offer appropriate warranties on your work</li>
</ul>

<h2>Safety Considerations</h2>
<p>Safety should always be your top priority:</p>
<ul>
<li>Wear safety glasses when working with glass or using power tools</li>
<li>Handle batteries carefully - never puncture or short circuit them</li>
<li>Work in a well-ventilated area when soldering</li>
<li>Use proper lifting techniques for heavy equipment</li>
<li>Keep a fire extinguisher nearby</li>
<li>Dispose of damaged batteries properly</li>
<li>Use heat-resistant surfaces and tools</li>
<li>Avoid working on devices while they''re powered on</li>
</ul>

<h2>Continuing Education and Skill Development</h2>
<p>The mobile repair industry evolves rapidly. Stay current by:</p>
<ul>
<li>Attending industry conferences and workshops</li>
<li>Joining professional repair associations</li>
<li>Following repair forums and online communities</li>
<li>Watching tutorial videos from experienced technicians</li>
<li>Practicing on older devices to build skills</li>
<li>Reading technical documentation and repair guides</li>
<li>Networking with other repair professionals</li>
<li>Experimenting with new tools and techniques</li>
</ul>

<h2>Business Aspects of Phone Repair</h2>
<p>Technical skills alone aren''t enough for success. Consider these business factors:</p>

<h3>Pricing Strategy</h3>
<p>Research local market rates and factor in your costs for parts, labor, overhead, and desired profit margin. Be competitive but don''t undervalue your expertise.</p>

<h3>Customer Service</h3>
<p>Excellent customer service builds loyalty and generates referrals. Communicate clearly, set realistic expectations, and follow through on commitments.</p>

<h3>Marketing</h3>
<p>Develop an online presence through a website and social media. Encourage satisfied customers to leave reviews and share their experiences.</p>

<h2>Conclusion</h2>
<p>By following these guidelines, you''ll be well-equipped to handle a wide range of repair challenges.</p>

<p>Whether you''re just starting out or looking to refine your skills, continuous practice and learning are essential. The satisfaction of successfully repairing a device and helping a customer is one of the most rewarding aspects of this profession.</p>

<p>Remember to always prioritize quality over speed, invest in proper tools and training, and treat each repair with the care and attention it deserves. Your reputation is built on every device you repair.</p>
', 'The mobile repair industry continues to grow, creating opportunities for skilled technicians worldwide....', 'https://miaoda-site-img.cdn.bcebos.com/images/7e412fe2-421b-4f0e-82f5-525175df7f9c.jpg', 'a3d51711-4268-480a-9733-70941ef08159', 'b9e5ca3e-16bd-40bc-9de8-0894cb41f4fc', 'published', 403, 'en', NOW());

INSERT INTO articles (title, slug, content, excerpt, cover_image, category_id, author_id, status, view_count, language, published_at)
VALUES ('Diagnosing Common Smartphone Issues', 'diagnosing-common-smartphone-issues-1', '
<h2>Introduction</h2>
<p>Whether you''re starting out or refining your techniques, this guide provides valuable insights.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/c61dedc7-c308-4a0d-8346-3f1131a752a1.jpg" alt="Diagnosing Common Smartphone Issues" />

<h2>Understanding the Fundamentals</h2>
<p>Before diving into the technical aspects, it''s important to understand the fundamental principles that govern this area of mobile device repair. Modern smartphones are complex devices with intricate components that require careful handling and specialized knowledge.</p>

<p>The repair process involves several key stages, each requiring specific tools and techniques. Professional technicians must be familiar with various device models, their unique characteristics, and common failure points.</p>

<h2>Essential Tools and Equipment</h2>
<p>Having the right tools is crucial for successful repairs. Here are the essential items you''ll need:</p>

<ul>
<li>Precision screwdriver set with multiple bits</li>
<li>Anti-static mat and wrist strap</li>
<li>Plastic opening tools and spudgers</li>
<li>Tweezers and magnifying glass</li>
<li>Heat gun or hot air station</li>
<li>Multimeter for electrical testing</li>
<li>Soldering iron with temperature control</li>
<li>Isopropyl alcohol for cleaning</li>
</ul>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/23bc515c-cf89-4382-948a-bfa72ccf488d.jpg" alt="Professional repair tools" />

<h2>Step-by-Step Process</h2>
<h3>Preparation Phase</h3>
<p>Proper preparation is essential for any repair job. Start by creating a clean, organized workspace with adequate lighting. Gather all necessary tools and replacement parts before beginning the repair.</p>

<p>Document the device''s condition with photos, noting any existing damage or issues. This protects both you and the customer and provides a reference during reassembly.</p>

<h3>Disassembly</h3>
<p>Carefully disassemble the device following manufacturer guidelines or repair manuals. Keep track of all screws and small components using a magnetic mat or organizer tray.</p>

<p>Take your time during this phase - rushing can lead to broken clips, stripped screws, or damaged cables. Each device has its own quirks and challenges that you''ll learn through experience.</p>

<h3>Diagnosis and Repair</h3>
<p>Once the device is open, carefully inspect all components for signs of damage, wear, or malfunction. Use diagnostic tools to test electrical connections and identify faulty parts.</p>

<p>Replace damaged components with high-quality parts from reputable suppliers. Avoid cheap alternatives that may fail prematurely or cause additional problems.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/7858950a-c7c1-4f3c-baee-12970b632a67.jpg" alt="Repair process" />

<h3>Testing and Quality Control</h3>
<p>Before final assembly, test all functions thoroughly:</p>
<ul>
<li>Display and touch responsiveness</li>
<li>Camera functionality (front and rear)</li>
<li>Audio input and output</li>
<li>Charging and battery performance</li>
<li>Wireless connectivity (WiFi, Bluetooth, cellular)</li>
<li>Sensors and buttons</li>
<li>Biometric features (Face ID, Touch ID)</li>
</ul>

<h2>Common Challenges and Solutions</h2>
<p>Even experienced technicians encounter challenges. Here are some common issues and how to address them:</p>

<h3>Stubborn Adhesive</h3>
<p>Modern devices use strong adhesive to secure components. Apply gentle heat and use proper prying techniques to avoid damage. Patience is key - never force components apart.</p>

<h3>Delicate Flex Cables</h3>
<p>Flex cables are extremely fragile and can tear easily. Always disconnect them carefully by lifting the connector straight up, never at an angle. Use proper tools and avoid excessive force.</p>

<h3>Stripped Screws</h3>
<p>If you encounter a stripped screw, try using a rubber band between the screwdriver and screw head for extra grip. As a last resort, carefully drill out the screw using appropriate safety measures.</p>



<h2>Best Practices for Professional Results</h2>
<p>To consistently deliver high-quality repairs:</p>

<ul>
<li>Maintain a clean, organized workspace</li>
<li>Use proper ESD protection at all times</li>
<li>Follow manufacturer repair procedures when available</li>
<li>Keep detailed repair logs and documentation</li>
<li>Stay updated on new techniques and tools</li>
<li>Invest in quality replacement parts</li>
<li>Provide clear communication with customers</li>
<li>Test thoroughly before returning devices</li>
<li>Offer appropriate warranties on your work</li>
</ul>

<h2>Safety Considerations</h2>
<p>Safety should always be your top priority:</p>
<ul>
<li>Wear safety glasses when working with glass or using power tools</li>
<li>Handle batteries carefully - never puncture or short circuit them</li>
<li>Work in a well-ventilated area when soldering</li>
<li>Use proper lifting techniques for heavy equipment</li>
<li>Keep a fire extinguisher nearby</li>
<li>Dispose of damaged batteries properly</li>
<li>Use heat-resistant surfaces and tools</li>
<li>Avoid working on devices while they''re powered on</li>
</ul>

<h2>Continuing Education and Skill Development</h2>
<p>The mobile repair industry evolves rapidly. Stay current by:</p>
<ul>
<li>Attending industry conferences and workshops</li>
<li>Joining professional repair associations</li>
<li>Following repair forums and online communities</li>
<li>Watching tutorial videos from experienced technicians</li>
<li>Practicing on older devices to build skills</li>
<li>Reading technical documentation and repair guides</li>
<li>Networking with other repair professionals</li>
<li>Experimenting with new tools and techniques</li>
</ul>

<h2>Business Aspects of Phone Repair</h2>
<p>Technical skills alone aren''t enough for success. Consider these business factors:</p>

<h3>Pricing Strategy</h3>
<p>Research local market rates and factor in your costs for parts, labor, overhead, and desired profit margin. Be competitive but don''t undervalue your expertise.</p>

<h3>Customer Service</h3>
<p>Excellent customer service builds loyalty and generates referrals. Communicate clearly, set realistic expectations, and follow through on commitments.</p>

<h3>Marketing</h3>
<p>Develop an online presence through a website and social media. Encourage satisfied customers to leave reviews and share their experiences.</p>

<h2>Conclusion</h2>
<p>Professional excellence in repair work comes from combining knowledge with practical experience.</p>

<p>Whether you''re just starting out or looking to refine your skills, continuous practice and learning are essential. The satisfaction of successfully repairing a device and helping a customer is one of the most rewarding aspects of this profession.</p>

<p>Remember to always prioritize quality over speed, invest in proper tools and training, and treat each repair with the care and attention it deserves. Your reputation is built on every device you repair.</p>
', 'Whether you''re starting out or refining your techniques, this guide provides valuable insights....', 'https://miaoda-site-img.cdn.bcebos.com/images/c61dedc7-c308-4a0d-8346-3f1131a752a1.jpg', '3da24a8a-b652-4b69-a3f6-42b034e794c2', 'b9e5ca3e-16bd-40bc-9de8-0894cb41f4fc', 'published', 125, 'en', NOW());

INSERT INTO articles (title, slug, content, excerpt, cover_image, category_id, author_id, status, view_count, language, published_at)
VALUES ('Camera Module Replacement Step-by-Step', 'camera-module-replacement-step-by-step-1', '
<h2>Introduction</h2>
<p>Modern smartphones are sophisticated devices that demand careful handling and specialized expertise.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/23bc515c-cf89-4382-948a-bfa72ccf488d.jpg" alt="Camera Module Replacement Step-by-Step" />

<h2>Understanding the Fundamentals</h2>
<p>Before diving into the technical aspects, it''s important to understand the fundamental principles that govern this area of mobile device repair. Modern smartphones are complex devices with intricate components that require careful handling and specialized knowledge.</p>

<p>The repair process involves several key stages, each requiring specific tools and techniques. Professional technicians must be familiar with various device models, their unique characteristics, and common failure points.</p>

<h2>Essential Tools and Equipment</h2>
<p>Having the right tools is crucial for successful repairs. Here are the essential items you''ll need:</p>

<ul>
<li>Precision screwdriver set with multiple bits</li>
<li>Anti-static mat and wrist strap</li>
<li>Plastic opening tools and spudgers</li>
<li>Tweezers and magnifying glass</li>
<li>Heat gun or hot air station</li>
<li>Multimeter for electrical testing</li>
<li>Soldering iron with temperature control</li>
<li>Isopropyl alcohol for cleaning</li>
</ul>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/7858950a-c7c1-4f3c-baee-12970b632a67.jpg" alt="Professional repair tools" />

<h2>Step-by-Step Process</h2>
<h3>Preparation Phase</h3>
<p>Proper preparation is essential for any repair job. Start by creating a clean, organized workspace with adequate lighting. Gather all necessary tools and replacement parts before beginning the repair.</p>

<p>Document the device''s condition with photos, noting any existing damage or issues. This protects both you and the customer and provides a reference during reassembly.</p>

<h3>Disassembly</h3>
<p>Carefully disassemble the device following manufacturer guidelines or repair manuals. Keep track of all screws and small components using a magnetic mat or organizer tray.</p>

<p>Take your time during this phase - rushing can lead to broken clips, stripped screws, or damaged cables. Each device has its own quirks and challenges that you''ll learn through experience.</p>

<h3>Diagnosis and Repair</h3>
<p>Once the device is open, carefully inspect all components for signs of damage, wear, or malfunction. Use diagnostic tools to test electrical connections and identify faulty parts.</p>

<p>Replace damaged components with high-quality parts from reputable suppliers. Avoid cheap alternatives that may fail prematurely or cause additional problems.</p>

<img src="https://miaoda-site-img.cdn.bcebos.com/images/abcc6fdc-e2d7-4a27-b444-0d03caf73842.jpg" alt="Repair process" />

<h3>Testing and Quality Control</h3>
<p>Before final assembly, test all functions thoroughly:</p>
<ul>
<li>Display and touch responsiveness</li>
<li>Camera functionality (front and rear)</li>
<li>Audio input and output</li>
<li>Charging and battery performance</li>
<li>Wireless connectivity (WiFi, Bluetooth, cellular)</li>
<li>Sensors and buttons</li>
<li>Biometric features (Face ID, Touch ID)</li>
</ul>

<h2>Common Challenges and Solutions</h2>
<p>Even experienced technicians encounter challenges. Here are some common issues and how to address them:</p>

<h3>Stubborn Adhesive</h3>
<p>Modern devices use strong adhesive to secure components. Apply gentle heat and use proper prying techniques to avoid damage. Patience is key - never force components apart.</p>

<h3>Delicate Flex Cables</h3>
<p>Flex cables are extremely fragile and can tear easily. Always disconnect them carefully by lifting the connector straight up, never at an angle. Use proper tools and avoid excessive force.</p>

<h3>Stripped Screws</h3>
<p>If you encounter a stripped screw, try using a rubber band between the screwdriver and screw head for extra grip. As a last resort, carefully drill out the screw using appropriate safety measures.</p>



<h2>Best Practices for Professional Results</h2>
<p>To consistently deliver high-quality repairs:</p>

<ul>
<li>Maintain a clean, organized workspace</li>
<li>Use proper ESD protection at all times</li>
<li>Follow manufacturer repair procedures when available</li>
<li>Keep detailed repair logs and documentation</li>
<li>Stay updated on new techniques and tools</li>
<li>Invest in quality replacement parts</li>
<li>Provide clear communication with customers</li>
<li>Test thoroughly before returning devices</li>
<li>Offer appropriate warranties on your work</li>
</ul>

<h2>Safety Considerations</h2>
<p>Safety should always be your top priority:</p>
<ul>
<li>Wear safety glasses when working with glass or using power tools</li>
<li>Handle batteries carefully - never puncture or short circuit them</li>
<li>Work in a well-ventilated area when soldering</li>
<li>Use proper lifting techniques for heavy equipment</li>
<li>Keep a fire extinguisher nearby</li>
<li>Dispose of damaged batteries properly</li>
<li>Use heat-resistant surfaces and tools</li>
<li>Avoid working on devices while they''re powered on</li>
</ul>

<h2>Continuing Education and Skill Development</h2>
<p>The mobile repair industry evolves rapidly. Stay current by:</p>
<ul>
<li>Attending industry conferences and workshops</li>
<li>Joining professional repair associations</li>
<li>Following repair forums and online communities</li>
<li>Watching tutorial videos from experienced technicians</li>
<li>Practicing on older devices to build skills</li>
<li>Reading technical documentation and repair guides</li>
<li>Networking with other repair professionals</li>
<li>Experimenting with new tools and techniques</li>
</ul>

<h2>Business Aspects of Phone Repair</h2>
<p>Technical skills alone aren''t enough for success. Consider these business factors:</p>

<h3>Pricing Strategy</h3>
<p>Research local market rates and factor in your costs for parts, labor, overhead, and desired profit margin. Be competitive but don''t undervalue your expertise.</p>

<h3>Customer Service</h3>
<p>Excellent customer service builds loyalty and generates referrals. Communicate clearly, set realistic expectations, and follow through on commitments.</p>

<h3>Marketing</h3>
<p>Develop an online presence through a website and social media. Encourage satisfied customers to leave reviews and share their experiences.</p>

<h2>Conclusion</h2>
<p>With practice and dedication, these techniques will help you become a more proficient repair technician.</p>

<p>Whether you''re just starting out or looking to refine your skills, continuous practice and learning are essential. The satisfaction of successfully repairing a device and helping a customer is one of the most rewarding aspects of this profession.</p>

<p>Remember to always prioritize quality over speed, invest in proper tools and training, and treat each repair with the care and attention it deserves. Your reputation is built on every device you repair.</p>
', 'Modern smartphones are sophisticated devices that demand careful handling and specialized expertise....', 'https://miaoda-site-img.cdn.bcebos.com/images/23bc515c-cf89-4382-948a-bfa72ccf488d.jpg', '3e48c97c-75b3-410d-873b-dc97e4053d67', 'b9e5ca3e-16bd-40bc-9de8-0894cb41f4fc', 'published', 303, 'en', NOW());

/*
# 创建视频存储桶

## 说明
为问答模块和其他内容编辑功能创建视频文件存储桶，支持上传MP4、WebM、OGG格式的视频文件。

## 存储桶配置
- 名称：app-7fshtpomqha9_cms_videos
- 公开访问：是
- 文件大小限制：50MB
- 允许的MIME类型：video/mp4, video/webm, video/ogg

## 安全策略
- 所有认证用户可以上传视频
- 所有用户（包括匿名）可以查看视频
- 只有上传者可以删除自己的视频
*/

-- 创建视频存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-7fshtpomqha9_cms_videos',
  'app-7fshtpomqha9_cms_videos',
  true,
  52428800, -- 50MB in bytes
  ARRAY['video/mp4', 'video/webm', 'video/ogg']
)
ON CONFLICT (id) DO NOTHING;

-- 允许所有认证用户上传视频
CREATE POLICY "Authenticated users can upload videos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'app-7fshtpomqha9_cms_videos');

-- 允许所有用户查看视频
CREATE POLICY "Anyone can view videos"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'app-7fshtpomqha9_cms_videos');

-- 允许用户删除自己上传的视频
CREATE POLICY "Users can delete their own videos"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'app-7fshtpomqha9_cms_videos' AND auth.uid() = owner);
/*
# Unify Welcome Notifications System

## Problem
Currently there are two separate welcome systems:
1. `send_welcome_notification()` - sends to notifications table
2. `send_welcome_message_on_register()` - sends to messages table

This causes duplicate welcome messages for new users.

## Solution
1. Drop the duplicate trigger `trigger_send_welcome_message`
2. Keep only `trigger_send_welcome_notification` for unified notification
3. Update `send_welcome_notification()` to send both notification and message
4. Ensure no duplicate welcome messages for new registrations

## Changes
- Drop trigger_send_welcome_message
- Update send_welcome_notification() to handle both notifications and messages
- Consolidate welcome message logic into one function
*/

-- Drop the duplicate welcome message trigger
DROP TRIGGER IF EXISTS trigger_send_welcome_message ON profiles;

-- Drop the old function
DROP FUNCTION IF EXISTS send_welcome_message_on_register();

-- Update send_welcome_notification to handle both notifications and messages
CREATE OR REPLACE FUNCTION send_welcome_notification()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
AS $$
DECLARE
  welcome_subject text;
  welcome_content text;
  welcome_settings jsonb;
  message_title text;
  message_content text;
  system_user_id uuid;
BEGIN
  -- Get system admin user ID (first admin user)
  SELECT id INTO system_user_id
  FROM profiles
  WHERE role = 'admin'
  ORDER BY created_at ASC
  LIMIT 1;
  
  -- If no admin exists, use the new user's ID as fallback
  IF system_user_id IS NULL THEN
    system_user_id := NEW.id;
  END IF;

  -- Get welcome message template from message_templates
  SELECT subject, content INTO welcome_subject, welcome_content
  FROM message_templates 
  WHERE template_key = 'welcome_message';
  
  -- Insert notification (always send)
  IF welcome_subject IS NOT NULL AND welcome_content IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, content, is_read)
    VALUES (NEW.id, 'system', welcome_subject, welcome_content, false);
  ELSE
    -- Use default welcome notification
    INSERT INTO notifications (user_id, type, title, content, is_read)
    VALUES (
      NEW.id, 
      'system', 
      'Welcome to iFixes Service Platform!', 
      'Dear ' || COALESCE(NEW.username, NEW.nickname, 'Member') || ',

Welcome to iFixes Service Platform!

We are delighted to have you join us. Here you can:
- Connect with technical experts online
- Get the latest technical information
- Enjoy exclusive member services

Tip: After verifying your email, you will automatically be upgraded to Silver membership with more privileges!

If you have any questions, please feel free to contact our customer service team.

Enjoy your experience!

iFixes Team',
      false
    );
  END IF;

  -- Get welcome message settings from system_settings
  SELECT setting_value INTO welcome_settings
  FROM system_settings
  WHERE setting_key = 'welcome_message_template';

  -- Send welcome message if enabled
  IF welcome_settings IS NOT NULL AND (welcome_settings->>'enabled')::boolean = true THEN
    message_title := welcome_settings->>'title';
    message_content := welcome_settings->>'content';
    
    -- Replace placeholders
    message_content := replace(message_content, '{username}', COALESCE(NEW.username, NEW.nickname, 'Member'));
    
    -- Insert welcome message
    IF message_title IS NOT NULL AND message_content IS NOT NULL THEN
      INSERT INTO messages (
        sender_id,
        receiver_id,
        title,
        content,
        message_type,
        is_read
      ) VALUES (
        system_user_id,
        NEW.id,
        message_title,
        message_content,
        'system',
        false
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

COMMENT ON FUNCTION send_welcome_notification() IS 'Unified function to send welcome notification and message to new members';

-- Ensure the trigger exists (recreate if needed)
DROP TRIGGER IF EXISTS trigger_send_welcome_notification ON profiles;

CREATE TRIGGER trigger_send_welcome_notification
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION send_welcome_notification();

COMMENT ON TRIGGER trigger_send_welcome_notification ON profiles IS 'Automatically send welcome notification and message when a new user registers';
/*
# Fix messages table column name issue

## Problem Description
Registration fails with error:
"ERROR: column "title" of relation "messages" does not exist (SQLSTATE 42703)"

## Root Cause
1. The actual messages table in database uses "subject" column
2. But migration 42 trigger functions use "title" column
3. This mismatch causes registration to fail when sending welcome messages

## Solution
Update all trigger functions that incorrectly use "title" to use the correct column name "subject"

## Changes
1. Fix send_welcome_message_on_register() function to use "subject"
2. Fix auto_upgrade_to_silver_on_email_verified() function to use "subject"
3. Ensure all message-related functions use consistent column names
*/

-- 1. Fix the welcome message trigger function
CREATE OR REPLACE FUNCTION send_welcome_message_on_register()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  welcome_settings jsonb;
  message_title text;
  message_content text;
BEGIN
  -- Get welcome message settings
  SELECT setting_value INTO welcome_settings
  FROM system_settings
  WHERE setting_key = 'welcome_message_template';

  -- Check if welcome message is enabled
  IF welcome_settings IS NOT NULL AND (welcome_settings->>'enabled')::boolean = true THEN
    -- Get message title and content
    message_title := welcome_settings->>'title';
    message_content := welcome_settings->>'content';
    
    -- Replace placeholders
    message_content := replace(message_content, '{username}', COALESCE(NEW.username, NEW.nickname, 'User'));
    
    -- Insert message (using correct column name "subject")
    INSERT INTO messages (
      sender_id,
      receiver_id,
      subject,
      content,
      message_type
    ) VALUES (
      NULL,  -- System message, sender_id is NULL
      NEW.id,
      message_title,
      message_content,
      'system'
    );
  END IF;

  RETURN NEW;
END;
$$;

-- 2. Fix the auto upgrade trigger function
CREATE OR REPLACE FUNCTION auto_upgrade_to_silver_on_email_verified()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Check if email was just verified (changed from false to true)
  IF NEW.email_verified = true AND (OLD.email_verified IS NULL OR OLD.email_verified = false) THEN
    -- If currently Bronze member, auto upgrade to Silver
    IF NEW.member_level = 'bronze' THEN
      NEW.member_level := 'silver';
      
      -- Send upgrade notification message (using correct column name "subject")
      INSERT INTO messages (
        sender_id,
        receiver_id,
        subject,
        content,
        message_type
      ) VALUES (
        NULL,
        NEW.id,
        'Congratulations! You have been upgraded to Silver Member',
        'Dear ' || COALESCE(NEW.username, NEW.nickname, 'User') || ',

Congratulations on successfully verifying your email!

Your membership level has been automatically upgraded to Silver Member. Now you can:
- Set up your personal homepage
- Enjoy more member privileges
- Get priority technical support

Thank you for your support!

The Team',
        'system'
      );
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- 3. Add comment for clarity
COMMENT ON COLUMN messages.subject IS 'Message title/subject';
COMMENT ON COLUMN messages.message_type IS 'Message type: system=System message, user=User message';
/*
# Fix Welcome Notification Column Names

## Problem Description
Migration 58 created a unified welcome notification function, but it has two critical errors:
1. Uses "title" column for messages table (should be "subject")
2. Uses "user_id" column for notifications table (should be "member_id")

## Root Cause
Migration 58 unified the welcome notification system but used incorrect column names:
- messages table: uses "title" instead of "subject"
- notifications table: uses "user_id" instead of "member_id"

## Solution
Update the send_welcome_notification() function to use correct column names

## Changes
1. Fix messages table INSERT to use "subject" instead of "title"
2. Fix notifications table INSERT to use "member_id" instead of "user_id"
*/

-- Update send_welcome_notification to use correct column names
CREATE OR REPLACE FUNCTION send_welcome_notification()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
AS $$
DECLARE
  welcome_subject text;
  welcome_content text;
  welcome_settings jsonb;
  message_title text;
  message_content text;
  system_user_id uuid;
BEGIN
  -- Get system admin user ID (first admin user)
  SELECT id INTO system_user_id
  FROM profiles
  WHERE role = 'admin'
  ORDER BY created_at ASC
  LIMIT 1;
  
  -- If no admin exists, use NULL for system messages
  IF system_user_id IS NULL THEN
    system_user_id := NULL;
  END IF;

  -- Get welcome message template from message_templates
  SELECT subject, content INTO welcome_subject, welcome_content
  FROM message_templates 
  WHERE template_key = 'welcome_message';
  
  -- Insert notification (always send) - using correct column "member_id"
  IF welcome_subject IS NOT NULL AND welcome_content IS NOT NULL THEN
    INSERT INTO notifications (member_id, type, title, content, is_read)
    VALUES (NEW.id, 'system', welcome_subject, welcome_content, false);
  ELSE
    -- Use default welcome notification
    INSERT INTO notifications (member_id, type, title, content, is_read)
    VALUES (
      NEW.id, 
      'system', 
      'Welcome to Our Community!', 
      'Dear ' || COALESCE(NEW.username, NEW.nickname, 'Member') || ',

Welcome to our community!

We are delighted to have you join us. Here you can:
- Connect with experts online
- Get the latest information
- Enjoy exclusive member services

Tip: After verifying your email, you will automatically be upgraded to Silver membership with more privileges!

If you have any questions, please feel free to contact our support team.

Enjoy your experience!

The Team',
      false
    );
  END IF;

  -- Get welcome message settings from system_settings
  SELECT setting_value INTO welcome_settings
  FROM system_settings
  WHERE setting_key = 'welcome_message_template';

  -- Send welcome message if enabled
  IF welcome_settings IS NOT NULL AND (welcome_settings->>'enabled')::boolean = true THEN
    message_title := welcome_settings->>'title';
    message_content := welcome_settings->>'content';
    
    -- Replace placeholders
    message_content := replace(message_content, '{username}', COALESCE(NEW.username, NEW.nickname, 'Member'));
    
    -- Insert welcome message - using correct column "subject"
    IF message_title IS NOT NULL AND message_content IS NOT NULL THEN
      INSERT INTO messages (
        sender_id,
        receiver_id,
        subject,
        content,
        message_type,
        is_read
      ) VALUES (
        system_user_id,
        NEW.id,
        message_title,
        message_content,
        'system',
        false
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

COMMENT ON FUNCTION send_welcome_notification() IS 'Unified function to send welcome notification and message to new members (fixed column names)';
/*
# 修复 notifications 表列名错误

## 问题描述
Migration 60 错误地将 notifications 表的列名从 user_id 改为 member_id
但实际上 notifications 表使用的就是 user_id 列

## 错误信息
ERROR: column "member_id" of relation "notifications" does not exist (SQLSTATE 42703)

## 实际表结构
notifications 表的列：
- id (uuid)
- user_id (uuid) ← 正确的列名
- type (text)
- title (text)
- content (text)
- related_type (text)
- related_id (uuid)
- is_read (boolean)
- created_at (timestamptz)

## 解决方案
将 send_welcome_notification() 函数中的 member_id 改回 user_id
保持 messages 表的 subject 列名不变（这个是正确的）

## 修改内容
1. 修复 notifications 表 INSERT 语句：member_id → user_id
2. 保持 messages 表 INSERT 语句：使用 subject（正确）
*/

-- 更新 send_welcome_notification 函数，使用正确的列名
CREATE OR REPLACE FUNCTION send_welcome_notification()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
AS $$
DECLARE
  welcome_subject text;
  welcome_content text;
  welcome_settings jsonb;
  message_title text;
  message_content text;
  system_user_id uuid;
BEGIN
  -- 获取系统管理员用户ID（第一个管理员用户）
  SELECT id INTO system_user_id
  FROM profiles
  WHERE role = 'admin'
  ORDER BY created_at ASC
  LIMIT 1;
  
  -- 如果没有管理员，使用 NULL 表示系统消息
  IF system_user_id IS NULL THEN
    system_user_id := NULL;
  END IF;

  -- 从 message_templates 获取欢迎消息模板
  SELECT subject, content INTO welcome_subject, welcome_content
  FROM message_templates 
  WHERE template_key = 'welcome_message';
  
  -- 插入通知（始终发送）- 使用正确的列名 "user_id"
  IF welcome_subject IS NOT NULL AND welcome_content IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, content, is_read)
    VALUES (NEW.id, 'system', welcome_subject, welcome_content, false);
  ELSE
    -- 使用默认欢迎通知
    INSERT INTO notifications (user_id, type, title, content, is_read)
    VALUES (
      NEW.id, 
      'system', 
      'Welcome to Our Community!', 
      'Dear ' || COALESCE(NEW.username, NEW.nickname, 'Member') || ',

Welcome to our community!

We are delighted to have you join us. Here you can:
- Connect with experts online
- Get the latest information
- Enjoy exclusive member services

Tip: After verifying your email, you will automatically be upgraded to Silver membership with more privileges!

If you have any questions, please feel free to contact our support team.

Enjoy your experience!

The Team',
      false
    );
  END IF;

  -- 从 system_settings 获取欢迎消息设置
  SELECT setting_value INTO welcome_settings
  FROM system_settings
  WHERE setting_key = 'welcome_message_template';

  -- 如果启用，发送欢迎消息
  IF welcome_settings IS NOT NULL AND (welcome_settings->>'enabled')::boolean = true THEN
    message_title := welcome_settings->>'title';
    message_content := welcome_settings->>'content';
    
    -- 替换占位符
    message_content := replace(message_content, '{username}', COALESCE(NEW.username, NEW.nickname, 'Member'));
    
    -- 插入欢迎消息 - 使用正确的列名 "subject"
    IF message_title IS NOT NULL AND message_content IS NOT NULL THEN
      INSERT INTO messages (
        sender_id,
        receiver_id,
        subject,
        content,
        message_type,
        is_read
      ) VALUES (
        system_user_id,
        NEW.id,
        message_title,
        message_content,
        'system',
        false
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

COMMENT ON FUNCTION send_welcome_notification() IS 'Unified function to send welcome notification and message to new members (fixed: notifications.user_id, messages.subject)';
/*
# 创建 SEO 管理表

## 1. 新增表

### seo_settings 表
全局 SEO 设置表，存储网站级别的 SEO 配置
- `id` (uuid, 主键)
- `site_title` (text) - 网站标题
- `site_description` (text) - 网站描述
- `site_keywords` (text) - 网站关键词
- `site_author` (text) - 网站作者
- `og_image` (text) - Open Graph 默认图片
- `twitter_handle` (text) - Twitter 账号
- `google_analytics_id` (text) - Google Analytics ID
- `google_search_console_id` (text) - Google Search Console ID
- `bing_webmaster_id` (text) - Bing Webmaster ID
- `robots_txt` (text) - robots.txt 内容
- `created_at`, `updated_at` (timestamptz)

### page_seo 表
页面级 SEO 设置表，存储每个页面的 SEO 配置
- `id` (uuid, 主键)
- `page_path` (text, 唯一) - 页面路径
- `page_title` (text) - 页面标题
- `page_description` (text) - 页面描述
- `page_keywords` (text) - 页面关键词
- `og_title`, `og_description`, `og_image` (text) - Open Graph 标签
- `twitter_title`, `twitter_description`, `twitter_image` (text) - Twitter Card 标签
- `canonical_url` (text) - 规范 URL
- `noindex`, `nofollow` (boolean) - 索引控制
- `priority` (decimal) - 站点地图优先级 (0.0-1.0)
- `change_frequency` (text) - 更新频率
- `created_at`, `updated_at` (timestamptz)

### redirects 表
URL 重定向管理表，存储 URL 重定向规则
- `id` (uuid, 主键)
- `from_path` (text, 唯一) - 源路径
- `to_path` (text) - 目标路径
- `redirect_type` (integer) - 重定向类型 (301, 302, 307, 308)
- `is_active` (boolean) - 是否启用
- `created_at`, `updated_at` (timestamptz)

## 2. 安全性
- 所有表都是公开的，任何人都可以读取
- 只有管理员可以修改

## 3. RPC 函数
- `get_seo_settings`: 获取全局 SEO 设置
- `update_seo_settings`: 更新全局 SEO 设置
- `get_page_seo`: 获取页面 SEO 设置
- `upsert_page_seo`: 创建或更新页面 SEO 设置
- `get_all_page_seo`: 获取所有页面 SEO 设置（用于生成站点地图）
- `get_active_redirects`: 获取所有启用的重定向规则
*/

-- 创建 seo_settings 表
CREATE TABLE IF NOT EXISTS seo_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_title text NOT NULL DEFAULT 'iFixes',
  site_description text NOT NULL DEFAULT 'Global leading mobile phone repair resource integration service provider',
  site_keywords text NOT NULL DEFAULT 'mobile phone repair, smartphone repair, screen repair, battery replacement',
  site_author text NOT NULL DEFAULT 'iFixes',
  og_image text,
  twitter_handle text,
  google_analytics_id text,
  google_search_console_id text,
  bing_webmaster_id text,
  robots_txt text NOT NULL DEFAULT 'User-agent: *
Allow: /
Sitemap: /sitemap.xml',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建 page_seo 表
CREATE TABLE IF NOT EXISTS page_seo (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_path text UNIQUE NOT NULL,
  page_title text,
  page_description text,
  page_keywords text,
  og_title text,
  og_description text,
  og_image text,
  twitter_title text,
  twitter_description text,
  twitter_image text,
  canonical_url text,
  noindex boolean DEFAULT false,
  nofollow boolean DEFAULT false,
  priority decimal(2,1) DEFAULT 0.5 CHECK (priority >= 0.0 AND priority <= 1.0),
  change_frequency text DEFAULT 'weekly' CHECK (change_frequency IN ('always', 'hourly', 'daily', 'weekly', 'monthly', 'yearly', 'never')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建 redirects 表
CREATE TABLE IF NOT EXISTS redirects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_path text UNIQUE NOT NULL,
  to_path text NOT NULL,
  redirect_type integer DEFAULT 301 CHECK (redirect_type IN (301, 302, 307, 308)),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 插入默认的全局 SEO 设置
INSERT INTO seo_settings (id, site_title, site_description, site_keywords, site_author)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'iFixes - Global Leading Mobile Phone Repair Resource Integration Service Provider',
  'iFixes provides comprehensive mobile phone repair resources, including repair guides, parts sourcing, technical support, and professional training for repair technicians worldwide.',
  'mobile phone repair, smartphone repair, screen repair, battery replacement, repair guides, repair parts, technical support, repair training',
  'iFixes'
)
ON CONFLICT (id) DO NOTHING;

-- 插入默认的页面 SEO 设置
INSERT INTO page_seo (page_path, page_title, page_description, priority, change_frequency) VALUES
('/', 'Home - iFixes', 'Welcome to iFixes, your trusted partner for mobile phone repair resources and services.', 1.0, 'daily'),
('/articles', 'Articles - iFixes', 'Browse our comprehensive collection of repair guides and technical articles.', 0.9, 'daily'),
('/products', 'Products - iFixes', 'Discover high-quality repair parts and tools for mobile phone repair.', 0.9, 'daily'),
('/questions', 'Q&A - iFixes', 'Get answers to your repair questions from our expert community.', 0.8, 'daily'),
('/downloads', 'Downloads - iFixes', 'Access repair manuals, software tools, and technical resources.', 0.8, 'weekly'),
('/videos', 'Videos - iFixes', 'Watch step-by-step repair tutorials and training videos.', 0.8, 'weekly'),
('/search', 'Search - iFixes', 'Search for repair guides, parts, and technical information.', 0.7, 'weekly')
ON CONFLICT (page_path) DO NOTHING;

-- 创建更新时间触发器函数
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 为所有表添加更新时间触发器
CREATE TRIGGER update_seo_settings_updated_at BEFORE UPDATE ON seo_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_page_seo_updated_at BEFORE UPDATE ON page_seo
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_redirects_updated_at BEFORE UPDATE ON redirects
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- RPC 函数：获取全局 SEO 设置
CREATE OR REPLACE FUNCTION get_seo_settings()
RETURNS TABLE (
  id uuid,
  site_title text,
  site_description text,
  site_keywords text,
  site_author text,
  og_image text,
  twitter_handle text,
  google_analytics_id text,
  google_search_console_id text,
  bing_webmaster_id text,
  robots_txt text,
  created_at timestamptz,
  updated_at timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT * FROM seo_settings
  ORDER BY created_at DESC
  LIMIT 1;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC 函数：更新全局 SEO 设置
CREATE OR REPLACE FUNCTION update_seo_settings(
  p_site_title text,
  p_site_description text,
  p_site_keywords text,
  p_site_author text,
  p_og_image text DEFAULT NULL,
  p_twitter_handle text DEFAULT NULL,
  p_google_analytics_id text DEFAULT NULL,
  p_google_search_console_id text DEFAULT NULL,
  p_bing_webmaster_id text DEFAULT NULL,
  p_robots_txt text DEFAULT NULL
)
RETURNS void AS $$
BEGIN
  UPDATE seo_settings
  SET
    site_title = p_site_title,
    site_description = p_site_description,
    site_keywords = p_site_keywords,
    site_author = p_site_author,
    og_image = COALESCE(p_og_image, og_image),
    twitter_handle = COALESCE(p_twitter_handle, twitter_handle),
    google_analytics_id = COALESCE(p_google_analytics_id, google_analytics_id),
    google_search_console_id = COALESCE(p_google_search_console_id, google_search_console_id),
    bing_webmaster_id = COALESCE(p_bing_webmaster_id, bing_webmaster_id),
    robots_txt = COALESCE(p_robots_txt, robots_txt),
    updated_at = now()
  WHERE id = '00000000-0000-0000-0000-000000000001';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC 函数：获取页面 SEO 设置
CREATE OR REPLACE FUNCTION get_page_seo(p_page_path text)
RETURNS TABLE (
  id uuid,
  page_path text,
  page_title text,
  page_description text,
  page_keywords text,
  og_title text,
  og_description text,
  og_image text,
  twitter_title text,
  twitter_description text,
  twitter_image text,
  canonical_url text,
  noindex boolean,
  nofollow boolean,
  priority decimal,
  change_frequency text,
  created_at timestamptz,
  updated_at timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT * FROM page_seo
  WHERE page_seo.page_path = p_page_path;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC 函数：创建或更新页面 SEO 设置
CREATE OR REPLACE FUNCTION upsert_page_seo(
  p_page_path text,
  p_page_title text DEFAULT NULL,
  p_page_description text DEFAULT NULL,
  p_page_keywords text DEFAULT NULL,
  p_og_title text DEFAULT NULL,
  p_og_description text DEFAULT NULL,
  p_og_image text DEFAULT NULL,
  p_twitter_title text DEFAULT NULL,
  p_twitter_description text DEFAULT NULL,
  p_twitter_image text DEFAULT NULL,
  p_canonical_url text DEFAULT NULL,
  p_noindex boolean DEFAULT false,
  p_nofollow boolean DEFAULT false,
  p_priority decimal DEFAULT 0.5,
  p_change_frequency text DEFAULT 'weekly'
)
RETURNS void AS $$
BEGIN
  INSERT INTO page_seo (
    page_path,
    page_title,
    page_description,
    page_keywords,
    og_title,
    og_description,
    og_image,
    twitter_title,
    twitter_description,
    twitter_image,
    canonical_url,
    noindex,
    nofollow,
    priority,
    change_frequency
  ) VALUES (
    p_page_path,
    p_page_title,
    p_page_description,
    p_page_keywords,
    p_og_title,
    p_og_description,
    p_og_image,
    p_twitter_title,
    p_twitter_description,
    p_twitter_image,
    p_canonical_url,
    p_noindex,
    p_nofollow,
    p_priority,
    p_change_frequency
  )
  ON CONFLICT (page_path) DO UPDATE SET
    page_title = COALESCE(EXCLUDED.page_title, page_seo.page_title),
    page_description = COALESCE(EXCLUDED.page_description, page_seo.page_description),
    page_keywords = COALESCE(EXCLUDED.page_keywords, page_seo.page_keywords),
    og_title = COALESCE(EXCLUDED.og_title, page_seo.og_title),
    og_description = COALESCE(EXCLUDED.og_description, page_seo.og_description),
    og_image = COALESCE(EXCLUDED.og_image, page_seo.og_image),
    twitter_title = COALESCE(EXCLUDED.twitter_title, page_seo.twitter_title),
    twitter_description = COALESCE(EXCLUDED.twitter_description, page_seo.twitter_description),
    twitter_image = COALESCE(EXCLUDED.twitter_image, page_seo.twitter_image),
    canonical_url = COALESCE(EXCLUDED.canonical_url, page_seo.canonical_url),
    noindex = EXCLUDED.noindex,
    nofollow = EXCLUDED.nofollow,
    priority = EXCLUDED.priority,
    change_frequency = EXCLUDED.change_frequency,
    updated_at = now();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC 函数：获取所有页面 SEO 设置（用于生成站点地图）
CREATE OR REPLACE FUNCTION get_all_page_seo()
RETURNS TABLE (
  page_path text,
  page_title text,
  priority decimal,
  change_frequency text,
  updated_at timestamptz,
  noindex boolean
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    page_seo.page_path,
    page_seo.page_title,
    page_seo.priority,
    page_seo.change_frequency,
    page_seo.updated_at,
    page_seo.noindex
  FROM page_seo
  WHERE page_seo.noindex = false
  ORDER BY page_seo.priority DESC, page_seo.page_path ASC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC 函数：获取所有启用的重定向规则
CREATE OR REPLACE FUNCTION get_active_redirects()
RETURNS TABLE (
  from_path text,
  to_path text,
  redirect_type integer
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    redirects.from_path,
    redirects.to_path,
    redirects.redirect_type
  FROM redirects
  WHERE redirects.is_active = true
  ORDER BY redirects.from_path ASC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
/*
# 为分类表添加显示选项字段

## 1. 新增字段
为 `categories` 表添加以下显示选项字段：
- `show_author` (boolean, default true) - 是否显示作者
- `show_date` (boolean, default true) - 是否显示日期
- `show_category` (boolean, default true) - 是否显示分类

## 2. 说明
这些字段用于控制分类列表页中内容的显示选项
*/

-- 添加显示选项字段
ALTER TABLE categories ADD COLUMN IF NOT EXISTS show_author boolean DEFAULT true NOT NULL;
ALTER TABLE categories ADD COLUMN IF NOT EXISTS show_date boolean DEFAULT true NOT NULL;
ALTER TABLE categories ADD COLUMN IF NOT EXISTS show_category boolean DEFAULT true NOT NULL;

-- 添加注释
COMMENT ON COLUMN categories.show_author IS '是否显示作者';
COMMENT ON COLUMN categories.show_date IS '是否显示日期';
COMMENT ON COLUMN categories.show_category IS '是否显示分类';
/*
# 添加内部配置获取函数

## 说明
- 创建 get_system_setting_internal 函数供 Edge Function 使用
- 不需要权限检查，因为 Edge Function 使用 service_role
- 保留原有的 get_system_setting 函数供前端使用
*/

-- 创建内部配置获取函数（供 Edge Function 使用）
CREATE OR REPLACE FUNCTION get_system_setting_internal(p_setting_key text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_setting_value jsonb;
BEGIN
  -- 不检查权限，因为 Edge Function 使用 service_role 调用
  SELECT setting_value INTO v_setting_value
  FROM system_settings
  WHERE setting_key = p_setting_key;

  RETURN COALESCE(v_setting_value, 'null'::jsonb);
END;
$$;

-- 添加注释
COMMENT ON FUNCTION get_system_setting_internal IS '内部配置获取函数，供 Edge Function 使用，不检查权限';
/*
# 创建系统配置表

## 1. 新增表
- `system_settings`
  - `id` (uuid, 主键)
  - `setting_key` (text, 唯一, 配置键名)
  - `setting_value` (jsonb, 配置值)
  - `category` (text, 配置分类)
  - `description` (text, 配置描述)
  - `is_encrypted` (boolean, 是否加密)
  - `created_at` (timestamptz, 创建时间)
  - `updated_at` (timestamptz, 更新时间)

## 2. 安全策略
- 启用 RLS
- 只允许管理员读取和修改配置

## 3. RPC 函数
- get_system_setting：获取单个配置
- set_system_setting：设置配置
- delete_system_setting：删除配置
- get_settings_by_category：获取分类下的所有配置
*/

-- 删除已存在的表（如果存在）
DROP TABLE IF EXISTS system_settings CASCADE;

-- 创建系统配置表
CREATE TABLE system_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value jsonb NOT NULL DEFAULT '{}'::jsonb,
  category text NOT NULL DEFAULT 'general',
  description text,
  is_encrypted boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX idx_system_settings_key ON system_settings(setting_key);
CREATE INDEX idx_system_settings_category ON system_settings(category);

-- 启用 RLS
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- 创建策略：只允许管理员访问
CREATE POLICY "管理员可以查看所有配置" ON system_settings
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "管理员可以修改所有配置" ON system_settings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- 创建更新时间触发器
CREATE OR REPLACE FUNCTION update_system_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER system_settings_updated_at
  BEFORE UPDATE ON system_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_system_settings_updated_at();

-- 创建 RPC 函数：获取配置
CREATE OR REPLACE FUNCTION get_system_setting(p_setting_key text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_setting_value jsonb;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION '权限不足';
  END IF;

  SELECT setting_value INTO v_setting_value
  FROM system_settings
  WHERE setting_key = p_setting_key;

  RETURN COALESCE(v_setting_value, '{}'::jsonb);
END;
$$;

-- 创建 RPC 函数：设置配置
CREATE OR REPLACE FUNCTION set_system_setting(
  p_setting_key text,
  p_setting_value jsonb,
  p_category text DEFAULT 'general',
  p_description text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION '权限不足';
  END IF;

  INSERT INTO system_settings (setting_key, setting_value, category, description)
  VALUES (p_setting_key, p_setting_value, p_category, p_description)
  ON CONFLICT (setting_key)
  DO UPDATE SET
    setting_value = p_setting_value,
    category = p_category,
    description = COALESCE(p_description, system_settings.description),
    updated_at = now();
END;
$$;

-- 创建 RPC 函数：删除配置
CREATE OR REPLACE FUNCTION delete_system_setting(p_setting_key text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION '权限不足';
  END IF;

  DELETE FROM system_settings WHERE setting_key = p_setting_key;
END;
$$;

-- 创建 RPC 函数：获取分类下的所有配置
CREATE OR REPLACE FUNCTION get_settings_by_category(p_category text)
RETURNS TABLE (
  setting_key text,
  setting_value jsonb,
  description text,
  updated_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION '权限不足';
  END IF;

  RETURN QUERY
  SELECT
    s.setting_key,
    s.setting_value,
    s.description,
    s.updated_at
  FROM system_settings s
  WHERE s.category = p_category
  ORDER BY s.setting_key;
END;
$$;

-- 插入默认翻译配置
INSERT INTO system_settings (setting_key, setting_value, category, description) VALUES
  ('translation.baidu.app_id', '""'::jsonb, 'translation', '百度翻译 APP ID'),
  ('translation.baidu.secret_key', '""'::jsonb, 'translation', '百度翻译密钥'),
  ('translation.enabled', 'true'::jsonb, 'translation', '是否启用自动翻译'),
  ('translation.quality', '"high"'::jsonb, 'translation', '翻译质量（high/standard）'),
  ('translation.cache_enabled', 'true'::jsonb, 'translation', '是否启用翻译缓存'),
  ('translation.cache_ttl', '2592000'::jsonb, 'translation', '缓存过期时间（秒，默认30天）'),
  ('translation.auto_translate', 'true'::jsonb, 'translation', '是否自动翻译未找到的文本'),
  ('translation.fallback_lang', '"en"'::jsonb, 'translation', '备用语言'),
  ('translation.rate_limit', '100'::jsonb, 'translation', 'API 调用频率限制（次/分钟）'),
  ('translation.log_enabled', 'true'::jsonb, 'translation', '是否记录翻译日志'),
  ('translation.review_required', 'false'::jsonb, 'translation', '新翻译是否需要审核'),
  ('translation.supported_languages', '["en","zh","zh-TW","ja","ko","es","fr","de","ru","pt","it","ar"]'::jsonb, 'translation', '支持的语言列表');
