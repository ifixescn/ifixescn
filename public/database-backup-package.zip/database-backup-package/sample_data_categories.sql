-- ================================================================
-- Sample Data: Categories
-- ================================================================
-- This file contains sample category data for the iFixes application
-- Categories are used across multiple content types: articles, products, videos, downloads, questions
-- ================================================================

-- Note: This is sample data. Adjust IDs and content as needed for your application.

-- Product Categories
INSERT INTO categories (id, name, slug, type, description, created_at, updated_at, items_per_page, sort_order, is_enabled, show_author, show_date, show_category) VALUES
('9005ae46-c441-47d9-9c3c-7341c62eabe3', 'Screwdriver & Tweezer', 'Screwdriver-Tweezer', 'product', 'Cell phone repair hand tools', NOW(), NOW(), 12, 1, true, false, true, true),
('e67928cf-30be-4ec4-889e-6ac609473b2f', 'Glue & Adhesive', 'Glue-Adhesive', 'product', 'Repair of digital products', NOW(), NOW(), 12, 2, true, false, true, true),
('ea348f48-c708-4dd9-acc5-49792a733ad0', 'Blade & Grinder', 'Blade-Grinder', 'product', 'Specialized for polishing and cutting', NOW(), NOW(), 12, 3, true, false, true, true),
('827df22a-4bb5-4417-b1ad-996bc6cd588d', 'Screen Tool', 'Screen-Tool', 'product', 'Tools for repairing cell phone screens', NOW(), NOW(), 12, 4, true, false, true, true),
('f9e212f8-cbf8-4ec3-9af8-f7efd579f963', 'Dis/Assemble Tool', 'DisAssemble-Tool', 'product', 'Tools required for disassembling', NOW(), NOW(), 12, 5, true, false, true, true),
('73fdaa4c-f9bb-4f0f-9827-0bb14e4e2317', 'Soldering Consumables', 'Soldering-Consumables', 'product', 'Consumables required for motherboard soldering', NOW(), NOW(), 12, 6, true, false, true, true),
('bea87fd7-8980-441c-9e8e-25d6036de803', 'Micro Soldering', 'Micro-Soldering', 'product', 'Welding micro devices and tools', NOW(), NOW(), 12, 7, true, false, true, true),
('e882f028-4cd1-4d0f-902b-e2289801fd24', 'Microscope Equipment', 'Microscope-Equipment', 'product', 'Microscope and peripheral accessories', NOW(), NOW(), 12, 8, true, false, true, true),
('e1e26fae-9af8-4672-ae52-e98f911af8f2', 'Board Holder & Preheater', 'Board-Holder-Preheater', 'product', 'Heating equipment and pressure holding tools', NOW(), NOW(), 12, 9, true, false, true, true),
('b92b2a1a-b2da-423a-ac3b-9816f905f071', 'Testing & Charging', 'Testing-Charging', 'product', 'Testing tools and battery accessories', NOW(), NOW(), 12, 10, true, false, true, true),
('966f008e-c5b4-495c-bc13-a8fb08f8445d', 'Organizer', 'Organizer', 'product', 'Repair tool kit and accessories', NOW(), NOW(), 12, 11, true, false, true, true),
('10f2f873-0c9d-4a7c-ac41-98c77bc673e0', 'Cleaning Tool', 'Cleaning-Tool', 'product', 'Cleaning tools and cleaning agents', NOW(), NOW(), 12, 12, true, false, true, true)
ON CONFLICT (id) DO NOTHING;

-- Article Categories
INSERT INTO categories (id, name, slug, type, description, created_at, updated_at, items_per_page, sort_order, is_enabled, show_author, show_date, show_category) VALUES
('3e48c97c-75b3-410d-873b-dc97e4053d67', 'Guides', 'guides', 'article', 'Cell phone repair guides', NOW(), NOW(), 10, 1, true, true, true, true),
('749ba4ef-ad43-4a4b-a9fb-8b44186c7970', 'News', 'news', 'article', 'Latest industry news', NOW(), NOW(), 10, 2, true, true, true, true),
('3da24a8a-b652-4b69-a3f6-42b034e794c2', 'Blog', 'blog', 'article', 'Technical blog posts', NOW(), NOW(), 10, 3, true, true, true, true),
('a3d51711-4268-480a-9733-70941ef08159', 'Notice', 'notice', 'article', 'Official notices and announcements', NOW(), NOW(), 10, 4, true, true, true, true)
ON CONFLICT (id) DO NOTHING;

-- Video Categories
INSERT INTO categories (id, name, slug, type, description, created_at, updated_at, items_per_page, sort_order, is_enabled, show_author, show_date, show_category) VALUES
('2a82a72b-8d33-4ea1-acab-27f0e68ecfbf', 'Tutorials', 'video-tutorials', 'video', 'Step-by-step video tutorials', NOW(), NOW(), 12, 1, true, false, true, true),
('11ba65a2-4601-40ee-a9dd-5eea26521b10', 'Demos', 'video-demos', 'video', 'Product demonstrations and showcases', NOW(), NOW(), 12, 2, true, false, true, true),
('0046b0e4-0aa1-4f7c-a9e2-9c41fe474c77', 'Webinars', 'video-webinars', 'video', 'Recorded webinars and presentations', NOW(), NOW(), 12, 3, true, false, true, true),
('47730c1f-8519-43f0-9791-30eb3a3cd740', 'Training', 'video-training', 'video', 'Professional training courses', NOW(), NOW(), 12, 4, true, false, true, true)
ON CONFLICT (id) DO NOTHING;

-- Download Categories
INSERT INTO categories (id, name, slug, type, description, created_at, updated_at, items_per_page, sort_order, is_enabled, show_author, show_date, show_category) VALUES
('160a77be-dd01-4109-9a58-8d6a2d1d8886', 'Software Downloads', 'download-software', 'download', 'Software packages and installers', NOW(), NOW(), 12, 1, true, false, true, true),
('e182b1c8-2a4a-4dd7-af86-62c9ecc5a01f', 'Doc & Data', 'doc-data', 'download', 'Download documents and data', NOW(), NOW(), 12, 2, true, false, true, true),
('b7726b91-3a97-4ad8-be85-b2aefc888b26', 'Product Images', 'product-images', 'download', 'E-commerce image package download', NOW(), NOW(), 12, 3, true, false, true, true)
ON CONFLICT (id) DO NOTHING;

-- Question Categories
INSERT INTO categories (id, name, slug, type, description, created_at, updated_at, items_per_page, sort_order, is_enabled, show_author, show_date, show_category) VALUES
('593bc04e-1686-4e42-abbf-55e596f208f1', 'Technical Support', 'question-technical-support', 'question', 'Technical questions and troubleshooting', NOW(), NOW(), 15, 1, true, true, true, true),
('e0a74dff-b138-4537-af4d-2c69deecf4c2', 'General Inquiry', 'question-general-inquiry', 'question', 'General questions and information', NOW(), NOW(), 15, 2, true, true, true, true),
('167ef9d0-800c-4e40-a399-27bb4fa52014', 'Feature Request', 'question-feature-request', 'question', 'Feature suggestions and requests', NOW(), NOW(), 15, 3, true, true, true, true),
('d5f8ce1d-dc26-4a13-8fc8-b8adb68089d5', 'Best Practices', 'question-best-practices', 'question', 'Best practices and recommendations', NOW(), NOW(), 15, 4, true, true, true, true)
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- End of Sample Data: Categories
-- ================================================================
