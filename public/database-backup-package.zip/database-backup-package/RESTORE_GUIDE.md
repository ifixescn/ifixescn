# Database Restoration Guide

## Prerequisites

### System Requirements
- PostgreSQL 12+ or Supabase project
- psql command-line tool (for PostgreSQL)
- Supabase CLI (for Supabase projects)
- Sufficient database storage space (~500MB recommended)

### Before You Start
1. ✅ Backup existing database (if any)
2. ✅ Verify PostgreSQL/Supabase version compatibility
3. ✅ Ensure you have admin/superuser access
4. ✅ Review the database structure in TABLE_LIST.md
5. ✅ Prepare environment variables and configuration

## Restoration Methods

### Method 1: Supabase Project (Recommended)

#### Step 1: Create New Supabase Project
```bash
# Login to Supabase
supabase login

# Initialize project
supabase init

# Link to your Supabase project
supabase link --project-ref your-project-ref
```

#### Step 2: Apply Database Structure
```bash
# Copy migrations to your project
cp database_structure.sql supabase/migrations/00001_initial_schema.sql

# Apply migrations
supabase db reset

# Or push to remote
supabase db push
```

#### Step 3: Verify Installation
```bash
# Check database status
supabase db status

# Run tests
supabase test db
```

### Method 2: PostgreSQL Database

#### Step 1: Create Database
```bash
# Create new database
createdb ifixes_db

# Or using psql
psql -U postgres -c "CREATE DATABASE ifixes_db;"
```

#### Step 2: Restore Structure
```bash
# Restore database structure
psql -U postgres -d ifixes_db -f database_structure.sql

# Check for errors
echo $?  # Should return 0 if successful
```

#### Step 3: Import Sample Data (Optional)
```bash
# Import categories
psql -U postgres -d ifixes_db -f sample_data_categories.sql

# Import site settings
psql -U postgres -d ifixes_db -f sample_data_site_settings.sql

# Import module settings
psql -U postgres -d ifixes_db -f sample_data_module_settings.sql

# Import SEO settings
psql -U postgres -d ifixes_db -f sample_data_seo_settings.sql
```

### Method 3: Docker PostgreSQL

#### Step 1: Start PostgreSQL Container
```bash
# Run PostgreSQL in Docker
docker run -d \
  --name ifixes-postgres \
  -e POSTGRES_PASSWORD=your_password \
  -e POSTGRES_DB=ifixes_db \
  -p 5432:5432 \
  -v pgdata:/var/lib/postgresql/data \
  postgres:15
```

#### Step 2: Copy SQL Files to Container
```bash
# Copy database structure
docker cp database_structure.sql ifixes-postgres:/tmp/

# Copy sample data files
docker cp sample_data_*.sql ifixes-postgres:/tmp/
```

#### Step 3: Execute SQL Files
```bash
# Restore structure
docker exec -i ifixes-postgres psql -U postgres -d ifixes_db -f /tmp/database_structure.sql

# Import sample data
docker exec -i ifixes-postgres psql -U postgres -d ifixes_db -f /tmp/sample_data_categories.sql
```

## Post-Restoration Steps

### 1. Verify Table Creation
```sql
-- Connect to database
psql -U postgres -d ifixes_db

-- Check table count (should be 60)
SELECT COUNT(*) as table_count
FROM information_schema.tables
WHERE table_schema = 'public' AND table_type = 'BASE TABLE';

-- List all tables
\dt

-- Check specific table structure
\d articles
\d products
\d profiles
```

### 2. Verify Indexes
```sql
-- Check indexes
SELECT 
  schemaname,
  tablename,
  indexname,
  indexdef
FROM pg_indexes
WHERE schemaname = 'public'
ORDER BY tablename, indexname;
```

### 3. Verify Foreign Keys
```sql
-- Check foreign key constraints
SELECT
  tc.table_name,
  kcu.column_name,
  ccu.table_name AS foreign_table_name,
  ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
  ON ccu.constraint_name = tc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND tc.table_schema = 'public'
ORDER BY tc.table_name;
```

### 4. Verify RLS Policies
```sql
-- Check RLS policies
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, policyname;

-- Check if RLS is enabled
SELECT 
  schemaname,
  tablename,
  rowsecurity
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY tablename;
```

### 5. Configure Application Connection

#### For Supabase
```env
# .env file
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

#### For PostgreSQL
```env
# .env file
DATABASE_URL=postgresql://user:password@localhost:5432/ifixes_db
```

### 6. Test Database Connection
```javascript
// Test connection in your application
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY
);

// Test query
const { data, error } = await supabase
  .from('site_settings')
  .select('*')
  .limit(1);

if (error) {
  console.error('Database connection failed:', error);
} else {
  console.log('Database connected successfully!');
}
```

## Troubleshooting

### Issue 1: Permission Denied
```bash
# Grant necessary permissions
GRANT ALL PRIVILEGES ON DATABASE ifixes_db TO your_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO your_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO your_user;
```

### Issue 2: Extension Not Found
```sql
-- Install required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For full-text search
```

### Issue 3: RLS Blocking Queries
```sql
-- Temporarily disable RLS for testing (NOT for production)
ALTER TABLE articles DISABLE ROW LEVEL SECURITY;

-- Re-enable after testing
ALTER TABLE articles ENABLE ROW LEVEL SECURITY;

-- Or bypass RLS for specific role
ALTER TABLE articles FORCE ROW LEVEL SECURITY;
GRANT BYPASSRLS ON TABLE articles TO admin_role;
```

### Issue 4: Foreign Key Violations
```sql
-- Check for orphaned records
SELECT a.id, a.category_id
FROM articles a
LEFT JOIN categories c ON a.category_id = c.id
WHERE a.category_id IS NOT NULL AND c.id IS NULL;

-- Fix orphaned records
UPDATE articles SET category_id = NULL
WHERE category_id NOT IN (SELECT id FROM categories);
```

### Issue 5: Sequence Reset Needed
```sql
-- Reset sequences after manual data import
SELECT setval(pg_get_serial_sequence('table_name', 'id'), 
  (SELECT MAX(id) FROM table_name));

-- Or reset all sequences
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN 
    SELECT table_name FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
  LOOP
    EXECUTE 'SELECT setval(pg_get_serial_sequence(''' || r.table_name || ''', ''id''), 
      COALESCE((SELECT MAX(id) FROM ' || r.table_name || '), 1))';
  END LOOP;
END $$;
```

## Data Migration

### Migrating Existing Data

#### Step 1: Export Data from Old Database
```bash
# Export all data
pg_dump -U postgres -d old_database --data-only --inserts -f data_export.sql

# Or export specific tables
pg_dump -U postgres -d old_database -t articles -t products --data-only --inserts -f content_export.sql
```

#### Step 2: Clean and Prepare Data
```bash
# Remove problematic statements
sed -i '/^SET /d' data_export.sql
sed -i '/^SELECT pg_catalog/d' data_export.sql
```

#### Step 3: Import Data
```bash
# Import to new database
psql -U postgres -d ifixes_db -f data_export.sql
```

### Bulk Data Import

#### Using COPY Command
```sql
-- Import from CSV
COPY articles(id, title, slug, content, status, created_at)
FROM '/path/to/articles.csv'
DELIMITER ','
CSV HEADER;
```

#### Using INSERT Statements
```sql
-- Disable triggers for faster import
ALTER TABLE articles DISABLE TRIGGER ALL;

-- Import data
INSERT INTO articles (id, title, slug, content, status) VALUES
  ('uuid-1', 'Title 1', 'slug-1', 'Content 1', 'published'),
  ('uuid-2', 'Title 2', 'slug-2', 'Content 2', 'published');

-- Re-enable triggers
ALTER TABLE articles ENABLE TRIGGER ALL;
```

## Performance Optimization

### After Restoration

```sql
-- Analyze tables for query optimization
ANALYZE;

-- Vacuum tables to reclaim space
VACUUM ANALYZE;

-- Reindex if needed
REINDEX DATABASE ifixes_db;
```

### Create Additional Indexes
```sql
-- Add custom indexes based on your query patterns
CREATE INDEX idx_articles_published_at ON articles(published_at DESC) 
  WHERE status = 'published';

CREATE INDEX idx_products_featured ON products(is_featured) 
  WHERE is_featured = true;

CREATE INDEX idx_questions_status_created ON questions(status, created_at DESC);
```

## Backup After Restoration

### Create Backup
```bash
# Full backup
pg_dump -U postgres -d ifixes_db -F c -f ifixes_backup_$(date +%Y%m%d).dump

# Structure only
pg_dump -U postgres -d ifixes_db --schema-only -f ifixes_structure_$(date +%Y%m%d).sql

# Data only
pg_dump -U postgres -d ifixes_db --data-only -f ifixes_data_$(date +%Y%m%d).sql
```

### Automated Backups
```bash
# Create backup script
cat > backup.sh << 'SCRIPT'
#!/bin/bash
BACKUP_DIR="/backups"
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump -U postgres -d ifixes_db -F c -f "$BACKUP_DIR/ifixes_$DATE.dump"
# Keep only last 7 days
find $BACKUP_DIR -name "ifixes_*.dump" -mtime +7 -delete
SCRIPT

chmod +x backup.sh

# Add to crontab (daily at 2 AM)
echo "0 2 * * * /path/to/backup.sh" | crontab -
```

## Security Checklist

After restoration, ensure:

- [ ] RLS is enabled on all tables
- [ ] Default admin user is created with strong password
- [ ] Database connection uses SSL/TLS
- [ ] Sensitive data is encrypted
- [ ] Backup encryption is enabled
- [ ] Access logs are enabled
- [ ] Regular security audits are scheduled

## Next Steps

1. ✅ Configure application environment variables
2. ✅ Set up authentication providers
3. ✅ Create initial admin user
4. ✅ Configure storage buckets (if using Supabase)
5. ✅ Set up Edge Functions (if needed)
6. ✅ Configure email templates
7. ✅ Test all application features
8. ✅ Set up monitoring and alerts
9. ✅ Schedule regular backups
10. ✅ Document custom configurations

## Support

For additional help:
- Review README.md for package overview
- Check TABLE_LIST.md for table details
- Consult PostgreSQL documentation
- Visit Supabase documentation (if using Supabase)

---

**Guide Version**: 1.0.0  
**Last Updated**: 2026-02-27
