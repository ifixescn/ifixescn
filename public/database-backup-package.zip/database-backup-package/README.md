# iFixes Application Database Backup Package

## 📦 Package Information

**Application Name**: iFixes Cell Phone Repair Tool  
**Backup Date**: 2026-02-27  
**Database Type**: PostgreSQL (Supabase)  
**Total Tables**: 60  
**Package Version**: v1.0.0

## 📁 Package Contents

### 1. Database Structure
- **database_structure.sql** - Complete database schema (DDL)
  - All table definitions
  - Indexes and constraints
  - Foreign key relationships
  - Triggers and functions
  - Row Level Security (RLS) policies
  - Size: ~441KB

### 2. Sample Data Exports
- **sample_data_categories.sql** - Category data
- **sample_data_site_settings.sql** - Site configuration
- **sample_data_module_settings.sql** - Module settings
- **sample_data_seo_settings.sql** - SEO configuration

### 3. Documentation
- **README.md** - This file
- **TABLE_LIST.md** - Complete list of all tables
- **RESTORE_GUIDE.md** - Database restoration guide

## 🗄️ Database Tables (60 Total)

### Core Tables
1. **site_settings** - Site configuration
2. **seo_settings** - SEO settings
3. **system_settings** - System configuration
4. **module_settings** - Module configuration

### Content Management
5. **articles** - Article content
6. **products** - Product information
7. **videos** - Video content
8. **downloads** - Download resources
9. **questions** - Q&A questions
10. **answers** - Q&A answers
11. **categories** - Content categories
12. **banners** - Banner images
13. **slides** - Slideshow content

### User Management
14. **profiles** - User profiles
15. **member_levels** - Member level system
16. **member_points_log** - Points transaction log
17. **points_rules** - Points rules configuration
18. **follows** - User follow relationships
19. **member_follows** - Member follow system
20. **privacy_settings** - User privacy settings

### Community Features
21. **blogs** - Blog posts
22. **blog_comments** - Blog comments
23. **blog_likes** - Blog likes
24. **member_posts** - Member posts
25. **post_comments** - Post comments
26. **post_likes** - Post likes
27. **groups** - User groups
28. **group_members** - Group membership
29. **group_posts** - Group posts

### Communication
30. **messages** - System messages
31. **direct_messages** - Direct messages
32. **notifications** - User notifications
33. **message_templates** - Message templates

### Analytics & Tracking
34. **analytics** - Analytics data
35. **analytics_summary** - Analytics summary
36. **page_views** - Page view tracking
37. **visitor_sessions** - Visitor sessions
38. **browsing_history** - User browsing history
39. **search_keywords** - Search keyword tracking

### Media Management
40. **albums** - Photo albums
41. **album_photos** - Album photos
42. **product_images** - Product images

### AI Features
43. **ai_article_generations** - AI article generation records
44. **ai_article_templates** - AI article templates
45. **ai_batch_generations** - AI batch generation tasks

### Web Scraping
46. **scraper_rules** - Scraper rules
47. **scraper_history** - Scraper execution history
48. **scraper_request_logs** - Scraper request logs

### SEO & Verification
49. **page_seo** - Page-level SEO settings
50. **redirects** - URL redirects
51. **verification_files** - Site verification files

### Yiyuan Chemical (Custom Module)
52. **yiyuan_content** - Yiyuan page content
53. **yiyuan_manufacturer** - Manufacturer information
54. **yiyuan_products** - Yiyuan products
55. **yiyuan_verification_guide** - Verification guide

### System & Security
56. **admin_operation_logs** - Admin operation logs
57. **profile_management_logs** - Profile management logs
58. **email_verification_codes** - Email verification
59. **member_submissions** - Member submissions
60. **wechat_configs** - WeChat configuration
61. **templates** - Template management

## 🔧 Database Features

### Security Features
- ✅ Row Level Security (RLS) enabled on all tables
- ✅ Role-based access control (Admin, Editor, Member, Guest)
- ✅ Secure authentication with Supabase Auth
- ✅ Email verification system
- ✅ Privacy settings management

### Performance Optimizations
- ✅ Indexes on frequently queried columns
- ✅ Foreign key constraints for data integrity
- ✅ Optimized query patterns
- ✅ Efficient pagination support

### Data Integrity
- ✅ Foreign key relationships
- ✅ NOT NULL constraints
- ✅ UNIQUE constraints
- ✅ CHECK constraints
- ✅ Default values
- ✅ Automatic timestamps (created_at, updated_at)

### Advanced Features
- ✅ Full-text search support
- ✅ Multi-language content support
- ✅ Content versioning
- ✅ Soft delete capability
- ✅ Analytics tracking
- ✅ Real-time subscriptions

## 📊 Database Statistics

### Content Statistics
- Articles: Dynamic content management
- Products: E-commerce ready
- Videos: Video library support
- Q&A: Community Q&A system
- Downloads: Resource distribution

### User Statistics
- User profiles with levels
- Points and rewards system
- Social features (follow, like, comment)
- Group and community features
- Direct messaging system

### Analytics
- Page view tracking
- Visitor session tracking
- Search keyword analysis
- User behavior tracking
- Content performance metrics

## 🚀 Quick Start

### 1. Restore Database Structure

```bash
# Using psql
psql -h your-db-host -U your-username -d your-database -f database_structure.sql

# Using Supabase CLI
supabase db reset
# Then apply migrations manually
```

### 2. Import Sample Data (Optional)

```bash
# Import categories
psql -h your-db-host -U your-username -d your-database -f sample_data_categories.sql

# Import site settings
psql -h your-db-host -U your-username -d your-database -f sample_data_site_settings.sql
```

### 3. Verify Installation

```sql
-- Check table count
SELECT COUNT(*) FROM information_schema.tables 
WHERE table_schema = 'public' AND table_type = 'BASE TABLE';

-- Check RLS policies
SELECT schemaname, tablename, policyname 
FROM pg_policies 
WHERE schemaname = 'public';
```

## 📝 Important Notes

### Before Restoration
1. **Backup existing data** if restoring to an existing database
2. **Check PostgreSQL version** compatibility (requires PostgreSQL 12+)
3. **Verify Supabase extensions** are installed (uuid-ossp, pgcrypto, etc.)
4. **Review RLS policies** and adjust for your security requirements

### After Restoration
1. **Update Supabase project settings** in your application
2. **Configure authentication providers** (email, OAuth, etc.)
3. **Set up storage buckets** for file uploads
4. **Test all RLS policies** with different user roles
5. **Verify foreign key relationships** are working correctly

### Data Migration
- This package includes **structure only** by default
- Sample data is provided for configuration tables
- User data and content should be migrated separately
- Use appropriate tools for large data migrations

## 🔒 Security Considerations

### RLS Policies
All tables have Row Level Security enabled with policies for:
- **Public read access** for published content
- **Authenticated user access** for user-specific data
- **Admin full access** for administrative operations
- **Owner-only access** for private user data

### Sensitive Data
- Passwords are hashed using Supabase Auth
- Email verification codes are time-limited
- API keys and secrets should be stored in environment variables
- Personal data follows privacy regulations

## 🛠️ Maintenance

### Regular Tasks
1. **Vacuum and analyze** tables regularly
2. **Monitor index usage** and optimize as needed
3. **Review and archive** old analytics data
4. **Clean up** expired verification codes
5. **Backup database** regularly

### Performance Monitoring
```sql
-- Check table sizes
SELECT 
  schemaname,
  tablename,
  pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;

-- Check index usage
SELECT 
  schemaname,
  tablename,
  indexname,
  idx_scan,
  idx_tup_read,
  idx_tup_fetch
FROM pg_stat_user_indexes
WHERE schemaname = 'public'
ORDER BY idx_scan DESC;
```

## 📞 Support

For issues or questions:
1. Check the **RESTORE_GUIDE.md** for detailed instructions
2. Review the **TABLE_LIST.md** for table relationships
3. Consult Supabase documentation for platform-specific issues
4. Contact technical support team

## 📄 License

Copyright © 2026 Shenzhen Hongdabiao Technology Co., Ltd. - iFixes  
All rights reserved.

## 📅 Version History

### v1.0.0 (2026-02-27)
- Initial database backup package
- Complete schema export (60 tables)
- Sample data for configuration tables
- Comprehensive documentation

---

**Package Created**: 2026-02-27  
**Database Version**: PostgreSQL 15+  
**Supabase Compatible**: Yes  
**Total Size**: ~500KB (structure + docs)
