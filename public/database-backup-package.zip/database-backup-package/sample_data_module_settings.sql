-- ================================================================
-- Sample Data: Module Settings
-- ================================================================
-- This file contains sample module configuration data
-- ================================================================

INSERT INTO module_settings (module_type, display_name, is_enabled, show_in_nav, sort_order, custom_settings, created_at, updated_at) VALUES
('articles', 'Articles', true, true, 1, '{"require_login_to_view": false, "allow_comments": true}', NOW(), NOW()),
('products', 'Products', true, true, 2, '{"show_price": true, "require_login_to_view": false}', NOW(), NOW()),
('video', 'Videos', true, true, 3, '{"require_login_to_watch": false, "allow_comments": true}', NOW(), NOW()),
('download', 'Downloads', true, true, 4, '{"require_login_to_download": false, "track_downloads": true}', NOW(), NOW()),
('questions', 'Q&A', true, true, 5, '{"allow_guest_questions": true, "require_approval": false}', NOW(), NOW())
ON CONFLICT (module_type) DO UPDATE SET
  display_name = EXCLUDED.display_name,
  is_enabled = EXCLUDED.is_enabled,
  show_in_nav = EXCLUDED.show_in_nav,
  sort_order = EXCLUDED.sort_order,
  custom_settings = EXCLUDED.custom_settings,
  updated_at = NOW();

-- ================================================================
-- End of Sample Data: Module Settings
-- ================================================================
