-- ================================================================
-- Sample Data: SEO Settings
-- ================================================================
-- This file contains sample SEO configuration data
-- ================================================================

INSERT INTO seo_settings (
  site_title,
  site_description,
  site_keywords,
  og_title,
  og_description,
  og_image,
  twitter_card,
  twitter_site,
  google_analytics_id,
  google_site_verification,
  baidu_site_verification,
  robots_txt,
  created_at,
  updated_at
) VALUES (
  'iFixes - Mobile Phone Repair Tools & Resources',
  'Global leading mobile phone repair resource integration service provider. Find repair guides, parts, tools, and expert community support.',
  'mobile phone repair, smartphone repair, repair guides, repair parts, repair tools, repair community, iFixes',
  'iFixes - Professional Mobile Phone Repair Solutions',
  'Discover comprehensive mobile phone repair resources, tools, and expert guidance for professional technicians and DIY enthusiasts.',
  '',
  'summary_large_image',
  '@iFixes',
  '',
  '',
  '',
  'User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/
Sitemap: https://yourdomain.com/sitemap.xml',
  NOW(),
  NOW()
)
ON CONFLICT DO NOTHING;

-- ================================================================
-- End of Sample Data: SEO Settings
-- ================================================================
