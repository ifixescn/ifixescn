# Complete Database Table List

## Table Overview

Total Tables: 60

## Tables by Category

### 1. System Configuration (4 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| site_settings | Site-wide configuration | key, value, type |
| seo_settings | SEO configuration | site_title, site_description, site_keywords |
| system_settings | System-level settings | setting_key, setting_value |
| module_settings | Module configuration | module_type, display_name, is_enabled |

### 2. Content Management (9 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| articles | Article content | id, title, slug, content, status |
| products | Product information | id, name, slug, price, status |
| videos | Video content | id, title, video_url, duration |
| downloads | Download resources | id, title, file_url, file_size |
| questions | Q&A questions | id, title, content, status |
| answers | Q&A answers | id, question_id, content |
| categories | Content categories | id, name, slug, type |
| banners | Banner images | id, title, image_url, link_url |
| slides | Slideshow content | id, title, image_url, sort_order |

### 3. User Management (7 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| profiles | User profiles | id, user_id, username, email |
| member_levels | Member level system | id, name, min_points, max_points |
| member_points_log | Points transaction log | id, user_id, points, action_type |
| points_rules | Points rules | id, action_type, points, description |
| follows | User follow relationships | id, follower_id, following_id |
| member_follows | Member follow system | id, follower_id, followed_id |
| privacy_settings | User privacy settings | id, user_id, settings |

### 4. Community Features (9 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| blogs | Blog posts | id, title, content, author_id |
| blog_comments | Blog comments | id, blog_id, user_id, content |
| blog_likes | Blog likes | id, blog_id, user_id |
| member_posts | Member posts | id, user_id, content, status |
| post_comments | Post comments | id, post_id, user_id, content |
| post_likes | Post likes | id, post_id, user_id |
| groups | User groups | id, name, description, owner_id |
| group_members | Group membership | id, group_id, user_id, role |
| group_posts | Group posts | id, group_id, user_id, content |

### 5. Communication (4 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| messages | System messages | id, user_id, title, content |
| direct_messages | Direct messages | id, sender_id, receiver_id, content |
| notifications | User notifications | id, user_id, type, content, is_read |
| message_templates | Message templates | id, name, subject, content |

### 6. Analytics & Tracking (6 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| analytics | Analytics data | id, event_type, user_id, metadata |
| analytics_summary | Analytics summary | id, date, metric_type, value |
| page_views | Page view tracking | id, page_url, user_id, session_id |
| visitor_sessions | Visitor sessions | id, session_id, user_id, ip_address |
| browsing_history | User browsing history | id, user_id, content_type, content_id |
| search_keywords | Search keyword tracking | id, keyword, search_count, result_count |

### 7. Media Management (3 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| albums | Photo albums | id, title, description, user_id |
| album_photos | Album photos | id, album_id, photo_url, caption |
| product_images | Product images | id, product_id, image_url, sort_order |

### 8. AI Features (3 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| ai_article_generations | AI article generation records | id, title, content, status |
| ai_article_templates | AI article templates | id, name, template_content, variables |
| ai_batch_generations | AI batch generation tasks | id, task_name, status, progress |

### 9. Web Scraping (3 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| scraper_rules | Scraper rules | id, name, url_pattern, selectors |
| scraper_history | Scraper execution history | id, rule_id, status, items_scraped |
| scraper_request_logs | Scraper request logs | id, url, status_code, response_time |

### 10. SEO & Verification (3 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| page_seo | Page-level SEO settings | id, page_path, title, description |
| redirects | URL redirects | id, from_path, to_path, status_code |
| verification_files | Site verification files | id, filename, content, platform |

### 11. Yiyuan Chemical Module (4 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| yiyuan_content | Yiyuan page content | id, language, hero_title, hero_subtitle |
| yiyuan_manufacturer | Manufacturer information | id, name, address, phone, email |
| yiyuan_products | Yiyuan products | id, name, description, specifications |
| yiyuan_verification_guide | Verification guide | id, step_number, title, description |

### 12. System & Security (5 tables)
| Table Name | Description | Key Fields |
|------------|-------------|------------|
| admin_operation_logs | Admin operation logs | id, admin_id, operation, details |
| profile_management_logs | Profile management logs | id, user_id, action, changes |
| email_verification_codes | Email verification | id, email, code, expires_at |
| member_submissions | Member submissions | id, user_id, submission_type, content |
| wechat_configs | WeChat configuration | id, app_id, app_secret, settings |
| templates | Template management | id, name, content, type |

## Table Relationships

### Primary Relationships

```
profiles (user)
├── articles (author_id)
├── products (created_by)
├── videos (uploaded_by)
├── questions (author_id)
├── answers (author_id)
├── blogs (author_id)
├── member_posts (user_id)
├── groups (owner_id)
└── browsing_history (user_id)

categories
├── articles (category_id)
├── products (category_id)
├── videos (category_id)
├── downloads (category_id)
└── questions (category_id)

questions
└── answers (question_id)

blogs
├── blog_comments (blog_id)
└── blog_likes (blog_id)

member_posts
├── post_comments (post_id)
└── post_likes (post_id)

groups
├── group_members (group_id)
└── group_posts (group_id)

albums
└── album_photos (album_id)

products
└── product_images (product_id)
```

## Common Field Patterns

### Timestamp Fields
Most tables include:
- `created_at` - Record creation timestamp
- `updated_at` - Last update timestamp
- `published_at` - Publication timestamp (content tables)

### Status Fields
Content tables typically have:
- `status` - Enum: 'draft', 'published', 'archived'
- `is_enabled` - Boolean for enable/disable
- `is_featured` - Boolean for featured content

### User Reference Fields
- `user_id` - References profiles.id
- `author_id` - References profiles.id (for content)
- `owner_id` - References profiles.id (for ownership)

### SEO Fields
Content tables often include:
- `slug` - URL-friendly identifier
- `seo_title` - SEO title
- `seo_keywords` - SEO keywords
- `seo_description` - SEO description

## Indexes

### Primary Indexes
All tables have:
- Primary key index on `id` (UUID)

### Common Indexes
- `slug` - Unique index for URL routing
- `user_id` - Index for user-related queries
- `category_id` - Index for category filtering
- `status` - Index for status filtering
- `created_at` - Index for date sorting

### Full-Text Search Indexes
- `articles.title`, `articles.content`
- `products.name`, `products.description`
- `questions.title`, `questions.content`

## Foreign Key Constraints

### Cascade Rules
- **ON DELETE CASCADE**: Used for dependent data (comments, likes)
- **ON DELETE SET NULL**: Used for optional relationships (category_id)
- **ON DELETE RESTRICT**: Used for critical relationships (user_id)

## Row Level Security (RLS)

### Policy Patterns

#### Public Content
```sql
-- Allow public read for published content
CREATE POLICY "public_read" ON articles
  FOR SELECT USING (status = 'published');
```

#### User-Owned Content
```sql
-- Allow users to manage their own content
CREATE POLICY "user_manage_own" ON member_posts
  FOR ALL USING (auth.uid() = user_id);
```

#### Admin Access
```sql
-- Allow admins full access
CREATE POLICY "admin_all" ON articles
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );
```

## Data Types

### Common Data Types
- `UUID` - Primary keys and foreign keys
- `TEXT` - Variable length text
- `VARCHAR(n)` - Fixed length text
- `INTEGER` - Whole numbers
- `NUMERIC` - Decimal numbers
- `BOOLEAN` - True/false values
- `TIMESTAMP WITH TIME ZONE` - Timestamps
- `JSONB` - JSON data

### Custom Types (Enums)
- `content_status` - 'draft', 'published', 'archived'
- `question_status` - 'open', 'answered', 'closed'
- `user_role` - 'admin', 'editor', 'member', 'guest'

---

**Document Version**: 1.0.0  
**Last Updated**: 2026-02-27
